#define WIN32_LEAN_AND_MEAN 
#include <windows.h>

extern void WINAPI Autotype(char* message);

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
    LPSTR lpCmdLine, int nCmdShow)

{
	WinExec("Notepad.exe",SW_SHOW);
	Autotype("Hello friends!\nThis is an example of autotyping. :)");
	return 0;
}
