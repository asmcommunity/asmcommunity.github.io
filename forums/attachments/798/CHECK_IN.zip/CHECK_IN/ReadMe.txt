
Purpose:
To prevent including a file multiple times.

It works like
	#ifndef _checkin_mac_
	#include checkin.mac
	#define _checkin_mac_
	#endif
in C.


Usage:
1. Add "include CHECKIN.MAC" before using macros "CHECK_IN" and "CHECK_OUT".
2. Add the macro "CHECK_IN" to the beginning of the file.
3. Add the macro "%CHECK_OUT" to the end of the file.


Files:
ReadMe.txt		this
CHECKIN.MAC		main file
TEST.ASM		example of step 1
TEST.INC		example of steps 2, 3
ml_msg.txt		the output messages of assembling TEST.ASM
TOOLS\*			an example to do steps 1, 2, 3 in a batch.


jemin@fox1.csie.ncu.edu.tw