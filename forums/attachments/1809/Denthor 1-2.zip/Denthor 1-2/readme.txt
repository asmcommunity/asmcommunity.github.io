These samples were originally written sometime back in the early 90's by Denthor of Asphyxia in PASCAL. Snowman translated some of them to C++ at some point. I have translated them into ASM (MASM syntax) as so many people still seem to want to know about 16-bit ASM for graphics. (Why?!? It's 2006! Tell your university professors to get their heads out of their asses and use 32-bit.)

These tutorials are the ones that I first started learning "proper" programming from, so it's a bit wierd going back to translate them, but hopefully they should be of use to someone.

Tutorials

The tutorials (in the tutorials folder, duh) are unchanged from their original versions (after code inserted by Snowman - note the "last modified" date is around 1994/5). 

Source

This is split into C++/PASCAL/ASM and is in the soruce folder. Don't ask me for any help to do with PASCAL, I've never used PASCAL and if the files don't work, that's your problem. I havn't compiled the c++ since I 1996 when I was using borland turbo c++, so I don't know if it will work with anything else. From a quick glance, the "asm { ... }" blocks must be changed to "__asm { ... }" blocks for use with MS c/c++ compilers (cl).

Compiling The ASM Source

Just run the MAKE.bat file in the ASM source directory. It assumes that you have ML and LINK16 in the \masm32\bin directory.

Notes

I have not optimised any of the code in any way, it is simply a translation of the original. It was made deliberately to be slow by Denthor. Once you know what you're doing, you can go back and redo them to make them fast (there's really no point - they all run way too fast anyway).

Binaries

The binaries can be found in the bin directory. Just double click and have fun.

Liability

I am not liable for any damage you may do to your system. The risk of running the software contained herein is yours alone and I do not accept any responsibility for anything they might do to you or your system.

Having said that, they have all been fine on any system I've ever run them on.