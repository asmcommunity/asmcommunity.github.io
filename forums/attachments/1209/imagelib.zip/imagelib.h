/*
** Ernest Murphy's Image Library
*/

#ifdef __cplusplus
extern "C" {
#endif

HBITMAP BitmapFromFile(char *pszFileName);
HBITMAP BitmapFromMemory(void *pMemory, DWORD dwFileSize);
HBITMAP BitmapFromPicture(IPicture *pPicture);
HBITMAP BitmapFromResource(HINSTANCE hModule, DWORD ResNumber);

#ifdef __cplusplus
}
#endif
