Many thanks to Chetnik for his original pe-mem demo

Jeremy Collake's JCALG1 compression library is available from :
http://www.collakesoftware.com
