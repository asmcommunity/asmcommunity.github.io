// conloader2.cpp : Defines the entry point for the console application.
//

// Conloader2 by stormix
// =====================
// SUMMARY
// Creates a patched version of the exe fill with the same name as it
// but the .exe extension rather than .com and executes it, waits for
// it and then returns its exit code. The nature of the patch is that
// the subsytem in the patched version is always IMAGE_SUBSYSTEM_WINDOWS_CUI
// i.e. a console application.

#include "stdafx.h"

using namespace std;

TCHAR g_szTempName[MAX_PATH];

// To make sure the temp file is always cleaned up.
LONG WINAPI MyExceptionFilter(EXCEPTION_POINTERS *ExceptionInfo)
{
	DeleteFile(g_szTempName);
	return EXCEPTION_EXECUTE_HANDLER;
}

// Display passed error message and system error message, if there
// is one, then exit.
void ErrorExit(LPCSTR szMessage)
{
	cerr << "Loader error: " << szMessage;
	if(GetLastError() != ERROR_SUCCESS)
	{
		LPSTR lpMsgBuf;
		if(FormatMessageA( 
			FORMAT_MESSAGE_ALLOCATE_BUFFER | 
			FORMAT_MESSAGE_FROM_SYSTEM | 
			FORMAT_MESSAGE_IGNORE_INSERTS,
			NULL,
			GetLastError(),
			MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
			(LPSTR) &lpMsgBuf,
			0,
			NULL ))
		{
			cerr << ": " << lpMsgBuf;
			LocalFree(lpMsgBuf);
		}
	}
	cerr << endl;
	DeleteFile(g_szTempName); // ensure temp file is cleaned up
	ExitProcess(-1);
}

// main function
int _tmain(int argc, _TCHAR* argv[])
{
	// set up final exception handler
	SetUnhandledExceptionFilter(MyExceptionFilter);

	// get our own file name
	TCHAR szModName[MAX_PATH];
	GetModuleFileName(GetModuleHandle(NULL), szModName, MAX_PATH);
	// check we weren't named .exe
	if(!_tcscmp(&szModName[_tcslen(szModName)-4], _T(".exe")))
		ErrorExit("Loader must use .com extension");
	// get path to .exe file
	_tcscpy(&szModName[_tcslen(szModName)-4], _T(".exe"));

	TCHAR szTempPath[MAX_PATH];
	GetTempPath(MAX_PATH, szTempPath);

	// get a temporary file name
	GetTempFileName(szTempPath, _T("LDR"), 0, g_szTempName);

	// copy the exe to it
	if(CopyFile(szModName, g_szTempName, FALSE) == FALSE)
		ErrorExit("Couldn't make a copy of exe file");

	// open the copied file
	HANDLE hTempFile = CreateFile(g_szTempName, GENERIC_READ | GENERIC_WRITE, 0,
		NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if(hTempFile == INVALID_HANDLE_VALUE)
		ErrorExit("Couldn't open temporary file");

	// map it into memory, check it's a valid PE and patch it
	HANDLE hFileMap = CreateFileMapping(hTempFile, NULL, PAGE_READWRITE, 0, 0, NULL);
	LPVOID lpvMap = MapViewOfFile(hFileMap, FILE_MAP_ALL_ACCESS, 0, 0, 0);
	PIMAGE_DOS_HEADER dosh = PIMAGE_DOS_HEADER(lpvMap);
	if(dosh->e_magic != IMAGE_DOS_SIGNATURE)
		ErrorExit("Invalid PE file");
	PIMAGE_NT_HEADERS nth = PIMAGE_NT_HEADERS(dosh->e_lfanew + ULONG_PTR(lpvMap));
	if(nth->Signature != IMAGE_NT_SIGNATURE)
		ErrorExit("Invalid PE file");
	nth->OptionalHeader.Subsystem = IMAGE_SUBSYSTEM_WINDOWS_CUI;
	UnmapViewOfFile(lpvMap);
	CloseHandle(hFileMap);
	CloseHandle(hTempFile);

	// run the patched exe
	STARTUPINFO si;
	ZeroMemory(&si, sizeof(si));
	si.cb = sizeof(si);
	PROCESS_INFORMATION pi;
	if(!CreateProcess(g_szTempName, NULL, NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi))
		ErrorExit("Couldn't run the patched exe");
	WaitForSingleObject(pi.hProcess, INFINITE);
	DWORD dwExitCode;
	GetExitCodeProcess(pi.hProcess, &dwExitCode);
	DeleteFile(g_szTempName);
	return (int)dwExitCode;
}

