// guicon.cpp : Defines the entry point for the application.
//

#define VC_EXTRALEAN
#include <windows.h>

int WINAPI WinMain(HINSTANCE hInst, HINSTANCE, LPSTR lpCmdLine, int nCmdShow)
{
	HANDLE hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
	HANDLE hStdIn = GetStdHandle(STD_INPUT_HANDLE);
	if(hStdIn == NULL) // we don't have a console
	{
		MessageBox(HWND_DESKTOP, "Hi from GUI!", "GUI", MB_OK | MB_ICONINFORMATION);
	}
	else // use the console
	{
		DWORD dw;
		WriteFile(hStdOut, "Hi from exe\r\n", 13, &dw, NULL);
		WriteFile(hStdOut, "Enter something: ", 17, &dw, NULL);
		char buf[256];
		ReadFile(hStdIn, buf, 256, &dw, NULL);
		WriteFile(hStdOut, buf, dw, &dw, NULL);
	}
	return 0;
}

