Here's a self-contained example that shows the various MASM32LIB shell routine deficiencies. It runs a background thread compressing a 1meg buffer with Jibz' aPlib.

There's two versions included compress_low.exe sets the thread priority to THREAD_PRIORITY_BELOW_NORMAL. compress_normal.exe doesn't. You could compress_low.exe a simulation of running winrar in "background mode".

First, try running compress_normal.exe. Try opening a few programs (larger than notepad, but not necessarily megabyte monsters). Performance should be sluggish, unless you have a dual-cpu or hyperthreading system. Notice 100% CPU usage in task manager.

Terminate compress_normal and run compress_low. It will also show 100% CPU usage in task manager, but try launching a few programs again - there should be no sluggishness at all, or at least considerably less than compress_normal.

Now for the m32lib shell tests - using the included binaries Jibz provided. Keep compress_low running.

cputestw.exe - compress keeps running normally.

cputeste.exe - compress keeps running normally, but when you hit the OK button it takes 10-20 seconds before it detects client.exe has terminated.

cputest.exe - compress suddenly runs in "bursts", and on my system, the worst-case compression time goes from 47 to 5218 ticks. That's a 111x speed drop, and 347x the normal speed at 15 ticks. At least it doesn't take those 10-20 seconds before it realises client.exe has terminated, though.

All the cputest* binaries use the standard MASM32LIB shell routines.

cputest.exe  - uses shell, loops GetExitCodeProcess, has a Sleep(0) call.

cputeste.exe - uses shell_ex, which still loops GetExitCodeProcess... but sets its priority to IDLE (this is symptomatic treatment, known as a "hack" or a "fudge").

cputestw.exe - uses wshell, which relies on WaitForSingleObject.
