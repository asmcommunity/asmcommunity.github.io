#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#include <stdio.h>
#include <stdlib.h>
#include "aplib.h"

const int test_size = 1024*1024;
const int max_count = 10000;

void	*workmem, *bufin, *bufout;

DWORD WINAPI worker(LPVOID parm)
{
	unsigned	tick, tickb = 0xFFFFFFFF, tickw = 0;

	for(unsigned count=0; count<max_count; count++)
	{
		tick = GetTickCount();
		aP_pack(bufin, bufout, test_size, workmem, 0, 0);
		tick = GetTickCount() - tick;

		if(tick < tickb) tickb = tick;
		if(tick > tickw) tickw = tick;

		printf("\rIteration %d took %10d ticks (best: %10d, worst: %10d)",
			count, tick, tickb, tickw);
	}


	return 0;
}


int main(int argc, char *argv[])
{
	DWORD	tid;
	HANDLE	hthread;

	workmem = malloc(aP_workmem_size(test_size));
	bufin   = malloc(test_size);
	bufout  = malloc(aP_max_packed_size(test_size));
	memset(bufin, '@', test_size);

	printf("Doing %d compression iterations of %d bytes\n", max_count, test_size);

	hthread = CreateThread(0, 0, worker, 0, CREATE_SUSPENDED, &tid);
	SetThreadPriority(hthread, THREAD_PRIORITY_BELOW_NORMAL);
	ResumeThread(hthread);
	WaitForSingleObject(hthread, INFINITE);

	printf("\ndone.\n");

	free(bufout);
	free(bufin);
	free(workmem);

	return 0;
}
