#ifndef _DDRAW_H
#define _DDRAW_H

/* DirectDraw definitions */

/*
Switches used
STRINGS UNICODE
DIRECTDRAW_VERSION (0x0#00h ie 0x0700h)
*/

#IFNDEF Unknown
Unknown STRUCT
   QueryInterface		DD
   AddRef				DD
   Release				DD
Unknown ends
ENDS

#IFNDEF GUID
	GUID STRUCT
	    Data1     dd
	    Data2     dw
	    Data3     dw
	    Data4     db
	        db
	        db
	        db
	        db
	        db
	        db
	        db
	ENDS
#ENDIF

#ifndef DIRECTDRAW_VERSION
#define DIRECTDRAW_VERSION  0x0700
#endif /* DIRECTDRAW_VERSION */

#DEFINE GUID_CLSID_DirectDraw <0xD7B70EE0,0x4340,0x11CF,0xB0,0x63,0x00,0x20,0xAF,0xC2,0xCD,0x35>
#DEFINE GUID_CLSID_DirectDraw7 <0x3c305196,0x50db,0x11d3,0x9c,0xfe,0x00,0xc0,0x4f,0xd9,0x30,0xc5>
#DEFINE GUID_CLSID_DirectDrawClipper <0x593817A0,0x7DB3,0x11CF,0xA2,0xDE,0x00,0xAA,0x00,0xb9,0x33,0x56>
#DEFINE GUID_IID_IDirectDraw <0x6C14DB80,0xA733,0x11CE,0xA5,0x21,0x00,0x20,0xAF,0x0B,0xE5,0x60>
#DEFINE GUID_IID_IDirectDraw2 <0xB3A6F3E0,0x2B43,0x11CF,0xA2,0xDE,0x00,0xAA,0x00,0xB9,0x33,0x56>
#DEFINE GUID_IID_IDirectDraw4 <0x9c59509a,0x39bd,0x11d1,0x8c,0x4a,0x00,0xc0,0x4f,0xd9,0x30,0xc5>
#DEFINE GUID_IID_IDirectDraw7 <0x15e65ec0,0x3b9c,0x11d2,0xb9,0x2f,0x00,0x60,0x97,0x97,0xea,0x5b>
#DEFINE GUID_IID_IDirectDrawSurface <0x6C14DB81,0xA733,0x11CE,0xA5,0x21,0x00,0x20,0xAF,0x0B,0xE5,0x60>
#DEFINE GUID_IID_IDirectDrawSurface2 <0x57805885,0x6eec,0x11cf,0x94,0x41,0xa8,0x23,0x03,0xc1,0x0e,0x27>
#DEFINE GUID_IID_IDirectDrawSurface3 <0xDA044E00,0x69B2,0x11D0,0xA1,0xD5,0x00,0xAA,0x00,0xB8,0xDF,0xBB>
#DEFINE GUID_IID_IDirectDrawSurface4 <0x0B2B8630,0xAD35,0x11D0,0x8E,0xA6,0x00,0x60,0x97,0x97,0xEA,0x5B>
#DEFINE GUID_IID_IDirectDrawSurface7 <0x06675a80,0x3b9b,0x11d2,0xb9,0x2f,0x00,0x60,0x97,0x97,0xea,0x5b>
#DEFINE GUID_IID_IDirectDrawPalette <0x6C14DB84,0xA733,0x11CE,0xA5,0x21,0x00,0x20,0xAF,0x0B,0xE5,0x60>
#DEFINE GUID_IID_IDirectDrawClipper <0x6C14DB85,0xA733,0x11CE,0xA5,0x21,0x00,0x20,0xAF,0x0B,0xE5,0x60>
#DEFINE GUID_IID_IDirectDrawColorControl <0x4B9F0EE0,0x0D7E,0x11D0,0x9B,0x06,0x00,0xA0,0xC9,0x03,0xA3,0xB8>
#DEFINE GUID_IID_IDirectDrawGammaControl <0x69C11C3E,0xB46B,0x11D1,0xAD,0x7A,0x00,0xC0,0x4F,0xC2,0x9B,0x4E>

#define DDENUM_ATTACHEDSECONDARYDEVICES  0x00000001
#define DDENUM_DETACHEDSECONDARYDEVICES  0x00000002
#define DDENUM_NONDISPLAYDEVICES  0x00000004

#define REGSTR_KEY_DDHW_DESCRIPTION  "Description"
#define REGSTR_KEY_DDHW_DRIVERNAME  "DriverName"
#define REGSTR_PATH_DDHW  "Hardware\\DirectDrawDrivers"

#define DDCREATE_HARDWAREONLY  0x00000001
#define DDCREATE_EMULATIONONLY  0x00000002

#define DD_ROP_SPACE  8

#define MAX_DDDEVICEID_STRING  512

#define DDGDI_GETHOSTIDENTIFIER  0x00000001

#define DDSD_CAPS  0x00000001
#define DDSD_HEIGHT  0x00000002
#define DDSD_WIDTH  0x00000004
#define DDSD_PITCH  0x00000008
#define DDSD_BACKBUFFERCOUNT  0x00000020
#define DDSD_ZBUFFERBITDEPTH  0x00000040
#define DDSD_ALPHABITDEPTH  0x00000080
#define DDSD_LPSURFACE  0x00000800
#define DDSD_PIXELFORMAT  0x00001000
#define DDSD_CKDESTOVERLAY  0x00002000
#define DDSD_CKDESTBLT  0x00004000
#define DDSD_CKSRCOVERLAY  0x00008000
#define DDSD_CKSRCBLT  0x00010000
#define DDSD_MIPMAPCOUNT  0x00020000
#define DDSD_REFRESHRATE  0x00040000
#define DDSD_LINEARSIZE  0x00080000
#define DDSD_TEXTURESTAGE  0x00100000
#define DDSD_FVF  0x00200000
#define DDSD_SRCVBHANDLE  0x00400000
#define DDSD_ALL  0x007ff9eel

#define DDOSD_GUID  0x00000001
#define DDOSD_COMPRESSION_RATIO  0x00000002
#define DDOSD_SCAPS  0x00000004
#define DDOSD_OSCAPS  0x00000008
#define DDOSD_ALL  0x0000000fl

#define DDOSDCAPS_OPTCOMPRESSED  0x00000001
#define DDOSDCAPS_OPTREORDERED  0x00000002
#define DDOSDCAPS_MONOLITHICMIPMAP  0x00000004
#define DDOSDCAPS_VALIDSCAPS  0x30004800
#define DDOSDCAPS_VALIDOSCAPS  0x00000007

#define DDCOLOR_BRIGHTNESS  0x00000001
#define DDCOLOR_CONTRAST  0x00000002
#define DDCOLOR_HUE  0x00000004
#define DDCOLOR_SATURATION  0x00000008
#define DDCOLOR_SHARPNESS  0x00000010
#define DDCOLOR_GAMMA  0x00000020
#define DDCOLOR_COLORENABLE  0x00000040

#define DDSCAPS_RESERVED1  0x00000001
#define DDSCAPS_ALPHA  0x00000002
#define DDSCAPS_BACKBUFFER  0x00000004
#define DDSCAPS_COMPLEX  0x00000008
#define DDSCAPS_FLIP  0x00000010
#define DDSCAPS_FRONTBUFFER  0x00000020
#define DDSCAPS_OFFSCREENPLAIN  0x00000040
#define DDSCAPS_OVERLAY  0x00000080
#define DDSCAPS_PALETTE  0x00000100
#define DDSCAPS_PRIMARYSURFACE  0x00000200
#define DDSCAPS_RESERVED3  0x00000400
#define DDSCAPS_PRIMARYSURFACELEFT  0
#define DDSCAPS_SYSTEMMEMORY  0x00000800
#define DDSCAPS_TEXTURE  0x00001000
#define DDSCAPS_3DDEVICE  0x00002000
#define DDSCAPS_VIDEOMEMORY  0x00004000
#define DDSCAPS_VISIBLE  0x00008000
#define DDSCAPS_WRITEONLY  0x00010000
#define DDSCAPS_ZBUFFER  0x00020000
#define DDSCAPS_OWNDC  0x00040000
#define DDSCAPS_LIVEVIDEO  0x00080000
#define DDSCAPS_HWCODEC  0x00100000
#define DDSCAPS_MODEX  0x00200000
#define DDSCAPS_MIPMAP  0x00400000
#define DDSCAPS_RESERVED2  0x00800000
#define DDSCAPS_ALLOCONLOAD  0x04000000
#define DDSCAPS_VIDEOPORT  0x08000000
#define DDSCAPS_LOCALVIDMEM  0x10000000
#define DDSCAPS_NONLOCALVIDMEM  0x20000000
#define DDSCAPS_STANDARDVGAMODE  0x40000000
#define DDSCAPS_OPTIMIZED  0x80000000

#define DDSCAPS2_HARDWAREDEINTERLACE  0x00000002
#define DDSCAPS2_HINTDYNAMIC  0x00000004
#define DDSCAPS2_HINTSTATIC  0x00000008
#define DDSCAPS2_TEXTUREMANAGE  0x00000010
#define DDSCAPS2_RESERVED1  0x00000020
#define DDSCAPS2_RESERVED2  0x00000040
#define DDSCAPS2_OPAQUE  0x00000080
#define DDSCAPS2_HINTANTIALIASING  0x00000100
#define DDSCAPS2_CUBEMAP  0x00000200
#define DDSCAPS2_CUBEMAP_POSITIVEX  0x00000400
#define DDSCAPS2_CUBEMAP_NEGATIVEX  0x00000800
#define DDSCAPS2_CUBEMAP_POSITIVEY  0x00001000
#define DDSCAPS2_CUBEMAP_NEGATIVEY  0x00002000
#define DDSCAPS2_CUBEMAP_POSITIVEZ  0x00004000
#define DDSCAPS2_CUBEMAP_NEGATIVEZ  0x00008000
#define DDSCAPS2_CUBEMAP_ALLFACES (DDSCAPS2_CUBEMAP_POSITIVEX|DDSCAPS2_CUBEMAP_NEGATIVEX|DDSCAPS2_CUBEMAP_POSITIVEY|DDSCAPS2_CUBEMAP_NEGATIVEY|DDSCAPS2_CUBEMAP_POSITIVEZ|DDSCAPS2_CUBEMAP_NEGATIVEZ)
#define DDSCAPS2_MIPMAPSUBLEVEL  0x00010000
#define DDSCAPS2_D3DTEXTUREMANAGE  0x00020000
#define DDSCAPS2_DONOTPERSIST  0x00040000
#define DDSCAPS2_STEREOSURFACELEFT  0x00080000

#define DDCAPS_3D  0x00000001
#define DDCAPS_ALIGNBOUNDARYDEST  0x00000002
#define DDCAPS_ALIGNSIZEDEST  0x00000004
#define DDCAPS_ALIGNBOUNDARYSRC  0x00000008
#define DDCAPS_ALIGNSIZESRC  0x00000010
#define DDCAPS_ALIGNSTRIDE  0x00000020
#define DDCAPS_BLT  0x00000040
#define DDCAPS_BLTQUEUE  0x00000080
#define DDCAPS_BLTFOURCC  0x00000100
#define DDCAPS_BLTSTRETCH  0x00000200
#define DDCAPS_GDI  0x00000400
#define DDCAPS_OVERLAY  0x00000800
#define DDCAPS_OVERLAYCANTCLIP  0x00001000
#define DDCAPS_OVERLAYFOURCC  0x00002000
#define DDCAPS_OVERLAYSTRETCH  0x00004000
#define DDCAPS_PALETTE  0x00008000
#define DDCAPS_PALETTEVSYNC  0x00010000
#define DDCAPS_READSCANLINE  0x00020000
#define DDCAPS_RESERVED1  0x00040000
#define DDCAPS_VBI  0x00080000
#define DDCAPS_ZBLTS  0x00100000
#define DDCAPS_ZOVERLAYS  0x00200000
#define DDCAPS_COLORKEY  0x00400000
#define DDCAPS_ALPHA  0x00800000
#define DDCAPS_COLORKEYHWASSIST  0x01000000
#define DDCAPS_NOHARDWARE  0x02000000
#define DDCAPS_BLTCOLORFILL  0x04000000
#define DDCAPS_BANKSWITCHED  0x08000000
#define DDCAPS_BLTDEPTHFILL  0x10000000
#define DDCAPS_CANCLIP  0x20000000
#define DDCAPS_CANCLIPSTRETCHED  0x40000000
#define DDCAPS_CANBLTSYSMEM  0x80000000

#define DDCAPS2_CERTIFIED  0x00000001
#define DDCAPS2_NO2DDURING3DSCENE  0x00000002
#define DDCAPS2_VIDEOPORT  0x00000004
#define DDCAPS2_AUTOFLIPOVERLAY  0x00000008
#define DDCAPS2_CANBOBINTERLEAVED  0x00000010
#define DDCAPS2_CANBOBNONINTERLEAVED  0x00000020
#define DDCAPS2_COLORCONTROLOVERLAY  0x00000040
#define DDCAPS2_COLORCONTROLPRIMARY  0x00000080
#define DDCAPS2_CANDROPZ16BIT  0x00000100
#define DDCAPS2_NONLOCALVIDMEM  0x00000200
#define DDCAPS2_NONLOCALVIDMEMCAPS  0x00000400
#define DDCAPS2_NOPAGELOCKREQUIRED  0x00000800
#define DDCAPS2_WIDESURFACES  0x00001000
#define DDCAPS2_CANFLIPODDEVEN  0x00002000
#define DDCAPS2_CANBOBHARDWARE  0x00004000
#define DDCAPS2_COPYFOURCC  0x00008000
#define DDCAPS2_PRIMARYGAMMA  0x00020000
#define DDCAPS2_CANRENDERWINDOWED  0x00080000
#define DDCAPS2_CANCALIBRATEGAMMA  0x00100000
#define DDCAPS2_FLIPINTERVAL  0x00200000
#define DDCAPS2_FLIPNOVSYNC  0x00400000
#define DDCAPS2_CANMANAGETEXTURE  0x00800000
#define DDCAPS2_TEXMANINNONLOCALVIDMEM  0x01000000
#define DDCAPS2_STEREO  0x02000000
#define DDCAPS2_SYSTONONLOCAL_AS_SYSTOLOCAL  0x04000000

#define DDFXALPHACAPS_BLTALPHAEDGEBLEND  0x00000001
#define DDFXALPHACAPS_BLTALPHAPIXELS  0x00000002
#define DDFXALPHACAPS_BLTALPHAPIXELSNEG  0x00000004
#define DDFXALPHACAPS_BLTALPHASURFACES  0x00000008
#define DDFXALPHACAPS_BLTALPHASURFACESNEG  0x00000010
#define DDFXALPHACAPS_OVERLAYALPHAEDGEBLEND  0x00000020
#define DDFXALPHACAPS_OVERLAYALPHAPIXELS  0x00000040
#define DDFXALPHACAPS_OVERLAYALPHAPIXELSNEG  0x00000080
#define DDFXALPHACAPS_OVERLAYALPHASURFACES  0x00000100
#define DDFXALPHACAPS_OVERLAYALPHASURFACESNEG  0x00000200

#define DDFXCAPS_BLTARITHSTRETCHY  0x00000020
#define DDFXCAPS_BLTARITHSTRETCHYN  0x00000010
#define DDFXCAPS_BLTMIRRORLEFTRIGHT  0x00000040
#define DDFXCAPS_BLTMIRRORUPDOWN  0x00000080
#define DDFXCAPS_BLTROTATION  0x00000100
#define DDFXCAPS_BLTROTATION90  0x00000200
#define DDFXCAPS_BLTSHRINKX  0x00000400
#define DDFXCAPS_BLTSHRINKXN  0x00000800
#define DDFXCAPS_BLTSHRINKY  0x00001000
#define DDFXCAPS_BLTSHRINKYN  0x00002000
#define DDFXCAPS_BLTSTRETCHX  0x00004000
#define DDFXCAPS_BLTSTRETCHXN  0x00008000
#define DDFXCAPS_BLTSTRETCHY  0x00010000
#define DDFXCAPS_BLTSTRETCHYN  0x00020000
#define DDFXCAPS_OVERLAYARITHSTRETCHY  0x00040000
#define DDFXCAPS_OVERLAYARITHSTRETCHYN  0x00000008
#define DDFXCAPS_OVERLAYSHRINKX  0x00080000
#define DDFXCAPS_OVERLAYSHRINKXN  0x00100000
#define DDFXCAPS_OVERLAYSHRINKY  0x00200000
#define DDFXCAPS_OVERLAYSHRINKYN  0x00400000
#define DDFXCAPS_OVERLAYSTRETCHX  0x00800000
#define DDFXCAPS_OVERLAYSTRETCHXN  0x01000000
#define DDFXCAPS_OVERLAYSTRETCHY  0x02000000
#define DDFXCAPS_OVERLAYSTRETCHYN  0x04000000
#define DDFXCAPS_OVERLAYMIRRORLEFTRIGHT 0x08000000
#define DDFXCAPS_OVERLAYMIRRORUPDOWN  0x10000000
#define DDFXCAPS_BLTALPHA  0x00000001
#define DDFXCAPS_BLTFILTER  DDFXCAPS_BLTARITHSTRETCHY
#define DDFXCAPS_OVERLAYALPHA  0x00000004
#define DDFXCAPS_OVERLAYFILTER  DDFXCAPS_OVERLAYARITHSTRETCHY

#define DDSVCAPS_RESERVED1  0x00000001
#define DDSVCAPS_RESERVED2  0x00000002
#define DDSVCAPS_RESERVED3  0x00000004
#define DDSVCAPS_RESERVED4  0x00000008
#define DDSVCAPS_STEREOSEQUENTIAL  0x00000010

#define DDPCAPS_4BIT  0x00000001
#define DDPCAPS_8BITENTRIES  0x00000002
#define DDPCAPS_8BIT  0x00000004
#define DDPCAPS_INITIALIZE  0x00000000
#define DDPCAPS_PRIMARYSURFACE  0x00000010
#define DDPCAPS_PRIMARYSURFACELEFT  0x00000020
#define DDPCAPS_ALLOW256  0x00000040
#define DDPCAPS_VSYNC  0x00000080
#define DDPCAPS_1BIT  0x00000100
#define DDPCAPS_2BIT  0x00000200
#define DDPCAPS_ALPHA  0x00000400

#define DDSPD_IUNKNOWNPOINTER  0x00000001
#define DDSPD_VOLATILE  0x00000002

#define DDBD_1  0x00004000
#define DDBD_2  0x00002000
#define DDBD_4  0x00001000
#define DDBD_8  0x00000800
#define DDBD_16  0x00000400
#define DDBD_24  0X00000200
#define DDBD_32  0x00000100

#define DDCKEY_COLORSPACE  0x00000001
#define DDCKEY_DESTBLT  0x00000002
#define DDCKEY_DESTOVERLAY  0x00000004
#define DDCKEY_SRCBLT  0x00000008
#define DDCKEY_SRCOVERLAY  0x00000010

#define DDCKEYCAPS_DESTBLT  0x00000001
#define DDCKEYCAPS_DESTBLTCLRSPACE  0x00000002
#define DDCKEYCAPS_DESTBLTCLRSPACEYUV  0x00000004
#define DDCKEYCAPS_DESTBLTYUV  0x00000008
#define DDCKEYCAPS_DESTOVERLAY  0x00000010
#define DDCKEYCAPS_DESTOVERLAYCLRSPACE  0x00000020
#define DDCKEYCAPS_DESTOVERLAYCLRSPACEYUV  0x00000040
#define DDCKEYCAPS_DESTOVERLAYONEACTIVE  0x00000080
#define DDCKEYCAPS_DESTOVERLAYYUV  0x00000100
#define DDCKEYCAPS_SRCBLT  0x00000200
#define DDCKEYCAPS_SRCBLTCLRSPACE  0x00000400
#define DDCKEYCAPS_SRCBLTCLRSPACEYUV  0x00000800
#define DDCKEYCAPS_SRCBLTYUV  0x00001000
#define DDCKEYCAPS_SRCOVERLAY  0x00002000
#define DDCKEYCAPS_SRCOVERLAYCLRSPACE  0x00004000
#define DDCKEYCAPS_SRCOVERLAYCLRSPACEYUV  0x00008000
#define DDCKEYCAPS_SRCOVERLAYONEACTIVE  0x00010000
#define DDCKEYCAPS_SRCOVERLAYYUV  0x00020000
#define DDCKEYCAPS_NOCOSTOVERLAY  0x00040000

#define DDPF_ALPHAPIXELS  0x00000001
#define DDPF_ALPHA  0x00000002
#define DDPF_FOURCC  0x00000004
#define DDPF_PALETTEINDEXED4  0x00000008
#define DDPF_PALETTEINDEXEDTO8  0x00000010
#define DDPF_PALETTEINDEXED8  0x00000020
#define DDPF_RGB  0x00000040
#define DDPF_COMPRESSED  0x00000080
#define DDPF_RGBTOYUV  0x00000100
#define DDPF_YUV  0x00000200
#define DDPF_ZBUFFER  0x00000400
#define DDPF_PALETTEINDEXED1  0x00000800
#define DDPF_PALETTEINDEXED2  0x00001000
#define DDPF_ZPIXELS  0x00002000
#define DDPF_STENCILBUFFER  0x00004000
#define DDPF_ALPHAPREMULT  0x00008000
#define DDPF_LUMINANCE  0x00020000
#define DDPF_BUMPLUMINANCE  0x00040000
#define DDPF_BUMPDUDV  0x00080000

#define DDENUMSURFACES_ALL  0x00000001
#define DDENUMSURFACES_MATCH  0x00000002
#define DDENUMSURFACES_NOMATCH  0x00000004
#define DDENUMSURFACES_CANBECREATED  0x00000008
#define DDENUMSURFACES_DOESEXIST  0x00000010

#define DDSDM_STANDARDVGAMODE  0x00000001
#define DDEDM_REFRESHRATES  0x00000001
#define DDEDM_STANDARDVGAMODES  0x00000002

#define DDSCL_FULLSCREEN  0x00000001
#define DDSCL_ALLOWREBOOT  0x00000002
#define DDSCL_NOWINDOWCHANGES  0x00000004
#define DDSCL_NORMAL  0x00000008
#define DDSCL_EXCLUSIVE  0x00000010
#define DDSCL_ALLOWMODEX  0x00000040
#define DDSCL_SETFOCUSWINDOW  0x00000080
#define DDSCL_SETDEVICEWINDOW  0x00000100
#define DDSCL_CREATEDEVICEWINDOW  0x00000200
#define DDSCL_MULTITHREADED  0x00000400
#define DDSCL_FPUSETUP  0x00000800
#define DDSCL_FPUPRESERVE  0x00001000

#define DDBLT_ALPHADEST  0x00000001
#define DDBLT_ALPHADESTCONSTOVERRIDE  0x00000002
#define DDBLT_ALPHADESTNEG  0x00000004
#define DDBLT_ALPHADESTSURFACEOVERRIDE  0x00000008
#define DDBLT_ALPHAEDGEBLEND  0x00000010
#define DDBLT_ALPHASRC  0x00000020
#define DDBLT_ALPHASRCCONSTOVERRIDE  0x00000040
#define DDBLT_ALPHASRCNEG  0x00000080
#define DDBLT_ALPHASRCSURFACEOVERRIDE  0x00000100
#define DDBLT_ASYNC  0x00000200
#define DDBLT_COLORFILL  0x00000400
#define DDBLT_DDFX  0x00000800
#define DDBLT_DDROPS  0x00001000
#define DDBLT_KEYDEST  0x00002000
#define DDBLT_KEYDESTOVERRIDE  0x00004000
#define DDBLT_KEYSRC  0x00008000
#define DDBLT_KEYSRCOVERRIDE  0x00010000
#define DDBLT_ROP  0x00020000
#define DDBLT_ROTATIONANGLE  0x00040000
#define DDBLT_ZBUFFER  0x00080000
#define DDBLT_ZBUFFERDESTCONSTOVERRIDE  0x00100000
#define DDBLT_ZBUFFERDESTOVERRIDE  0x00200000
#define DDBLT_ZBUFFERSRCCONSTOVERRIDE  0x00400000
#define DDBLT_ZBUFFERSRCOVERRIDE  0x00800000
#define DDBLT_WAIT  0x01000000
#define DDBLT_DEPTHFILL  0x02000000
#define DDBLT_DONOTWAIT  0x08000000

#define DDBLTFAST_NOCOLORKEY  0x00000000
#define DDBLTFAST_SRCCOLORKEY  0x00000001
#define DDBLTFAST_DESTCOLORKEY  0x00000002
#define DDBLTFAST_WAIT  0x00000010
#define DDBLTFAST_DONOTWAIT  0x00000020

#define DDFLIP_WAIT  0x00000001
#define DDFLIP_EVEN  0x00000002
#define DDFLIP_ODD  0x00000004
#define DDFLIP_NOVSYNC  0x00000008
#define DDFLIP_INTERVAL2  0x02000000
#define DDFLIP_INTERVAL3  0x03000000
#define DDFLIP_INTERVAL4  0x04000000
#define DDFLIP_STEREO  0x00000010
#define DDFLIP_DONOTWAIT  0x00000020

#define DDOVER_ALPHADEST  0x00000001
#define DDOVER_ALPHADESTCONSTOVERRIDE  0x00000002
#define DDOVER_ALPHADESTNEG  0x00000004
#define DDOVER_ALPHADESTSURFACEOVERRIDE  0x00000008
#define DDOVER_ALPHAEDGEBLEND  0x00000010
#define DDOVER_ALPHASRC  0x00000020
#define DDOVER_ALPHASRCCONSTOVERRIDE  0x00000040
#define DDOVER_ALPHASRCNEG  0x00000080
#define DDOVER_ALPHASRCSURFACEOVERRIDE  0x00000100
#define DDOVER_HIDE  0x00000200
#define DDOVER_KEYDEST  0x00000400
#define DDOVER_KEYDESTOVERRIDE  0x00000800
#define DDOVER_KEYSRC  0x00001000
#define DDOVER_KEYSRCOVERRIDE  0x00002000
#define DDOVER_SHOW  0x00004000
#define DDOVER_ADDDIRTYRECT  0x00008000
#define DDOVER_REFRESHDIRTYRECTS  0x00010000
#define DDOVER_REFRESHALL  0x00020000
#define DDOVER_DDFX  0x00080000
#define DDOVER_AUTOFLIP  0x00100000
#define DDOVER_BOB  0x00200000
#define DDOVER_OVERRIDEBOBWEAVE  0x00400000
#define DDOVER_INTERLEAVED  0x00800000
#define DDOVER_BOBHARDWARE  0x01000000
#define DDOVER_ARGBSCALEFACTORS  0x02000000
#define DDOVER_DEGRADEARGBSCALING  0x04000000

#define DDLOCK_SURFACEMEMORYPTR  0x00000000
#define DDLOCK_WAIT  0x00000001
#define DDLOCK_EVENT  0x00000002
#define DDLOCK_READONLY  0x00000010
#define DDLOCK_WRITEONLY  0x00000020
#define DDLOCK_NOSYSLOCK  0x00000800
#define DDLOCK_NOOVERWRITE  0x00001000
#define DDLOCK_DISCARDCONTENTS  0x00002000
#define DDLOCK_OKTOSWAP  0x00002000
#define DDLOCK_DONOTWAIT  0x00004000

#define DDBLTFX_ARITHSTRETCHY  0x00000001
#define DDBLTFX_MIRRORLEFTRIGHT  0x00000002
#define DDBLTFX_MIRRORUPDOWN  0x00000004
#define DDBLTFX_NOTEARING  0x00000008
#define DDBLTFX_ROTATE180  0x00000010
#define DDBLTFX_ROTATE270  0x00000020
#define DDBLTFX_ROTATE90  0x00000040
#define DDBLTFX_ZBUFFERRANGE  0x00000080
#define DDBLTFX_ZBUFFERBASEDEST  0x00000100

#define DDOVERFX_ARITHSTRETCHY  0x00000001
#define DDOVERFX_MIRRORLEFTRIGHT  0x00000002
#define DDOVERFX_MIRRORUPDOWN  0x00000004

#define DDWAITVB_BLOCKBEGIN  0x00000001
#define DDWAITVB_BLOCKBEGINEVENT  0x00000002
#define DDWAITVB_BLOCKEND  0x00000004

#define DDGFS_CANFLIP  0x00000001
#define DDGFS_ISFLIPDONE  0x00000002

#define DDGBS_CANBLT  0x00000001
#define DDGBS_ISBLTDONE  0x00000002

#define DDENUMOVERLAYZ_BACKTOFRONT  0x00000000
#define DDENUMOVERLAYZ_FRONTTOBACK  0x00000001

#define DDOVERZ_SENDTOFRONT  0x00000000
#define DDOVERZ_SENDTOBACK  0x00000001
#define DDOVERZ_MOVEFORWARD  0x00000002
#define DDOVERZ_MOVEBACKWARD  0x00000003
#define DDOVERZ_INSERTINFRONTOF  0x00000004
#define DDOVERZ_INSERTINBACKOF  0x00000005

#define DDSGR_CALIBRATE  0x00000001
#define DDSMT_ISTESTREQUIRED  0x00000001

#define DDEM_MODEPASSED  0x00000001
#define DDEM_MODEFAILED  0x00000002

#define DD_OK  0
#define DD_FALSE  S_FALSE

#define DDENUMRET_CANCEL  0
#define DDENUMRET_OK  1

#define DDERR_ALREADYINITIALIZED  5
#define DDERR_CANNOTATTACHSURFACE  10
#define DDERR_CANNOTDETACHSURFACE  20
#define DDERR_CURRENTLYNOTAVAIL  40
#define DDERR_EXCEPTION  55
#define DDERR_GENERIC  E_FAIL
#define DDERR_HEIGHTALIGN  90
#define DDERR_INCOMPATIBLEPRIMARY  95
#define DDERR_INVALIDCAPS  100
#define DDERR_INVALIDCLIPLIST  110
#define DDERR_INVALIDMODE  120
#define DDERR_INVALIDOBJECT  130
#define DDERR_INVALIDPARAMS  E_INVALIDARG
#define DDERR_INVALIDPIXELFORMAT  145
#define DDERR_INVALIDRECT  150
#define DDERR_LOCKEDSURFACES  160
#define DDERR_NO3D  170
#define DDERR_NOALPHAHW  180
#define DDERR_NOSTEREOHARDWARE  181
#define DDERR_NOSURFACELEFT  182
#define DDERR_NOCLIPLIST  205
#define DDERR_NOCOLORCONVHW  210
#define DDERR_NOCOOPERATIVELEVELSET  212
#define DDERR_NOCOLORKEY  215
#define DDERR_NOCOLORKEYHW  220
#define DDERR_NODIRECTDRAWSUPPORT  222
#define DDERR_NOEXCLUSIVEMODE  225
#define DDERR_NOFLIPHW  230
#define DDERR_NOGDI  240
#define DDERR_NOMIRRORHW  250
#define DDERR_NOTFOUND  255
#define DDERR_NOOVERLAYHW  260
#define DDERR_OVERLAPPINGRECTS  270
#define DDERR_NORASTEROPHW  280
#define DDERR_NOROTATIONHW  290
#define DDERR_NOSTRETCHHW  310
#define DDERR_NOT4BITCOLOR  316
#define DDERR_NOT4BITCOLORINDEX  317
#define DDERR_NOT8BITCOLOR  320
#define DDERR_NOTEXTUREHW  330
#define DDERR_NOVSYNCHW  335
#define DDERR_NOZBUFFERHW  340
#define DDERR_NOZOVERLAYHW  350
#define DDERR_OUTOFCAPS  360
#define DDERR_OUTOFMEMORY  E_OUTOFMEMORY
#define DDERR_OUTOFVIDEOMEMORY  380
#define DDERR_OVERLAYCANTCLIP  382
#define DDERR_OVERLAYCOLORKEYONLYONEACTIVE  384
#define DDERR_PALETTEBUSY  387
#define DDERR_COLORKEYNOTSET  400
#define DDERR_SURFACEALREADYATTACHED  410
#define DDERR_SURFACEALREADYDEPENDENT  420
#define DDERR_SURFACEBUSY  430
#define DDERR_CANTLOCKSURFACE  435
#define DDERR_SURFACEISOBSCURED  440
#define DDERR_SURFACELOST  450
#define DDERR_SURFACENOTATTACHED  460
#define DDERR_TOOBIGHEIGHT  470
#define DDERR_TOOBIGSIZE  480
#define DDERR_TOOBIGWIDTH  490
#define DDERR_UNSUPPORTED  E_NOTIMPL
#define DDERR_UNSUPPORTEDFORMAT  510
#define DDERR_UNSUPPORTEDMASK  520
#define DDERR_INVALIDSTREAM  521
#define DDERR_VERTICALBLANKINPROGRESS  537
#define DDERR_WASSTILLDRAWING  540
#define DDERR_DDSCAPSCOMPLEXREQUIRED  542
#define DDERR_XALIGN  560
#define DDERR_INVALIDDIRECTDRAWGUID  561
#define DDERR_DIRECTDRAWALREADYCREATED  562
#define DDERR_NODIRECTDRAWHW  563
#define DDERR_PRIMARYSURFACEALREADYEXISTS  564
#define DDERR_NOEMULATION  565
#define DDERR_REGIONTOOSMALL  566
#define DDERR_CLIPPERISUSINGHWND  567
#define DDERR_NOCLIPPERATTACHED  568
#define DDERR_NOHWND  569
#define DDERR_HWNDSUBCLASSED  570
#define DDERR_HWNDALREADYSET  571
#define DDERR_NOPALETTEATTACHED  572
#define DDERR_NOPALETTEHW  573
#define DDERR_BLTFASTCANTCLIP  574
#define DDERR_NOBLTHW  575
#define DDERR_NODDROPSHW  576
#define DDERR_OVERLAYNOTVISIBLE  577
#define DDERR_NOOVERLAYDEST  578
#define DDERR_INVALIDPOSITION  579
#define DDERR_NOTAOVERLAYSURFACE  580
#define DDERR_EXCLUSIVEMODEALREADYSET  581
#define DDERR_NOTFLIPPABLE  582
#define DDERR_CANTDUPLICATE  583
#define DDERR_NOTLOCKED  584
#define DDERR_CANTCREATEDC  585
#define DDERR_NODC  586
#define DDERR_WRONGMODE  587
#define DDERR_IMPLICITLYCREATED  588
#define DDERR_NOTPALETTIZED  589
#define DDERR_UNSUPPORTEDMODE  590
#define DDERR_NOMIPMAPHW  591
#define DDERR_INVALIDSURFACETYPE  592
#define DDERR_NOOPTIMIZEHW  600
#define DDERR_NOTLOADED  601
#define DDERR_NOFOCUSWINDOW  602
#define DDERR_NOTONMIPMAPSUBLEVEL  603
#define DDERR_DCALREADYCREATED  620
#define DDERR_NONONLOCALVIDMEM  630
#define DDERR_CANTPAGELOCK  640
#define DDERR_CANTPAGEUNLOCK  660
#define DDERR_NOTPAGELOCKED  680
#define DDERR_MOREDATA  690
#define DDERR_EXPIRED  691
#define DDERR_TESTFINISHED  692
#define DDERR_NEWMODE  693
#define DDERR_D3DNOTINITIALIZED  694
#define DDERR_VIDEONOTACTIVE  695
#define DDERR_NOMONITORINFORMATION  696
#define DDERR_NODRIVERSUPPORT  697
#define DDERR_DEVICEDOESNTOWNSURFACE  699
#define DDERR_NOTINITIALIZED  CO_E_NOTINITIALIZED

DDARGB STRUCT
	blue DB
	green DB
	red DB
	alpha DB
ENDS

DDRGBA STRUCT
	red DB
	green DB
	blue DB
	alpha DB
ENDS

DDCOLORKEY STRUCT
	dwColorSpaceLowValue DD
	dwColorSpaceHighValue DD
ENDS

DDBLTFX STRUCT
	dwSize DD
	dwDDFX DD
	dwROP DD
	dwDDROP DD
	dwRotationAngle DD
	dwZBufferOpCode DD
	dwZBufferLow DD
	dwZBufferHigh DD
	dwZBufferBaseDest DD
	dwZDestConstBitDepth DD
	UNION
		dwZDestConst DD
		lpDDSZBufferDest DD
	ENDUNION
	dwZSrcConstBitDepth DD
	UNION
		dwZSrcConst DD
		lpDDSZBufferSrc DD
	ENDUNION
	dwAlphaEdgeBlendBitDepth DD
	dwAlphaEdgeBlend DD
	dwReserved DD
	dwAlphaDestConstBitDepth DD
	UNION
		dwAlphaDestConst DD
		lpDDSAlphaDest DD
	ENDUNION
	dwAlphaSrcConstBitDepth DD
	UNION
		dwAlphaSrcConst DD
		lpDDSAlphaSrc DD
	ENDUNION
	UNION
		dwFillColor DD
		dwFillDepth DD
		dwFillPixel DD
		lpDDSPattern DD
	ENDUNION
	ddckDestColorkey DDCOLORKEY <>
	ddckSrcColorkey DDCOLORKEY <>
ENDS

DDSCAPS STRUCT
	dwCaps DD
ENDS

DDOSCAPS STRUCT
	dwCaps DD
ENDS

DDSCAPSEX STRUCT
	dwCaps2 DD
	dwCaps3 DD
	dwCaps4 DD
ENDS

DDSCAPS2 STRUCT
	dwCaps DD
	dwCaps2 DD
	dwCaps3 DD
	dwCaps4 DD
ENDS

DDCAPS_DX1 STRUCT
	dwSize DD
	dwCaps DD
	dwCaps2 DD
	dwCKeyCaps DD
	dwFXCaps DD
	dwFXAlphaCaps DD
	dwPalCaps DD
	dwSVCaps DD
	dwAlphaBltConstBitDepths DD
	dwAlphaBltPixelBitDepths DD
	dwAlphaBltSurfaceBitDepths DD
	dwAlphaOverlayConstBitDepths DD
	dwAlphaOverlayPixelBitDepths DD
	dwAlphaOverlaySurfaceBitDepths DD
	dwZBufferBitDepths DD
	dwVidMemTotal DD
	dwVidMemFree DD
	dwMaxVisibleOverlays DD
	dwCurrVisibleOverlays DD
	dwNumFourCCCodes DD
	dwAlignBoundarySrc DD
	dwAlignSizeSrc DD
	dwAlignBoundaryDest DD
	dwAlignSizeDest DD
	dwAlignStrideAlign DD
	dwRops DD DD_ROP_SPACE DUP (?)
	ddsCaps DDSCAPS <>
	dwMinOverlayStretch DD
	dwMaxOverlayStretch DD
	dwMinLiveVideoStretch DD
	dwMaxLiveVideoStretch DD
	dwMinHwCodecStretch DD
	dwMaxHwCodecStretch DD
	dwReserved1 DD
	dwReserved2 DD
	dwReserved3 DD
ENDS

DDCAPS_DX3 STRUCT
	dwSize DD
	dwCaps DD
	dwCaps2 DD
	dwCKeyCaps DD
	dwFXCaps DD
	dwFXAlphaCaps DD
	dwPalCaps DD
	dwSVCaps DD
	dwAlphaBltConstBitDepths DD
	dwAlphaBltPixelBitDepths DD
	dwAlphaBltSurfaceBitDepths DD
	dwAlphaOverlayConstBitDepths DD
	dwAlphaOverlayPixelBitDepths DD
	dwAlphaOverlaySurfaceBitDepths DD
	dwZBufferBitDepths DD
	dwVidMemTotal DD
	dwVidMemFree DD
	dwMaxVisibleOverlays DD
	dwCurrVisibleOverlays DD
	dwNumFourCCCodes DD
	dwAlignBoundarySrc DD
	dwAlignSizeSrc DD
	dwAlignBoundaryDest DD
	dwAlignSizeDest DD
	dwAlignStrideAlign DD
	dwRops DD DD_ROP_SPACE DUP (?)
	ddsCaps DDSCAPS <>
	dwMinOverlayStretch DD
	dwMaxOverlayStretch DD
	dwMinLiveVideoStretch DD
	dwMaxLiveVideoStretch DD
	dwMinHwCodecStretch DD
	dwMaxHwCodecStretch DD
	dwReserved1 DD
	dwReserved2 DD
	dwReserved3 DD
	dwSVBCaps DD
	dwSVBCKeyCaps DD
	dwSVBFXCaps DD
	dwSVBRops DD DD_ROP_SPACE DUP (?)
	dwVSBCaps DD
	dwVSBCKeyCaps DD
	dwVSBFXCaps DD
	dwVSBRops DD DD_ROP_SPACE DUP (?)
	dwSSBCaps DD
	dwSSBCKeyCaps DD
	dwSSBFXCaps DD
	dwSSBRops DD DD_ROP_SPACE DUP (?)
	dwReserved4 DD
	dwReserved5 DD
	dwReserved6 DD
ENDS

DDCAPS_DX5 STRUCT
	dwSize DD
	dwCaps DD
	dwCaps2 DD
	dwCKeyCaps DD
	dwFXCaps DD
	dwFXAlphaCaps DD
	dwPalCaps DD
	dwSVCaps DD
	dwAlphaBltConstBitDepths DD
	dwAlphaBltPixelBitDepths DD
	dwAlphaBltSurfaceBitDepths DD
	dwAlphaOverlayConstBitDepths DD
	dwAlphaOverlayPixelBitDepths DD
	dwAlphaOverlaySurfaceBitDepths DD
	dwZBufferBitDepths DD
	dwVidMemTotal DD
	dwVidMemFree DD
	dwMaxVisibleOverlays DD
	dwCurrVisibleOverlays DD
	dwNumFourCCCodes DD
	dwAlignBoundarySrc DD
	dwAlignSizeSrc DD
	dwAlignBoundaryDest DD
	dwAlignSizeDest DD
	dwAlignStrideAlign DD
	dwRops DD DD_ROP_SPACE DUP (?)
	ddsCaps DDSCAPS <>
	dwMinOverlayStretch DD
	dwMaxOverlayStretch DD
	dwMinLiveVideoStretch DD
	dwMaxLiveVideoStretch DD
	dwMinHwCodecStretch DD
	dwMaxHwCodecStretch DD
	dwReserved1 DD
	dwReserved2 DD
	dwReserved3 DD
	dwSVBCaps DD
	dwSVBCKeyCaps DD
	dwSVBFXCaps DD
	dwSVBRops DD DD_ROP_SPACE DUP (?)
	dwVSBCaps DD
	dwVSBCKeyCaps DD
	dwVSBFXCaps DD
	dwVSBRops DD DD_ROP_SPACE DUP (?)
	dwSSBCaps DD
	dwSSBCKeyCaps DD
	dwSSBFXCaps DD
	dwSSBRops DD DD_ROP_SPACE DUP (?)
	dwMaxVideoPorts DD
	dwCurrVideoPorts DD
	dwSVBCaps2 DD
	dwNLVBCaps DD
	dwNLVBCaps2 DD
	dwNLVBCKeyCaps DD
	dwNLVBFXCaps DD
	dwNLVBRops DD DD_ROP_SPACE DUP (?)
ENDS

DDCAPS_DX6 STRUCT
	dwSize DD
	dwCaps DD
	dwCaps2 DD
	dwCKeyCaps DD
	dwFXCaps DD
	dwFXAlphaCaps DD
	dwPalCaps DD
	dwSVCaps DD
	dwAlphaBltConstBitDepths DD
	dwAlphaBltPixelBitDepths DD
	dwAlphaBltSurfaceBitDepths DD
	dwAlphaOverlayConstBitDepths DD
	dwAlphaOverlayPixelBitDepths DD
	dwAlphaOverlaySurfaceBitDepths DD
	dwZBufferBitDepths DD
	dwVidMemTotal DD
	dwVidMemFree DD
	dwMaxVisibleOverlays DD
	dwCurrVisibleOverlays DD
	dwNumFourCCCodes DD
	dwAlignBoundarySrc DD
	dwAlignSizeSrc DD
	dwAlignBoundaryDest DD
	dwAlignSizeDest DD
	dwAlignStrideAlign DD
	dwRops DD DD_ROP_SPACE DUP (?)
	ddsOldCaps DDSCAPS
	dwMinOverlayStretch DD
	dwMaxOverlayStretch DD
	dwMinLiveVideoStretch DD
	dwMaxLiveVideoStretch DD
	dwMinHwCodecStretch DD
	dwMaxHwCodecStretch DD
	dwReserved1 DD
	dwReserved2 DD
	dwReserved3 DD
	dwSVBCaps DD
	dwSVBCKeyCaps DD
	dwSVBFXCaps DD
	dwSVBRops DD DD_ROP_SPACE DUP (?)
	dwVSBCaps DD
	dwVSBCKeyCaps DD
	dwVSBFXCaps DD
	dwVSBRops DD DD_ROP_SPACE DUP (?)
	dwSSBCaps DD
	dwSSBCKeyCaps DD
	dwSSBFXCaps DD
	dwSSBRops DD DD_ROP_SPACE DUP (?)
	dwMaxVideoPorts DD
	dwCurrVideoPorts DD
	dwSVBCaps2 DD
	dwNLVBCaps DD
	dwNLVBCaps2 DD
	dwNLVBCKeyCaps DD
	dwNLVBFXCaps DD
	dwNLVBRops DD DD_ROP_SPACE DUP (?)
	ddsCaps DDSCAPS2
ENDS

DDCAPS_DX7 STRUCT
	dwSize DD
	dwCaps DD
	dwCaps2 DD
	dwCKeyCaps DD
	dwFXCaps DD
	dwFXAlphaCaps DD
	dwPalCaps DD
	dwSVCaps DD
	dwAlphaBltConstBitDepths DD
	dwAlphaBltPixelBitDepths DD
	dwAlphaBltSurfaceBitDepths DD
	dwAlphaOverlayConstBitDepths DD
	dwAlphaOverlayPixelBitDepths DD
	dwAlphaOverlaySurfaceBitDepths DD
	dwZBufferBitDepths DD
	dwVidMemTotal DD
	dwVidMemFree DD
	dwMaxVisibleOverlays DD
	dwCurrVisibleOverlays DD
	dwNumFourCCCodes DD
	dwAlignBoundarySrc DD
	dwAlignSizeSrc DD
	dwAlignBoundaryDest DD
	dwAlignSizeDest DD
	dwAlignStrideAlign DD
	dwRops DD DD_ROP_SPACE DUP (?)
	ddsOldCaps DDSCAPS
	dwMinOverlayStretch DD
	dwMaxOverlayStretch DD
	dwMinLiveVideoStretch DD
	dwMaxLiveVideoStretch DD
	dwMinHwCodecStretch DD
	dwMaxHwCodecStretch DD
	dwReserved1 DD
	dwReserved2 DD
	dwReserved3 DD
	dwSVBCaps DD
	dwSVBCKeyCaps DD
	dwSVBFXCaps DD
	dwSVBRops DD DD_ROP_SPACE DUP (?)
	dwVSBCaps DD
	dwVSBCKeyCaps DD
	dwVSBFXCaps DD
	dwVSBRops DD DD_ROP_SPACE DUP (?)
	dwSSBCaps DD
	dwSSBCKeyCaps DD
	dwSSBFXCaps DD
	dwSSBRops DD DD_ROP_SPACE DUP (?)
	dwMaxVideoPorts DD
	dwCurrVideoPorts DD
	dwSVBCaps2 DD
	dwNLVBCaps DD
	dwNLVBCaps2 DD
	dwNLVBCKeyCaps DD
	dwNLVBFXCaps DD
	dwNLVBRops DD DD_ROP_SPACE DUP (?)
	ddsCaps DDSCAPS2
ENDS

#if DIRECTDRAW_VERSION <= 0x300
	#define DDCAPS DDCAPS_DX3
#elseif DIRECTDRAW_VERSION <= 0x500
	#define DDCAPS DDCAPS_DX5
#elseif DIRECTDRAW_VERSION <= 0x600
	#define DDCAPS DDCAPS_DX6
#else
	#define DDCAPS DDCAPS_DX7
#endif

DDPIXELFORMAT STRUCT
	dwSize DD
	dwFlags DD
	dwFourCC DD
	UNION
		dwRGBBitCount DD
		dwYUVBitCount DD
		dwZBufferBitDepth DD
		dwAlphaBitDepth DD
		dwLuminanceBitCount DD
		dwBumpBitCount DD
	ENDUNION
	UNION
		dwRBitMask DD
		dwYBitMask DD
		dwStencilBitDepth DD
		dwLuminanceBitMask DD
		dwBumpDuBitMask DD
	ENDUNION
	UNION
		dwGBitMask DD
		dwUBitMask DD
		dwZBitMask DD
		dwBumpDvBitMask DD
	ENDUNION
	UNION
		dwBBitMask DD
		dwVBitMask DD
		dwStencilBitMask DD
		dwBumpLuminanceBitMask DD
	ENDUNION
	UNION
		dwRGBAlphaBitMask DD
		dwYUVAlphaBitMask DD
		dwLuminanceAlphaBitMask DD
		dwRGBZBitMask DD
		dwYUVZBitMask DD
	ENDUNION
ENDS

DDOVERLAYFX STRUCT
	dwSize DD
	dwAlphaEdgeBlendBitDepth DD
	dwAlphaEdgeBlend DD
	dwReserved DD
	dwAlphaDestConstBitDepth DD
	UNION
		dwAlphaDestConst DD
		lpDDSAlphaDest DD
	ENDUNION
	dwAlphaSrcConstBitDepth DD
	UNION
		dwAlphaSrcConst DD
		lpDDSAlphaSrc DD
	ENDUNION
	dckDestColorkey DDCOLORKEY <>
	dckSrcColorkey DDCOLORKEY <>
	dwDDFX DD
	dwFlags DD
ENDS

DDBLTBATCH STRUCT
	lprDest DD
	lpDDSSrc DD
	lprSrc DD
	dwFlags DD
	lpDDBltFx DD
ENDS

DDGAMMARAMP STRUCT
	red DW 256 DUP (?)
	green DW 256 DUP (?)
	blue DW 256 DUP (?)
ENDS

DDDEVICEIDENTIFIER STRUCT
	szDriver DB MAX_DDDEVICEID_STRING DUP (?)
	szDescription DB MAX_DDDEVICEID_STRING DUP (?)
	liDriverVersion DQ
	dwVendorId DD
	dwDeviceId DD
	dwSubSysId DD
	dwRevision DD
	guidDeviceIdentifier GUID <>
ENDS

DDDEVICEIDENTIFIER2 STRUCT
	szDriver DB MAX_DDDEVICEID_STRING DUP (?)
	szDescription DB MAX_DDDEVICEID_STRING DUP (?)
	liDriverVersion DQ
	dwVendorId DD
	dwDeviceId DD
	dwSubSysId DD
	dwRevision DD
	guidDeviceIdentifier GUID <>
	dwWHQLLevel DD
ENDS

IDirectDraw STRUCT
	IUnknown Unknown <>
	Compact DD
	CreateClipper DD
	CreatePalette DD
	CreateSurface DD
	DuplicateSurface DD
	EnumDisplayModes DD
	EnumSurfaces DD
	FlipToGDISurface DD
	GetCaps DD
	GetDisplayMode DD
	GetFourCCCodes DD
	GetGDISurface DD
	GetMonitorFrequency DD
	GetScanLine DD
	GetVerticalBlankStatus DD
	Initialize DD
	RestoreDisplayMode DD
	SetCooperativeLevel DD
	SetDisplayMode DD
	WaitForVerticalBlank DD
ENDS

IDirectDraw2 STRUCT
	IUnknown Unknown <>
	Compact DD
	CreateClipper DD
	CreatePalette DD
	CreateSurface DD
	DuplicateSurface DD
	EnumDisplayModes DD
	EnumSurfaces DD
	FlipToGDISurface DD
	GetCaps DD
	GetDisplayMode DD
	GetFourCCCodes DD
	GetGDISurface DD
	GetMonitorFrequency DD
	GetScanLine DD
	GetVerticalBlankStatus DD
	Initialize DD
	RestoreDisplayMode DD
	SetCooperativeLevel DD
	SetDisplayMode DD
	WaitForVerticalBlank DD
	GetAvailableVidMem DD
ENDS

IDirectDraw4 STRUCT
	IUnknown Unknown <>
	Compact DD
	CreateClipper DD
	CreatePalette DD
	CreateSurface DD
	DuplicateSurface DD
	EnumDisplayModes DD
	EnumSurfaces DD
	FlipToGDISurface DD
	GetCaps DD
	GetDisplayMode DD
	GetFourCCCodes DD
	GetGDISurface DD
	GetMonitorFrequency DD
	GetScanLine DD
	GetVerticalBlankStatus DD
	Initialize DD
	RestoreDisplayMode DD
	SetCooperativeLevel DD
	SetDisplayMode DD
	WaitForVerticalBlank DD
	GetAvailableVidMem DD
	GetSurfaceFromDC DD
	RestoreAllSurfaces DD
	TestCooperativeLevel DD
	GetDeviceIdentifier DD
ENDS

IDirectDraw7
	IUnknown Unknown <>
	Compact DD
	CreateClipper DD
	CreatePalette DD
	CreateSurface DD
	DuplicateSurface DD
	EnumDisplayModes DD
	EnumSurfaces DD
	FlipToGDISurface DD
	GetCaps DD
	GetDisplayMode DD
	GetFourCCCodes DD
	GetGDISurface DD
	GetMonitorFrequency DD
	GetScanLine DD
	GetVerticalBlankStatus DD
	Initialize DD
	RestoreDisplayMode DD
	SetCooperativeLevel DD
	SetDisplayMode DD
	WaitForVerticalBlank DD
	GetAvailableVidMem DD
	GetSurfaceFromDC DD
	RestoreAllSurfaces DD
	TestCooperativeLevel DD
	GetDeviceIdentifier DD
	StartModeTest DD
	EvaluateMode DD
ENDS

IDirectDrawPalette STRUCT
	IUnknown Unknown <>
	GetCaps DD
	GetEntries DD
	Initialize DD
	SetEntries DD
ENDS

IDirectDrawClipper STRUCT
	IUnknown Unknown <>
	GetClipList DD
	GetHWnd DD
	Initialize DD
	IsClipListChanged DD
	SetClipList DD
	SetHWnd DD
ENDS

IDirectDrawSurface STRUCT
	IUnknown Unknown <>
	AddAttachedSurface DD
	AddOverlayDirtyRect DD
	Blt DD
	BltBatch DD
	BltFast DD
	DeleteAttachedSurface DD
	EnumAttachedSurfaces DD
	EnumOverlayZOrders DD
	Flip DD
	GetAttachedSurface DD
	GetBltStatus DD
	GetCaps DD
	GetClipper DD
	GetColorKey DD
	GetDC DD
	GetFlipStatus DD
	GetOverlayPosition DD
	GetPalette DD
	GetPixelFormat DD
	GetSurfaceDesc DD
	Initialize DD
	IsLost DD
	Lock DD
	ReleaseDC DD
	Restore DD
	SetClipper DD
	SetColorKey DD
	SetOverlayPosition DD
	SetPalette DD
	Unlock DD
	UpdateOverlay DD
	UpdateOverlayDisplay DD
	UpdateOverlayZOrder DD
ENDS

IDirectDrawSurface2 STRUCT
	IUnknown Unknown <>
	AddAttachedSurface DD
	AddOverlayDirtyRect DD
	Blt DD
	BltBatch DD
	BltFast DD
	DeleteAttachedSurface DD
	EnumAttachedSurfaces DD
	EnumOverlayZOrders DD
	Flip DD
	GetAttachedSurface DD
	GetBltStatus DD
	GetCaps DD
	GetClipper DD
	GetColorKey DD
	GetDC DD
	GetFlipStatus DD
	GetOverlayPosition DD
	GetPalette DD
	GetPixelFormat DD
	GetSurfaceDesc DD
	Initialize DD
	IsLost DD
	Lock DD
	ReleaseDC DD
	Restore DD
	SetClipper DD
	SetColorKey DD
	SetOverlayPosition DD
	SetPalette DD
	Unlock DD
	UpdateOverlay DD
	UpdateOverlayDisplay DD
	UpdateOverlayZOrder DD
	GetDDInterface DD
	PageLock DD
	PageUnlock DD
ENDS

IDirectDrawSurface3 STRUCT
	IUnknown Unknown <>
	AddAttachedSurface DD
	AddOverlayDirtyRect DD
	Blt DD
	BltBatch DD
	BltFast DD
	DeleteAttachedSurface DD
	EnumAttachedSurfaces DD
	EnumOverlayZOrders DD
	Flip DD
	GetAttachedSurface DD
	GetBltStatus DD
	GetCaps DD
	GetClipper DD
	GetColorKey DD
	GetDC DD
	GetFlipStatus DD
	GetOverlayPosition DD
	GetPalette DD
	GetPixelFormat DD
	GetSurfaceDesc DD
	Initialize DD
	IsLost DD
	Lock DD
	ReleaseDC DD
	Restore DD
	SetClipper DD
	SetColorKey DD
	SetOverlayPosition DD
	SetPalette DD
	Unlock DD
	UpdateOverlay DD
	UpdateOverlayDisplay DD
	UpdateOverlayZOrder DD
	GetDDInterface DD
	PageLock DD
	PageUnlock DD
	SetSurfaceDesc DD
ENDS

IDirectDrawSurface4 STRUCT
	IUnknown Unknown <>
	AddAttachedSurface DD
	AddOverlayDirtyRect DD
	Blt DD
	BltBatch DD
	BltFast DD
	DeleteAttachedSurface DD
	EnumAttachedSurfaces DD
	EnumOverlayZOrders DD
	Flip DD
	GetAttachedSurface DD
	GetBltStatus DD
	GetCaps DD
	GetClipper DD
	GetColorKey DD
	GetDC DD
	GetFlipStatus DD
	GetOverlayPosition DD
	GetPalette DD
	GetPixelFormat DD
	GetSurfaceDesc DD
	Initialize DD
	IsLost DD
	Lock DD
	ReleaseDC DD
	Restore DD
	SetClipper DD
	SetColorKey DD
	SetOverlayPosition DD
	SetPalette DD
	Unlock DD
	UpdateOverlay DD
	UpdateOverlayDisplay DD
	UpdateOverlayZOrder DD
	GetDDInterface DD
	PageLock DD
	PageUnlock DD
	SetSurfaceDesc DD
	SetPrivateData DD
	GetPrivateData DD
	FreePrivateData DD
	GetUniquenessValue DD
	ChangeUniquenessValue DD
ENDS

IDirectDrawSurface7 STRUCT
	IUnknown Unknown <>
	AddAttachedSurface DD
	AddOverlayDirtyRect DD
	Blt DD
	BltBatch DD 
	BltFast DD
	DeleteAttachedSurface DD
	EnumAttachedSurfaces DD
	EnumOverlayZOrders DD
	Flip DD
	GetAttachedSurface DD
	GetBltStatus DD
	GetCaps DD
	GetClipper DD
	GetColorKey DD
	GetDC DD
	GetFlipStatus DD
	GetOverlayPosition DD
	GetPalette DD
	GetPixelFormat DD
	GetSurfaceDesc DD
	Initialize DD
	IsLost DD
	Lock DD
	ReleaseDC DD
	Restore DD
	SetClipper DD
	SetColorKey DD
	SetOverlayPosition DD
	SetPalette DD
	Unlock DD
	UpdateOverlay DD
	UpdateOverlayDisplay DD
	UpdateOverlayZOrder DD
	GetDDInterface DD
	PageLock DD
	PageUnlock DD
	SetSurfaceDesc DD
	SetPrivateData DD
	GetPrivateData DD
	FreePrivateData DD
	GetUniquenessValue DD
	ChangeUniquenessValue DD
	SetPriority DD
	GetPriority DD
	SetLOD DD
	GetLOD DD
ENDS

IDirectDrawColorControl STRUCT
	IUnknown Unknown <>
	GetColorControls DD
	SetColorControls DD
ENDS

IDirectDrawGammaControl STRUCT
	IUnknown Unknown <>
	GetGammaRamp DD
	SetGammaRamp DD
ENDS

DDSURFACEDESC STRUCT
	dwSize DD
	dwFlags DD
	dwHeight DD
	dwWidth DD
	UNION
		lPitch DD
		dwLinearSize DD
	ENDUNION
	dwBackBufferCount DD
	UNION
		dwMipMapCount DD
		dwZBufferBitDepth DD
		dwRefreshRate DD
	ENDUNION
	dwAlphaBitDepth DD
	dwReserved DD
	lpSurface DD
	ddckCKDestOverlay DDCOLORKEY <>
	ddckCKDestBlt DDCOLORKEY <>
	ddckCKSrcOverlay DDCOLORKEY <>
	ddckCKSrcBlt DDCOLORKEY <>
	ddpfPixelFormat DDPIXELFORMAT <>
	ddsCaps DDSCAPS <>
ENDS

DDSURFACEDESC2 STRUCT
	dwSize DD
	dwFlags DD
	dwHeight DD
	dwWidth DD
	UNION
		lPitch DD
		dwLinearSize DD
	ENDUNION
	dwBackBufferCount DD
	UNION
		dwMipMapCount DD
		dwRefreshRate DD
		dwSrcVBHandle DD
	ENDUNION
	dwAlphaBitDepth DD
	dwReserved DD
	lpSurface DD
	UNION
		ddckCKDestOverlay DDCOLORKEY <>
		dwEmptyFaceColor DD
	ENDUNION
	ddckCKDestBlt DDCOLORKEY <>
	ddckCKSrcOverlay DDCOLORKEY <>
	ddckCKSrcBlt DDCOLORKEY <>
	UNION
		ddpfPixelFormat DDPIXELFORMAT <>
		dwFVF DD
	ENDUNION
	ddsCaps DDSCAPS2 <>
	dwTextureStage DD
ENDS

DDOPTSURFACEDESC STRUCT
	dwSize DD
	dwFlags DD
	ddSCaps DDSCAPS2 <>
	ddOSCaps DDOSCAPS <>
	guid GUID <>
	dwCompressionRatio DD
ENDS

DDCOLORCONTROL STRUCT
	dwSize DD
	dwFlags DD
	lBrightness DD
	lContrast DD
	lHue DD
	lSaturation DD
	lSharpness DD
	lGamma DD
	lColorEnable DD
	dwReserved1 DD
ENDS

#if STRINGS UNICODE
	#define DirectDrawEnumerate  DirectDrawEnumerateW
	#define DirectDrawEnumerateEx  DirectDrawEnumerateExW
#else
	#define DirectDrawEnumerate  DirectDrawEnumerateA
	#define DirectDrawEnumerateEx  DirectDrawEnumerateExA
#endif

#endif // _DDRAW_H

