WinXP-2K_PageFile.vbs - Checks the current and peak usage, and allocated
size of the Windows Windows XP or Windows 2000 pagefile and optionally
log and/or show the results in a popup.
� Bill James - wgjames@mvps.org - Created 4 Nov 2002 - Revised 9 Nov 2002

The purpose of this script is to provide an easy way to monitor pagefile
usage, in order to optimize the settings without wasting hard drive space.
You should have a minimium size setting sufficient to cover your normal use
as determined using this script, plus ~20 MB, and a large maximum pagefile
limit (I recommend setting that equal to the space available on the pagefile
partition.  The key number to look for in the log file is "Session Peak Usage",
which may be smaller than "Current Pagefile Size" if the pagefile size has
shrunk from the largest session usage.  The following article by MVP Alex
Nichol is an excellent reference for additional information on Virtual Memory,
including setting the pagefile minimum: http://www.aumha.org/a/vmxp.htm

You can run this script manually during a Windows session, or if you have
Windows XP/2000 Pro I recommend adding it as a logoff script to log results
at the end of each Windows session.  To implement running the script at
logoff (also shutdown and restart) for Windows XP Pro or Windows 2000 Pro:
Click Start, Run, gpedit.msc.  Select User Configuration, Windows Settings,
Scripts.  In the right pane, select Logoff, Properties.  Click Add, Browse.
Browse to the location of this script and select it.  IMPORTANT: In the
"Script Parameters" box add "log" (no quotes) so the script will not show a
popup which would stall your shutdown sequence.  OK, Apply, OK.  (You may
want to first copy this script to the logoff folder and select it there)

If logging is enabled (default), the results are saved in My Documents folder
as PageFileLog.txt.

**********************************************************
Three optional settings are configurable within the script (right-click, Edit):
  WriteToFile - If set to True the information will be added to a log file in
    your 'My Documents' folder.  Of course, you want this if you are running
    at logoff, but you might not want it for manually checks.  Changing this
    to False disables logging.
  ShowPopup - If set to True then after the script runs a message box is
    presented with the results.  This might not be desirable when
    automatically running the script at logoff.  False disables popup.
  DisplaySeconds - The number of seconds that the results popup will
    display.  Setting this to 0 (zero) will cause the popup to remain until
    acknowledged.

To set these options, right-click the script and select Edit.  Look for these
lines starting on line ~34:

WriteToFile = True    'Options: True, False
ShowPopup = True      'Options: True, False
DisplaySeconds = 0    '0 (zero) to force OK
**********************************************************

**********************************************************
You can also set the options using arguments:
Syntax:  [path]scriptname [log] [rpt] [t:sec]
  log - add results to the logfile
  rpt - show results in popup
  t:seconds - controls how long the popup message will display

Example: "WinXP-2K_PageFile.vbs rpt t:5" - show popup for 5 seconds, no log.
Example: "WinXP-2K_PageFile.vbs log" - log the results, no popup.
Example: "WinXP-2K_PageFile.vbs log rpt t:10" - log and 10 second popup.

NOTE: If ANY arguments are used, all hardcoded variables are set to
false or 0, so you must specifically set which options you want.

To use these options, create a shortcut to the script and add the arguments
there, or the arguments can be used running the script from command line.
**********************************************************

**********************************************************
The DesktopShortcutHelper.vbs script can be used for easily creating Desktop
shortcuts to run WinXP-2K_PageFile.vbs in Report Only Mode (popup but no
logging, run in Logging Mode (popup and write to log), and a shortcut to
view the log file.  There is a prompt for creating each of these.
**********************************************************

