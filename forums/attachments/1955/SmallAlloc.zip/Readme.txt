ultrano@mail.bg  / ultrano@ultranos.com

SmallAlloc  - a complete memory manager for allocating _many_  _small_ objects, usually of the same size. 
When is this useful? When you have one or several structs, and you'll define hundreds, thousands of them. And with easy adjustments, - MILLIONS of such objects!

Available sizes of the allocated objects are 1..8192 bytes. Objects are grouped by their size, at least one 64kB page per such a group is allocated.

64kB pages are perfect for most cases, but if you want maximum speed of allocation while having millions of tiny objects, you should change the pagesize. 


Do not use SmallAlloc for strings of arbitrary length, unless you use some fixed size for strings (like 256 bytes, or 17 bytes). 

Now SmallAlloc is also thread-safe. Enabling this is done via one lock. 