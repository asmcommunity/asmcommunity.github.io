Masked Edit Lib:
----------------
Source by Jaymeson Trudgen, (NaN).


This lib was written to subclass any edit window control and provide
added masks to limit user input to only selected fields.


Here are the breakdown for the API like fucntions:

1) ConvertToMask( hEdit )

	You must call this to subclass and initialize the the control
	for masked input.  You can call this on any number of Edit
	controls.

2) SetEditMask( hEdit, lpSzMask )

	This is to set the mask for the subclassed control. There is
	no default mask, so you must provide at least one mask following
	a controls conversion to masked edit.

	Masked chars are : 	?  -  Case insensitive character
				#  -  Numeric character

3) GetEditMask( hEdit )
	
	This will return the full string of the Mask it currently
	has stored within the control in EAX.

4) SetEditText( hEdit, lpSzText )

	This is set the masked edit control's data value according
	to the mask it has in memory.  The provided string to set
	with must be in condensed form.  That is it should only
	have the number of chars and numbers required to fill the
	mask fields. For example:

	Mask = "Hello ?.?. my favorite number is ###"

	lpSzText = "JT314"

	The displayed string in the control will be:
	
	"Hello J.T. my favrite number is 314"

5) GetEditText( hEdit )
	
	Inverse to SetEditText, this will return in EAX a string
	pointer to a string that is in condensed form, ignoring
	all non-masked chars.

6) IsFieldsFull( hEdit )

	This is used to check and see if the masked edit control
	has been filled entirely, leaving no fields blank "_".
	It will return true if its fully satisfied according to its
	mask, otherwise it will return FALSE.


This is all there is to it! I hope you make good use of it.

Visit the Win32Asm community:

	http://board.win32asmcommunity.net/

Regards,
NaN