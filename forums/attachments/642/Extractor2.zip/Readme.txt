Many thanks to Chetnik for his original pe-mem demo
