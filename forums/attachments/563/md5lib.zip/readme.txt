MD5 Library Readme

  Greg Hoyer, aka iblis.  7-20-2003


  I wrote this library with size in mind.  The size of the code and data for the
main non-utility procedures totals 510 bytes.  If you make use of all procedures
the size comes to 598 bytes.  I'm not  exactly sure how good or bad that is, but
by comparison  to other MD5 libraries  out there it's pretty  small.   This size
reduction is accomplished first by using  MD5_Startup to generate the sine table
at runtime.   Then  the block transform  is greatly  reduced by  stuffing all 64
different transformations into  one loop.  And then, of  course, it's written in
assembly, which accounts for most of its compact size.


  C/C++ usage:
  ------------
  Link your project with MD5.lib and include MD5.h in your source.

  Usage is very similar to most MD5 hashing libraries.  However before you can
  do anything, you must initialize the sine table by calling MD5_Startup().

  Create a temporary MD5CTXT structure and pass it to the MD5_Init() routine.

  Call MD5_Read, passing a pointer to your initialized MD5CTXT structure and a
  pointer to the data to read in.  This can be done as many times as necessary
  until all the data has been read.

  Call MD5_Digest, passing a pointer to the MD5CTXT structure and a pointer to
  a MD5HASH structure.  On return, the MD5HASH structure will contain the MD5
  hash.

  Use the MD5_Compare function to compare two MD5 hashes.

  To convert the MD5 hash to a string, use the MD52String function, passing
  a pointer to the MD5HASH structure and a pointer to a buffer at least 33
  characters in length.

    Example:
    ...
    {
      MD5CTXT ctxt;
      MD5HASH hash;
      char str[33]; /* use wchar_t for unicode */
      char data[3] = { 'a', 'b', 'c' };

      MD5_Startup();
      MD5_Init( &ctxt );
      MD5_Read( &ctxt, data, 3 );
      MD5_Digest( &ctxt, &hash );
      MD52String( &hash, str, true );
      printf( "MD5(\"abc\") = %s\n", str );
      /* prints 900150983CD24FB0D6963F7D28E17F72 */
    }


  MASM usage:
  -----------
  See C/C++ usage for relative notes.

    Example:
    .data?
      ctxt MD5CTXT <>
      hash MD5HASH <>
      strn db 33 dup(?)  ; use dw for unicode
    .data
      bdata db "abc"
    .code
      ...
      invoke MD5_Startup
      invoke MD5_init, offset ctxt
      invoke MD5_Read, offset ctxt, offset bdata, 3
      invoke MD5_Digest, offset ctxt, offset hash
      invoke MD52String, offset hash, offset strn, 1
      ; strn = "900150983CD24FB0D6963F7D28E17F72"



  Legal Stuff:
  ------------
  Eh, I don't care.  Do with this library what you want.  Change my
  name, even, if it makes you feel better.  ;)