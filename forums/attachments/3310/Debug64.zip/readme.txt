Try/EndTry - No parameters. Will print exception info if one occurs between the two macros
PrintDec - (Num) - Will print a qword in decimal notation, will accept a register, memory location or immediate value
PrintHex - (Num) - Will print a qword in hex notation, will accept a register, memory location or immediate value
PrintDouble - (Num) - Will print a double precision value, will accept a register, memory location (no immediate value)
PrintFloat - (Num) - Will print a single precision value, will accept a register, memory location or immediate value
PrintString - (Label) Prints a string variable
PrintStringByAddr - (Addr) Prints a string pointed to by Addr
PrintText - ("Str") Prints an immediate quoted string
PrintError - No parameters. Prints the last error message
PrintOleError - (Erno) Prints the system defined message identified by Erno
DumpMem - (pStart, nLength) Dumps a hex representation of memory beginning at pStart for nLength bytes
DumpFPU - No parameters - Displays the contents of the FPU
DumpMMX - No parameters - Displays the contents of the MMX registers
DumpEFlags - No parameters - Displays the contents of the EFlag register
Disassemble(pTarget,nLines) - Disassembles nLines of code beginning at pTarget
Spy - (SPY_TYPE_XXX,Var) - Single steps a block of code displaying Var on each step. SPY_TYPE_XXX is one of the constants below. If using one of the SPY_TYPE_REGxx types do not include a second parameter
StopSpy - No Parameters - Stops spying a variable
DumpSymbols - No Parameters - Dumps the symbol table


SPY_TYPE_FLOAT = 0
SPY_TYPE_DOUBLE = 1
SPY_TYPE_QWORD = 2
SPY_TYPE_DWORD = 3
SPY_TYPE_QWORDHEX = 4
SPY_TYPE_DWORDHEX = 5
SPY_TYPE_STRING = 6
SPY_TYPE_REGRAX = 7
SPY_TYPE_REGRBX = 8
SPY_TYPE_REGRCX = 9
SPY_TYPE_REGRDX = 10
SPY_TYPE_REGRSI = 11
SPY_TYPE_REGRDI = 12
SPY_TYPE_REGRSP = 13
SPY_TYPE_REGRBP = 14
SPY_TYPE_REGR8 = 15
SPY_TYPE_REGR9 = 16
SPY_TYPE_REGR10 = 17
SPY_TYPE_REGR11 = 18
SPY_TYPE_REGR12 = 19
SPY_TYPE_REGR13 = 20
SPY_TYPE_REGR14 = 21
SPY_TYPE_REGR15 = 22

These are macros and so do not use them with invoke, for example:

PrintText("Hello")

To use them add the following to your code (change the path to match your system)

#define DBG64LIB C:\RadASM30\GoAsm\dbg\Debug64.lib
#include C:\RadASM30\GoAsm\dbg\Debug64.a