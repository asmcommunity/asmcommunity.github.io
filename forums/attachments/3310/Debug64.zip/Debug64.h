// Headers available at
// http://www.quickersoft.com/donkey/index.html

// NOTE: INCLUDE Environment variable must be set to headers path

#DEFINE WINVER NTDDI_WINXP
#DEFINE FILTERAPI
#DEFINE WIN64

#DEFINE LINKFILES
#DEFINE LINKVCRT

#DEFINE CCUSEORDINALS

#include "WINDOWS.H"
#include "Commctrl.h"
#include "macros.h"
#include Radasm\addins.h
#include "DbgEng.h"
#include "psapi.h"
#include "DbgHelp.h"
#include "imagehlp.h"
#include "shlwapi.h"