extern int sum(int x , int y);
extern "C" int __cdecl testsumator(void);

class SUMATOR
{
	private:
		int sum(int x , int y);
	public:
		SUMATOR(){};
		~SUMATOR(){};
};

int testsumator(void)
{
SUMATOR s;
return sum(10,20);
}


