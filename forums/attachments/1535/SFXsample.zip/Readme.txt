Decomp.exe : SFX archive coded with Jeremy Collake's JCALG1 compression library
	       The library is available from:
	       http://www.collakesoftware.com

Run the SFX archive decomp.exe and it will output the file test.exe