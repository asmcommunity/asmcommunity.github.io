\pellesc\bin\podump /EXPORTS fwdfuncs.dll

Dump of fwdfuncs.dll

File type: DLL

	Exported symbols for fwdfuncs.dll

	       0 characteristics
	4521099F timestamp (Mon Oct  2 15:44:15 2006)
	    0.00 version
	       1 ordinal base
	       3 number of functions
	       3 number of names

	address     ord  index  name
	10002057      1      0  Cls (forwarded to Console.ClearScreen)
	10002072      2      1  ConOut (forwarded to Console.StdOut)
	1000100C      3      2  szUpper

SUMMARY
    1000 .rdata
    1000 .reloc
    1000 .text
