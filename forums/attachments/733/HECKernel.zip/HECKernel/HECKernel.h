

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 6.00.0361 */
/* at Wed Jul 06 08:27:35 2005
 */
/* Compiler settings for HECKernel.idl:
    Oicf, W1, Zp8, env=Win32 (32b run)
    protocol : dce , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
//@@MIDL_FILE_HEADING(  )

#pragma warning( disable: 4049 )  /* more than 64k source lines */


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 475
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __HECKernel_h__
#define __HECKernel_h__

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

/* Forward Declarations */ 

#ifndef __IHEC_Designer_FWD_DEFINED__
#define __IHEC_Designer_FWD_DEFINED__
typedef interface IHEC_Designer IHEC_Designer;
#endif 	/* __IHEC_Designer_FWD_DEFINED__ */


#ifndef __HEC_Designer_FWD_DEFINED__
#define __HEC_Designer_FWD_DEFINED__

#ifdef __cplusplus
typedef class HEC_Designer HEC_Designer;
#else
typedef struct HEC_Designer HEC_Designer;
#endif /* __cplusplus */

#endif 	/* __HEC_Designer_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

#ifdef __cplusplus
extern "C"{
#endif 

void * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void * ); 

#ifndef __IHEC_Designer_INTERFACE_DEFINED__
#define __IHEC_Designer_INTERFACE_DEFINED__

/* interface IHEC_Designer */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IHEC_Designer;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("971E5760-9186-4dae-A728-DEFEAD34D0FD")
    IHEC_Designer : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Attach( 
            IUnknown *pDoc) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE AttachDiv( 
            IUnknown *pDiv) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Detach( void) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IHEC_DesignerVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IHEC_Designer * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IHEC_Designer * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IHEC_Designer * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IHEC_Designer * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IHEC_Designer * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IHEC_Designer * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IHEC_Designer * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Attach )( 
            IHEC_Designer * This,
            IUnknown *pDoc);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *AttachDiv )( 
            IHEC_Designer * This,
            IUnknown *pDiv);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Detach )( 
            IHEC_Designer * This);
        
        END_INTERFACE
    } IHEC_DesignerVtbl;

    interface IHEC_Designer
    {
        CONST_VTBL struct IHEC_DesignerVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IHEC_Designer_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IHEC_Designer_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IHEC_Designer_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IHEC_Designer_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IHEC_Designer_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IHEC_Designer_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IHEC_Designer_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IHEC_Designer_Attach(This,pDoc)	\
    (This)->lpVtbl -> Attach(This,pDoc)

#define IHEC_Designer_AttachDiv(This,pDiv)	\
    (This)->lpVtbl -> AttachDiv(This,pDiv)

#define IHEC_Designer_Detach(This)	\
    (This)->lpVtbl -> Detach(This)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IHEC_Designer_Attach_Proxy( 
    IHEC_Designer * This,
    IUnknown *pDoc);


void __RPC_STUB IHEC_Designer_Attach_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IHEC_Designer_AttachDiv_Proxy( 
    IHEC_Designer * This,
    IUnknown *pDiv);


void __RPC_STUB IHEC_Designer_AttachDiv_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IHEC_Designer_Detach_Proxy( 
    IHEC_Designer * This);


void __RPC_STUB IHEC_Designer_Detach_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IHEC_Designer_INTERFACE_DEFINED__ */



#ifndef __HECKernelLib_LIBRARY_DEFINED__
#define __HECKernelLib_LIBRARY_DEFINED__

/* library HECKernelLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_HECKernelLib;

EXTERN_C const CLSID CLSID_HEC_Designer;

#ifdef __cplusplus

class DECLSPEC_UUID("18D2B8E7-103D-40ea-BE63-34706BD73476")
HEC_Designer;
#endif
#endif /* __HECKernelLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


