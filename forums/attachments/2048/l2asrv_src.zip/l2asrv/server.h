// server.h: interface for the server class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(_server_H_)
#define _server_H_

#if defined(__GNUG__) && !defined(__APPLE__)
    #pragma interface "server.h"
#endif

#include "tcpsocket.h"
#include "mwWorkThread.h"

class server : public mwWorkThread
{
public:
	bool Create(int port, int lport, int protocol, wxUint32 address);
	void SetHandler(wxEvtHandler *handler) { m_handler = handler; }
	server();
	virtual ~server();

	virtual void run();

protected:

private:
	int m_port;
	int m_protocol;
	wxUint32 m_address;
	wxEvtHandler *m_handler;

	TCPSocket m_sock;
};

#endif
