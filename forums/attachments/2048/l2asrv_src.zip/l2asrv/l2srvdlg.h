#ifndef _L2SRVDLG_H_
#define _L2SRVDLG_H_

#if defined(__GNUG__) && !defined(__APPLE__)
#pragma interface "l2srvdlg.cpp"
#endif

/*!
 * Includes
 */

////@begin includes
////@end includes

/*!
 * Forward declarations
 */

////@begin forward declarations
////@end forward declarations

/*!
 * Control identifiers
 */

////@begin control identifiers
#define ID_DIALOG 10003
#define SYMBOL_L2SRVDLG_STYLE wxCAPTION|wxRESIZE_BORDER|wxSYSTEM_MENU|wxCLOSE_BOX|wxMINIMIZE_BOX|wxMAXIMIZE_BOX
#define SYMBOL_L2SRVDLG_TITLE _("L2Walker")
#define SYMBOL_L2SRVDLG_IDNAME ID_DIALOG
#define SYMBOL_L2SRVDLG_SIZE wxSize(400, 300)
#define SYMBOL_L2SRVDLG_POSITION wxDefaultPosition
#define ID_TEXTCTRL1 10006
////@end control identifiers

/*!
 * Compatibility
 */

#ifndef wxCLOSE_BOX
#define wxCLOSE_BOX 0x1000
#endif
#ifndef wxFIXED_MINSIZE
#define wxFIXED_MINSIZE 0
#endif

/*!
 * l2srvdlg class declaration
 */

class server;
#define server_num 4

class l2srvdlg: public wxDialog
{    
    DECLARE_DYNAMIC_CLASS( l2srvdlg )
    DECLARE_EVENT_TABLE()

public:
    /// Constructors
    l2srvdlg( );
    l2srvdlg( wxWindow* parent, wxWindowID id = SYMBOL_L2SRVDLG_IDNAME, const wxString& caption = SYMBOL_L2SRVDLG_TITLE, const wxPoint& pos = SYMBOL_L2SRVDLG_POSITION, const wxSize& size = SYMBOL_L2SRVDLG_SIZE, long style = SYMBOL_L2SRVDLG_STYLE );

	virtual ~l2srvdlg();

    /// Creation
    bool Create( wxWindow* parent, wxWindowID id = SYMBOL_L2SRVDLG_IDNAME, const wxString& caption = SYMBOL_L2SRVDLG_TITLE, const wxPoint& pos = SYMBOL_L2SRVDLG_POSITION, const wxSize& size = SYMBOL_L2SRVDLG_SIZE, long style = SYMBOL_L2SRVDLG_STYLE );

    /// Creates the controls and sizers
    void CreateControls();

	void OnUserInfo( wxCommandEvent& event );

////@begin l2srvdlg event handler declarations

////@end l2srvdlg event handler declarations

////@begin l2srvdlg member function declarations

    /// Retrieves bitmap resources
    wxBitmap GetBitmapResource( const wxString& name );

    /// Retrieves icon resources
    wxIcon GetIconResource( const wxString& name );
////@end l2srvdlg member function declarations

    /// Should we show tooltips?
    static bool ShowToolTips();

    void OnCloseWindow( wxCloseEvent& event );

////@begin l2srvdlg member variables
    wxTextCtrl* m_logCtl;
////@end l2srvdlg member variables
private:
	int m_port;
	int m_protocol;
	wxUint32 m_address;
	server *m_servers[server_num];
};

#endif
    // _L2SRVDLG_H_
