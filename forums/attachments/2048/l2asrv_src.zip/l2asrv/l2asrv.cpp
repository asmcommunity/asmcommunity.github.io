/////////////////////////////////////////////////////////////////////////////
// Name:        L2ASrv.cpp
// Purpose:     
// Author:      
// Modified by: 
// Created:     05/30/05 19:30:50
// RCS-ID:      
// Copyright:   
// Licence:     
/////////////////////////////////////////////////////////////////////////////

#if defined(__GNUG__) && !defined(__APPLE__)
#pragma implementation "L2ASrv.h"
#endif

// For compilers that support precompilation, includes "wx/wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
#pragma hdrstop
#endif

#ifndef WX_PRECOMP
#include "wx/wx.h"
#endif

#include <wx/filename.h>

////@begin includes
////@end includes

#include "L2ASrv.h"
#include "l2srvdlg.h"

////@begin XPM images
////@end XPM images

/*!
 * Application instance implementation
 */

////@begin implement app
IMPLEMENT_APP( L2ASrvApp )
////@end implement app

/*!
 * L2ASrvApp type definition
 */

IMPLEMENT_CLASS( L2ASrvApp, wxApp )

/*!
 * L2ASrvApp event table definition
 */

BEGIN_EVENT_TABLE( L2ASrvApp, wxApp )

////@begin L2ASrvApp event table entries
////@end L2ASrvApp event table entries

END_EVENT_TABLE()

/*!
 * Constructor for L2ASrvApp
 */

L2ASrvApp::L2ASrvApp()
{
////@begin L2ASrvApp member initialisation
////@end L2ASrvApp member initialisation
}

/*!
 * Initialisation for L2ASrvApp
 */

bool L2ASrvApp::OnInit()
{    
#if defined(__WXMSW__)
    WSADATA wsa;
	if ( WSAStartup(MAKEWORD(2, 2), &wsa) != 0 ) {
		wxLogError(wxT("WSAStartup failed!"));
		return FALSE;
	}
#endif
#if wxUSE_XPM
    wxImage::AddHandler( new wxXPMHandler );
#endif
#if wxUSE_LIBPNG
    wxImage::AddHandler( new wxPNGHandler );
#endif
#if wxUSE_LIBJPEG
    wxImage::AddHandler( new wxJPEGHandler );
#endif
#if wxUSE_GIF
    wxImage::AddHandler( new wxGIFHandler );
#endif

	l2srvdlg* mainWindow = new l2srvdlg();

	if (!mainWindow->Create(NULL))
		return false;

	mainWindow->Show(true);

    return true;
}

/*!
 * Cleanup for L2ASrvApp
 */
int L2ASrvApp::OnExit()
{    
#if defined(__WXMSW__)
	WSACleanup();
#endif
    return wxApp::OnExit();
}

