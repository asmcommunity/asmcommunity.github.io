#ifdef __GNUG__
    #pragma implementation "client.h"
#endif

// For compilers that support precompilation, includes "wx/wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

// for all others, include the necessary headers (this file is usually all you
// need because it includes almost all "standard" wxWindows headers)
#ifndef WX_PRECOMP
    #include "wx/wx.h"
#endif

//#define debugfile 1
//#define use_dat_file

#include "client.h"
#include "md5.h"

DEFINE_EVENT_TYPE(mwEVT_USER_INFO)

wxString iptos(u_long in)
{
	u_char *p;

	p = (u_char *)&in;
	return wxString::Format("%d.%d.%d.%d", p[0], p[1], p[2], p[3]);
}

client::client()
{
	m_handler = NULL;
}

client::~client()
{
}

/*
wxUint8 key_limohu9999[]={0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x75,0x8D,0x09,0xD6,0x43,0x3C,0x5C,0xFD,
                 0x55,0x0F,0x3C,0xB9,0x4F,0xFE,0x0B,0x45,0x9A,0x48,0xC9,0x30,0x31,0x40,0x29,0x2E,
                 0xFA,0xD4,0xCB,0x4C,0xEE,0x46,0x2D,0xAA,0xFA,0xD4,0xCB,0x4C,0xEE,0x46,0x2D,0xAA,
                 0x44,0x36,0x45,0x42,0x44,0x33,0x44,0x31,0x31,0x38,0x32,0x41,0x37,0x42,0x38,0x44,
                 0x39,0x33,0x41,0x45,0x41,0x46,0x39,0x43,0x39,0x42,0x38,0x46,0x37,0x31,0x32,0x45};

wxUint8 key_zoophyte2000[]={0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x16,0x8D,0xFA,0x39,0x69,0x0F,0x4C,0xC2,
                0xA0,0x9B,0x9F,0xF4,0x9B,0x33,0x1F,0x13,0x95,0xFA,0x09,0x03,0x98,0x51,0x32,0x42,
                0xFA,0xD4,0xCB,0x4C,0xEE,0x46,0x2D,0xAA,0xFA,0xD4,0xCB,0x4C,0xEE,0x46,0x2D,0xAA,
                0x33,0x37,0x37,0x34,0x38,0x41,0x46,0x39,0x37,0x39,0x43,0x43,0x34,0x46,0x34,0x43,
                0x45,0x44,0x41,0x34,0x33,0x44,0x36,0x37,0x30,0x35,0x38,0x42,0x34,0x44,0x42,0x44};
*/


unsigned char account_key[80];
char part_tmp[64];

wxUint32 csi[256] = {
         0, 0x77073096, 0xee0e612c, 0x990951ba,  0x76dc419, 0x706af48f, 0xe963a535, 0x9e6495a3,
 0xedb8832, 0x79dcb8a4, 0xe0d5e91e, 0x97d2d988,  0x9b64c2b, 0x7eb17cbd, 0xe7b82d07, 0x90bf1d91,
0x1db71064, 0x6ab020f2, 0xf3b97148, 0x84be41de, 0x1adad47d, 0x6ddde4eb, 0xf4d4b551, 0x83d385c7,
0x136c9856, 0x646ba8c0, 0xfd62f97a, 0x8a65c9ec, 0x14015c4f, 0x63066cd9, 0xfa0f3d63, 0x8d080df5,
0x3b6e20c8, 0x4c69105e, 0xd56041e4, 0xa2677172, 0x3c03e4d1, 0x4b04d447, 0xd20d85fd, 0xa50ab56b,
0x35b5a8fa, 0x42b2986c, 0xdbbbc9d6, 0xacbcf940, 0x32d86ce3, 0x45df5c75, 0xdcd60dcf, 0xabd13d59,
0x26d930ac, 0x51de003a, 0xc8d75180, 0xbfd06116, 0x21b4f4b5, 0x56b3c423, 0xcfba9599, 0xb8bda50f,
0x2802b89e, 0x5f058808, 0xc60cd9b2, 0xb10be924, 0x2f6f7c87, 0x58684c11, 0xc1611dab, 0xb6662d3d,
0x76dc4190,  0x1db7106, 0x98d220bc, 0xefd5102a, 0x71b18589,  0x6b6b51f, 0x9fbfe4a5, 0xe8b8d433,
0x7807c9a2,  0xf00f934, 0x9609a88e, 0xe10e9818, 0x7f6a0dbb,  0x86d3d2d, 0x91646c97, 0xe6635c01,
0x6b6b51f4, 0x1c6c6162, 0x856530d8, 0xf262004e, 0x6c0695ed, 0x1b01a57b, 0x8208f4c1, 0xf50fc457,
0x65b0d9c6, 0x12b7e950, 0x8bbeb8ea, 0xfcb9887c, 0x62dd1ddf, 0x15da2d49, 0x8cd37cf3, 0xfbd44c65,
0x4db26158, 0x3ab551ce, 0xa3bc0074, 0xd4bb30e2, 0x4adfa541, 0x3dd895d7, 0xa4d1c46d, 0xd3d6f4fb,
0x4369e96a, 0x346ed9fc, 0xad678846, 0xda60b8d0, 0x44042d73, 0x33031de5, 0xaa0a4c5f, 0xdd0d7cc9,
0x5005713c, 0x270241aa, 0xbe0b1010, 0xc90c2086, 0x5768b525, 0x206f85b3, 0xb966d409, 0xce61e49f,
0x5edef90e, 0x29d9c998, 0xb0d09822, 0xc7d7a8b4, 0x59b33d17, 0x2eb40d81, 0xb7bd5c3b, 0xc0ba6cad,
0xedb88320, 0x9abfb3b6,  0x3b6e20c, 0x74b1d29a, 0xead54739, 0x9dd277af,  0x4db2615, 0x73dc1683,
0xe3630b12, 0x94643b84,  0xd6d6a3e, 0x7a6a5aa8, 0xe40ecf0b, 0x9309ff9d,  0xa00ae27, 0x7d079eb1,
0xf00f9344, 0x8708a3d2, 0x1e01f268, 0x6906c2fe, 0xf762575d, 0x806567cb, 0x196c3671, 0x6e6b06e7,
0xfed41b76, 0x89d32be0, 0x10da7a5a, 0x67dd4acc, 0xf9b9df6f, 0x8ebeeff9, 0x17b7be43, 0x60b08ed5,
0xd6d6a3e8, 0xa1d1937e, 0x38d8c2c4, 0x4fdff252, 0xd1bb67f1, 0xa6bc5767, 0x3fb506dd, 0x48b2364b,
0xd80d2bda, 0xaf0a1b4c, 0x36034af6, 0x41047a60, 0xdf60efc3, 0xa867df55, 0x316e8eef, 0x4669be79,
0xcb61b38c, 0xbc66831a, 0x256fd2a0, 0x5268e236, 0xcc0c7795, 0xbb0b4703, 0x220216b9, 0x5505262f,
0xc5ba3bbe, 0xb2bd0b28, 0x2bb45a92, 0x5cb36a04, 0xc2d7ffa7, 0xb5d0cf31, 0x2cd99e8b, 0x5bdeae1d,
0x9b64c2b0, 0xec63f226, 0x756aa39c,  0x26d930a, 0x9c0906a9, 0xeb0e363f, 0x72076785,  0x5005713,
0x95bf4a82, 0xe2b87a14, 0x7bb12bae,  0xcb61b38, 0x92d28e9b, 0xe5d5be0d, 0x7cdcefb7,  0xbdbdf21,
0x86d3d2d4, 0xf1d4e242, 0x68ddb3f8, 0x1fda836e, 0x81be16cd, 0xf6b9265b, 0x6fb077e1, 0x18b74777,
0x88085ae6, 0xff0f6a70, 0x66063bca, 0x11010b5c, 0x8f659eff, 0xf862ae69, 0x616bffd3, 0x166ccf45,
0xa00ae278, 0xd70dd2ee, 0x4e048354, 0x3903b3c2, 0xa7672661, 0xd06016f7, 0x4969474d, 0x3e6e77db,
0xaed16a4a, 0xd9d65adc, 0x40df0b66, 0x37d83bf0, 0xa9bcae53, 0xdebb9ec5, 0x47b2cf7f, 0x30b5ffe9,
0xbdbdf21c, 0xcabac28a, 0x53b39330, 0x24b4a3a6, 0xbad03605, 0xcdd70693, 0x54de5729, 0x23d967bf,
0xb3667a2e, 0xc4614ab8, 0x5d681b02, 0x2a6f2b94, 0xb40bbe37, 0xc30c8ea1, 0x5a05df1b, 0x2d02ef8d
};

wxUint32 spr[] = {
  0x808200,          0,     0x8000,   0x808202,   0x808002,     0x8202,        0x2,     0x8000,
     0x200,   0x808200,   0x808202,      0x200,   0x800202,   0x808002,   0x800000,        0x2,
     0x202,   0x800200,   0x800200,     0x8200,     0x8200,   0x808000,   0x808000,   0x800202,
    0x8002,   0x800002,   0x800002,     0x8002,          0,      0x202,     0x8202,   0x800000,
    0x8000,   0x808202,        0x2,   0x808000,   0x808200,   0x800000,   0x800000,      0x200,
  0x808002,     0x8000,     0x8200,   0x800002,      0x200,        0x2,   0x800202,     0x8202,
  0x808202,     0x8002,   0x808000,   0x800202,   0x800002,      0x202,     0x8202,   0x808200,
     0x202,   0x800200,   0x800200,          0,     0x8002,     0x8200,          0,   0x808002,
0x40084010, 0x40004000,     0x4000,    0x84010,    0x80000,       0x10, 0x40080010, 0x40004010,
0x40000010, 0x40084010, 0x40084000, 0x40000000, 0x40004000,    0x80000,       0x10, 0x40080010,
   0x84000,    0x80010, 0x40004010,          0, 0x40000000,     0x4000,    0x84010, 0x40080000,
   0x80010, 0x40000010,          0,    0x84000,     0x4010, 0x40084000, 0x40080000,     0x4010,
         0,    0x84010, 0x40080010,    0x80000, 0x40004010, 0x40080000, 0x40084000,     0x4000,
0x40080000, 0x40004000,       0x10, 0x40084010,    0x84010,       0x10,     0x4000, 0x40000000,
    0x4010, 0x40084000,    0x80000, 0x40000010,    0x80010, 0x40004010, 0x40000010,    0x80010,
   0x84000,          0, 0x40004000,     0x4010, 0x40000000, 0x40080010, 0x40084010,    0x84000,
     0x104,  0x4010100,          0,  0x4010004,  0x4000100,          0,    0x10104,  0x4000100,
   0x10004,  0x4000004,  0x4000004,    0x10000,  0x4010104,    0x10004,  0x4010000,      0x104,
 0x4000000,        0x4,  0x4010100,      0x100,    0x10100,  0x4010000,  0x4010004,    0x10104,
 0x4000104,    0x10100,    0x10000,  0x4000104,        0x4,  0x4010104,      0x100,  0x4000000,
 0x4010100,  0x4000000,    0x10004,      0x104,    0x10000,  0x4010100,  0x4000100,          0,
     0x100,    0x10004,  0x4010104,  0x4000100,  0x4000004,      0x100,          0,  0x4010004,
 0x4000104,    0x10000,  0x4000000,  0x4010104,        0x4,    0x10104,    0x10100,  0x4000004,
 0x4010000,  0x4000104,      0x104,  0x4010000,    0x10104,        0x4,  0x4010004,    0x10100,
0x80401000, 0x80001040, 0x80001040,       0x40,   0x401040, 0x80400040, 0x80400000, 0x80001000,
         0,   0x401000,   0x401000, 0x80401040, 0x80000040,          0,   0x400040, 0x80400000,
0x80000000,     0x1000,   0x400000, 0x80401000,       0x40,   0x400000, 0x80001000,     0x1040,
0x80400040, 0x80000000,     0x1040,   0x400040,     0x1000,   0x401040, 0x80401040, 0x80000040,
  0x400040, 0x80400000,   0x401000, 0x80401040, 0x80000040,          0,          0,   0x401000,
    0x1040,   0x400040, 0x80400040, 0x80000000, 0x80401000, 0x80001040, 0x80001040,       0x40,
0x80401040, 0x80000040, 0x80000000,     0x1000, 0x80400000, 0x80001000,   0x401040, 0x80400040,
0x80001000,     0x1040,   0x400000, 0x80401000,       0x40,   0x400000,     0x1000,   0x401040,
      0x80,  0x1040080,  0x1040000, 0x21000080,    0x40000,       0x80, 0x20000000,  0x1040000,
0x20040080,    0x40000,  0x1000080, 0x20040080, 0x21000080, 0x21040000,    0x40080, 0x20000000,
 0x1000000, 0x20040000, 0x20040000,          0, 0x20000080, 0x21040080, 0x21040080,  0x1000080,
0x21040000, 0x20000080,          0, 0x21000000,  0x1040080,  0x1000000, 0x21000000,    0x40080,
   0x40000, 0x21000080,       0x80,  0x1000000, 0x20000000,  0x1040000, 0x21000080, 0x20040080,
 0x1000080, 0x20000000, 0x21040000,  0x1040080, 0x20040080,       0x80,  0x1000000, 0x21040000,
0x21040080,    0x40080, 0x21000000, 0x21040080,  0x1040000,          0, 0x20040000, 0x21000000,
   0x40080,  0x1000080, 0x20000080,    0x40000,          0, 0x20040000,  0x1040080, 0x20000080,
0x10000008, 0x10200000,     0x2000, 0x10202008, 0x10200000,        0x8, 0x10202008,   0x200000,
0x10002000,   0x202008,   0x200000, 0x10000008,   0x200008, 0x10002000, 0x10000000,     0x2008,
         0,   0x200008, 0x10002008,     0x2000,   0x202000, 0x10002008,        0x8, 0x10200008,
0x10200008,          0,   0x202008, 0x10202000,     0x2008,   0x202000, 0x10202000, 0x10000000,
0x10002000,        0x8, 0x10200008,   0x202000, 0x10202008,   0x200000,     0x2008, 0x10000008,
  0x200000, 0x10002000, 0x10000000,     0x2008, 0x10000008, 0x10202008,   0x202000, 0x10200000,
  0x202008, 0x10202000,          0, 0x10200008,        0x8,     0x2000, 0x10200000,   0x202008,
    0x2000,   0x200008, 0x10002008,          0, 0x10202000, 0x10000000,   0x200008, 0x10002008,
  0x100000,  0x2100001,  0x2000401,          0,      0x400,  0x2000401,   0x100401,  0x2100400,
 0x2100401,   0x100000,          0,  0x2000001,        0x1,  0x2000000,  0x2100001,      0x401,
 0x2000400,   0x100401,   0x100001,  0x2000400,  0x2000001,  0x2100000,  0x2100400,   0x100001,
 0x2100000,      0x400,      0x401,  0x2100401,   0x100400,        0x1,  0x2000000,   0x100400,
 0x2000000,   0x100400,   0x100000,  0x2000401,  0x2000401,  0x2100001,  0x2100001,        0x1,
  0x100001,  0x2000000,  0x2000400,   0x100000,  0x2100400,      0x401,   0x100401,  0x2100400,
     0x401,  0x2000001,  0x2100401,  0x2100000,   0x100400,          0,        0x1,  0x2100401,
         0,   0x100401,  0x2100000,      0x400,  0x2000001,  0x2000400,      0x400,   0x100001,
 0x8000820,      0x800,    0x20000,  0x8020820,  0x8000000,  0x8000820,       0x20,  0x8000000,
   0x20020,  0x8020000,  0x8020820,    0x20800,  0x8020800,    0x20820,      0x800,       0x20,
 0x8020000,  0x8000020,  0x8000800,      0x820,    0x20800,    0x20020,  0x8020020,  0x8020800,
     0x820,          0,          0,  0x8020020,  0x8000020,  0x8000800,    0x20820,    0x20000,
   0x20820,    0x20000,  0x8020800,      0x800,       0x20,  0x8020020,      0x800,    0x20820,
 0x8000800,       0x20,  0x8000020,  0x8020000,  0x8020020,  0x8000000,    0x20000,  0x8000820,
         0,  0x8020820,    0x20020,  0x8000020,  0x8020000,  0x8000800,  0x8000820,          0,
 0x8020820,    0x20800,    0x20800,      0x820,      0x820,    0x20020,  0x8000000,  0x8020800,
         0,       0x80,          0,       0x80,     0x8000,     0x8080,     0x8000,     0x8080,
         0,       0x80,          0,       0x80,     0x8000,     0x8080,     0x8000,     0x8080,
  0x800000,   0x800080,   0x800000,   0x800080,   0x808000,   0x808080,   0x808000,   0x808080,
  0x800000,   0x800080,   0x800000,   0x800080,   0x808000,   0x808080,   0x808000,   0x808080,
         0,       0x80,          0,       0x80,     0x8000,     0x8080,     0x8000,     0x8080,
         0,       0x80,          0,       0x80,     0x8000,     0x8080,     0x8000,     0x8080,
  0x800000,   0x800080,   0x800000,   0x800080,   0x808000,   0x808080,   0x808000,   0x808080,
  0x800000,   0x800080,   0x800000,   0x800080,   0x808000,   0x808080,   0x808000,   0x808080,
0x80000000, 0x80000080, 0x80000000, 0x80000080, 0x80008000, 0x80008080, 0x80008000, 0x80008080,
0x80000000, 0x80000080, 0x80000000, 0x80000080, 0x80008000, 0x80008080, 0x80008000, 0x80008080,
0x80800000, 0x80800080, 0x80800000, 0x80800080, 0x80808000, 0x80808080, 0x80808000, 0x80808080,
0x80800000, 0x80800080, 0x80800000, 0x80800080, 0x80808000, 0x80808080, 0x80808000, 0x80808080,
0x80000000, 0x80000080, 0x80000000, 0x80000080, 0x80008000, 0x80008080, 0x80008000, 0x80008080,
0x80000000, 0x80000080, 0x80000000, 0x80000080, 0x80008000, 0x80008080, 0x80008000, 0x80008080,
0x80800000, 0x80800080, 0x80800000, 0x80800080, 0x80808000, 0x80808080, 0x80808000, 0x80808080,
0x80800000, 0x80800080, 0x80800000, 0x80800080, 0x80808000, 0x80808080, 0x80808000, 0x80808080,
         0,       0x80,          0,       0x80,     0x8000,     0x8080,     0x8000,     0x8080,
         0,       0x80,          0,       0x80,     0x8000,     0x8080,     0x8000,     0x8080,
  0x800000,   0x800080,   0x800000,   0x800080,   0x808000,   0x808080,   0x808000,   0x808080,
  0x800000,   0x800080,   0x800000,   0x800080,   0x808000,   0x808080,   0x808000,   0x808080,
         0,       0x80,          0,       0x80,     0x8000,     0x8080,     0x8000,     0x8080,
         0,       0x80,          0,       0x80,     0x8000,     0x8080,     0x8000,     0x8080,
  0x800000,   0x800080,   0x800000,   0x800080,   0x808000,   0x808080,   0x808000,   0x808080,
  0x800000,   0x800080,   0x800000,   0x800080,   0x808000,   0x808080,   0x808000,   0x808080,
0x80000000, 0x80000080, 0x80000000, 0x80000080, 0x80008000, 0x80008080, 0x80008000, 0x80008080,
0x80000000, 0x80000080, 0x80000000, 0x80000080, 0x80008000, 0x80008080, 0x80008000, 0x80008080,
0x80800000, 0x80800080, 0x80800000, 0x80800080, 0x80808000, 0x80808080, 0x80808000, 0x80808080,
0x80800000, 0x80800080, 0x80800000, 0x80800080, 0x80808000, 0x80808080, 0x80808000, 0x80808080,
0x80000000, 0x80000080, 0x80000000, 0x80000080, 0x80008000, 0x80008080, 0x80008000, 0x80008080,
0x80000000, 0x80000080, 0x80000000, 0x80000080, 0x80008000, 0x80008080, 0x80008000, 0x80008080,
0x80800000, 0x80800080, 0x80800000, 0x80800080, 0x80808000, 0x80808080, 0x80808000, 0x80808080,
0x80800000, 0x80800080, 0x80800000, 0x80800080, 0x80808000, 0x80808080, 0x80808000, 0x80808080,
         0,          0,       0x80,       0x80,          0,          0,       0x80,       0x80,
    0x8000,     0x8000,     0x8080,     0x8080,     0x8000,     0x8000,     0x8080,     0x8080,
         0,          0,       0x80,       0x80,          0,          0,       0x80,       0x80,
    0x8000,     0x8000,     0x8080,     0x8080,     0x8000,     0x8000,     0x8080,     0x8080,
  0x800000,   0x800000,   0x800080,   0x800080,   0x800000,   0x800000,   0x800080,   0x800080,
  0x808000,   0x808000,   0x808080,   0x808080,   0x808000,   0x808000,   0x808080,   0x808080,
  0x800000,   0x800000,   0x800080,   0x800080,   0x800000,   0x800000,   0x800080,   0x800080,
  0x808000,   0x808000,   0x808080,   0x808080,   0x808000,   0x808000,   0x808080,   0x808080,
         0,          0,       0x80,       0x80,          0,          0,       0x80,       0x80,
    0x8000,     0x8000,     0x8080,     0x8080,     0x8000,     0x8000,     0x8080,     0x8080,
         0,          0,       0x80,       0x80,          0,          0,       0x80,       0x80,
    0x8000,     0x8000,     0x8080,     0x8080,     0x8000,     0x8000,     0x8080,     0x8080,
  0x800000,   0x800000,   0x800080,   0x800080,   0x800000,   0x800000,   0x800080,   0x800080,
  0x808000,   0x808000,   0x808080,   0x808080,   0x808000,   0x808000,   0x808080,   0x808080,
  0x800000,   0x800000,   0x800080,   0x800080,   0x800000,   0x800000,   0x800080,   0x800080,
  0x808000,   0x808000,   0x808080,   0x808080,   0x808000,   0x808000,   0x808080,   0x808080,
0x80000000, 0x80000000, 0x80000080, 0x80000080, 0x80000000, 0x80000000, 0x80000080, 0x80000080,
0x80008000, 0x80008000, 0x80008080, 0x80008080, 0x80008000, 0x80008000, 0x80008080, 0x80008080,
0x80000000, 0x80000000, 0x80000080, 0x80000080, 0x80000000, 0x80000000, 0x80000080, 0x80000080,
0x80008000, 0x80008000, 0x80008080, 0x80008080, 0x80008000, 0x80008000, 0x80008080, 0x80008080,
0x80800000, 0x80800000, 0x80800080, 0x80800080, 0x80800000, 0x80800000, 0x80800080, 0x80800080,
0x80808000, 0x80808000, 0x80808080, 0x80808080, 0x80808000, 0x80808000, 0x80808080, 0x80808080,
0x80800000, 0x80800000, 0x80800080, 0x80800080, 0x80800000, 0x80800000, 0x80800080, 0x80800080,
0x80808000, 0x80808000, 0x80808080, 0x80808080, 0x80808000, 0x80808000, 0x80808080, 0x80808080,
0x80000000, 0x80000000, 0x80000080, 0x80000080, 0x80000000, 0x80000000, 0x80000080, 0x80000080,
0x80008000, 0x80008000, 0x80008080, 0x80008080, 0x80008000, 0x80008000, 0x80008080, 0x80008080,
0x80000000, 0x80000000, 0x80000080, 0x80000080, 0x80000000, 0x80000000, 0x80000080, 0x80000080,
0x80008000, 0x80008000, 0x80008080, 0x80008080, 0x80008000, 0x80008000, 0x80008080, 0x80008080,
0x80800000, 0x80800000, 0x80800080, 0x80800080, 0x80800000, 0x80800000, 0x80800080, 0x80800080,
0x80808000, 0x80808000, 0x80808080, 0x80808080, 0x80808000, 0x80808000, 0x80808080, 0x80808080,
0x80800000, 0x80800000, 0x80800080, 0x80800080, 0x80800000, 0x80800000, 0x80800080, 0x80800080,
0x80808000, 0x80808000, 0x80808080, 0x80808080, 0x80808000, 0x80808000, 0x80808080, 0x80808080,
         0, 0x80000000,   0x800000, 0x80800000,     0x8000, 0x80008000,   0x808000, 0x80808000,
      0x80, 0x80000080,   0x800080, 0x80800080,     0x8080, 0x80008080,   0x808080, 0x80808080,
         0, 0x80000000,   0x800000, 0x80800000,     0x8000, 0x80008000,   0x808000, 0x80808000,
      0x80, 0x80000080,   0x800080, 0x80800080,     0x8080, 0x80008080,   0x808080, 0x80808080,
         0, 0x80000000,   0x800000, 0x80800000,     0x8000, 0x80008000,   0x808000, 0x80808000,
      0x80, 0x80000080,   0x800080, 0x80800080,     0x8080, 0x80008080,   0x808080, 0x80808080,
         0, 0x80000000,   0x800000, 0x80800000,     0x8000, 0x80008000,   0x808000, 0x80808000,
      0x80, 0x80000080,   0x800080, 0x80800080,     0x8080, 0x80008080,   0x808080, 0x80808080,
         0, 0x80000000,   0x800000, 0x80800000,     0x8000, 0x80008000,   0x808000, 0x80808000,
      0x80, 0x80000080,   0x800080, 0x80800080,     0x8080, 0x80008080,   0x808080, 0x80808080,
         0, 0x80000000,   0x800000, 0x80800000,     0x8000, 0x80008000,   0x808000, 0x80808000,
      0x80, 0x80000080,   0x800080, 0x80800080,     0x8080, 0x80008080,   0x808080, 0x80808080,
         0, 0x80000000,   0x800000, 0x80800000,     0x8000, 0x80008000,   0x808000, 0x80808000,
      0x80, 0x80000080,   0x800080, 0x80800080,     0x8080, 0x80008080,   0x808080, 0x80808080,
         0, 0x80000000,   0x800000, 0x80800000,     0x8000, 0x80008000,   0x808000, 0x80808000,
      0x80, 0x80000080,   0x800080, 0x80800080,     0x8080, 0x80008080,   0x808080, 0x80808080,
         0, 0x80000000,   0x800000, 0x80800000,     0x8000, 0x80008000,   0x808000, 0x80808000,
      0x80, 0x80000080,   0x800080, 0x80800080,     0x8080, 0x80008080,   0x808080, 0x80808080,
         0, 0x80000000,   0x800000, 0x80800000,     0x8000, 0x80008000,   0x808000, 0x80808000,
      0x80, 0x80000080,   0x800080, 0x80800080,     0x8080, 0x80008080,   0x808080, 0x80808080,
         0, 0x80000000,   0x800000, 0x80800000,     0x8000, 0x80008000,   0x808000, 0x80808000,
      0x80, 0x80000080,   0x800080, 0x80800080,     0x8080, 0x80008080,   0x808080, 0x80808080,
         0, 0x80000000,   0x800000, 0x80800000,     0x8000, 0x80008000,   0x808000, 0x80808000,
      0x80, 0x80000080,   0x800080, 0x80800080,     0x8080, 0x80008080,   0x808080, 0x80808080,
         0, 0x80000000,   0x800000, 0x80800000,     0x8000, 0x80008000,   0x808000, 0x80808000,
      0x80, 0x80000080,   0x800080, 0x80800080,     0x8080, 0x80008080,   0x808080, 0x80808080,
         0, 0x80000000,   0x800000, 0x80800000,     0x8000, 0x80008000,   0x808000, 0x80808000,
      0x80, 0x80000080,   0x800080, 0x80800080,     0x8080, 0x80008080,   0x808080, 0x80808080,
         0, 0x80000000,   0x800000, 0x80800000,     0x8000, 0x80008000,   0x808000, 0x80808000,
      0x80, 0x80000080,   0x800080, 0x80800080,     0x8080, 0x80008080,   0x808080, 0x80808080,
         0, 0x80000000,   0x800000, 0x80800000,     0x8000, 0x80008000,   0x808000, 0x80808000,
      0x80, 0x80000080,   0x800080, 0x80800080,     0x8080, 0x80008080,   0x808080, 0x80808080,
         0,          0,          0,          0,          0,          0,          0,          0,
         0,          0,          0,          0,          0,          0,          0,          0,
0x80000000, 0x80000000, 0x80000000, 0x80000000, 0x80000000, 0x80000000, 0x80000000, 0x80000000,
0x80000000, 0x80000000, 0x80000000, 0x80000000, 0x80000000, 0x80000000, 0x80000000, 0x80000000,
  0x800000,   0x800000,   0x800000,   0x800000,   0x800000,   0x800000,   0x800000,   0x800000,
  0x800000,   0x800000,   0x800000,   0x800000,   0x800000,   0x800000,   0x800000,   0x800000,
0x80800000, 0x80800000, 0x80800000, 0x80800000, 0x80800000, 0x80800000, 0x80800000, 0x80800000,
0x80800000, 0x80800000, 0x80800000, 0x80800000, 0x80800000, 0x80800000, 0x80800000, 0x80800000,
    0x8000,     0x8000,     0x8000,     0x8000,     0x8000,     0x8000,     0x8000,     0x8000,
    0x8000,     0x8000,     0x8000,     0x8000,     0x8000,     0x8000,     0x8000,     0x8000,
0x80008000, 0x80008000, 0x80008000, 0x80008000, 0x80008000, 0x80008000, 0x80008000, 0x80008000,
0x80008000, 0x80008000, 0x80008000, 0x80008000, 0x80008000, 0x80008000, 0x80008000, 0x80008000,
  0x808000,   0x808000,   0x808000,   0x808000,   0x808000,   0x808000,   0x808000,   0x808000,
  0x808000,   0x808000,   0x808000,   0x808000,   0x808000,   0x808000,   0x808000,   0x808000,
0x80808000, 0x80808000, 0x80808000, 0x80808000, 0x80808000, 0x80808000, 0x80808000, 0x80808000,
0x80808000, 0x80808000, 0x80808000, 0x80808000, 0x80808000, 0x80808000, 0x80808000, 0x80808000,
      0x80,       0x80,       0x80,       0x80,       0x80,       0x80,       0x80,       0x80,
      0x80,       0x80,       0x80,       0x80,       0x80,       0x80,       0x80,       0x80,
0x80000080, 0x80000080, 0x80000080, 0x80000080, 0x80000080, 0x80000080, 0x80000080, 0x80000080,
0x80000080, 0x80000080, 0x80000080, 0x80000080, 0x80000080, 0x80000080, 0x80000080, 0x80000080,
  0x800080,   0x800080,   0x800080,   0x800080,   0x800080,   0x800080,   0x800080,   0x800080,
  0x800080,   0x800080,   0x800080,   0x800080,   0x800080,   0x800080,   0x800080,   0x800080,
0x80800080, 0x80800080, 0x80800080, 0x80800080, 0x80800080, 0x80800080, 0x80800080, 0x80800080,
0x80800080, 0x80800080, 0x80800080, 0x80800080, 0x80800080, 0x80800080, 0x80800080, 0x80800080,
    0x8080,     0x8080,     0x8080,     0x8080,     0x8080,     0x8080,     0x8080,     0x8080,
    0x8080,     0x8080,     0x8080,     0x8080,     0x8080,     0x8080,     0x8080,     0x8080,
0x80008080, 0x80008080, 0x80008080, 0x80008080, 0x80008080, 0x80008080, 0x80008080, 0x80008080,
0x80008080, 0x80008080, 0x80008080, 0x80008080, 0x80008080, 0x80008080, 0x80008080, 0x80008080,
  0x808080,   0x808080,   0x808080,   0x808080,   0x808080,   0x808080,   0x808080,   0x808080,
  0x808080,   0x808080,   0x808080,   0x808080,   0x808080,   0x808080,   0x808080,   0x808080,
0x80808080, 0x80808080, 0x80808080, 0x80808080, 0x80808080, 0x80808080, 0x80808080, 0x80808080,
0x80808080, 0x80808080, 0x80808080, 0x80808080, 0x80808080, 0x80808080, 0x80808080, 0x80808080
};

// 617670
wxUint32 spr2[] = {
	0x2020101,  0x2020202,  0x2020201,  0x1020202,   0x202830, 0x31140c04,  0x5012129, 0x2a32150d,
	0xe060222, 0x232b3316, 0x170f0703, 0x1c242c34, 0x35181008,  0x91d252d, 0x2e361911, 0x120a1e26,
	0x272f371a, 0x1b130b1f,  0x4110b0e,   0x19171b, 0x1207160d, 0x18100905, 0x150c1402, 0x1a0f0801,
	0x1319040f, 0x101a0109,  0x8170b05,   0x11070c,  0xe0a0316, 0x181b1406
};

char crypt_buf[1024];

/*
:0061D77C 07 02 00 00 04 0D 00 00 05 00 00 00 03 00 00 00
:0061D78C 06 22 00 00 06 19 00 00 01 0A 00 00 11 08 00 00
:0061D79C 0B 20 00 00 04 13 00 00 02 29 00 00 15 01 00 00
:0061D7AC 28 04 00 00 21 12 00 00 00 09 00 00 01 12 00 00
:0061D7BC 38 08 00 00 30 20 00 00 08 1D 00 00 18 02 00 00
:0061D7CC 30 01 00 00 20 26 00 00 24 14 00 00 2A 00 00 00
:0061D7DC 10 04 00 00 00 24 00 00 15 12 00 00 0A 28 00 00
:0061D7EC 00 30 00 00 0A 04 00 00 02 32 00 00 00 00 00 00
:0061D7FC 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00
*/

wxUint32 dword_61D77C[32];

wxUint32 client::checksum(char *buf, int len)
{
	wxUint32 ax = 0xffffffff;
	for (int index=0; index<len; index++) {
		ax = (ax>>8) ^ csi[(buf[index]^ax)&0xff];
	}
	return ~ax;
}

void des_decrypt(int isdecrypt)
{
	wxUint32 var_4 = 0, var_8 = 0, var_C = 0;
	wxUint32 buf = 0;

	__asm {
                push    eax
                push    ebx
                push    ecx
                push    edx
                push    esi
                push    edi
                movzx   ecx, byte ptr crypt_buf[5]
                movzx   eax, byte ptr crypt_buf[0]
                shl     ecx, 2
                mov     buf, ecx
                movzx   ecx, byte ptr crypt_buf[6]
                movzx   edx, byte ptr crypt_buf[1]
                shl     ecx, 2
                mov     var_C, ecx
                movzx   ecx, byte ptr crypt_buf[7]
                movzx   ebx, byte ptr crypt_buf[4]
                shl     ecx, 2
                shl     eax, 2
                mov     var_8, ecx
                mov     ecx, spr[800h][eax]
                mov     eax, spr[0C00h][eax]
                shr     ecx, 1
                shr     eax, 1
                shl     edx, 2
                or      ecx, spr[800h][edx]
                or      eax, spr[0C00h][edx]
                push    esi
                movzx   esi, byte ptr crypt_buf[2]
                shr     ecx, 1
                shr     eax, 1
                shl     esi, 2
                or      ecx, spr[800h][esi]
                or      eax, spr[0C00h][esi]
                shr     ecx, 1
                push    edi
                movzx   edi, byte ptr crypt_buf[3]
                shr     eax, 1
                shl     ebx, 2
                shl     edi, 2
                or      ecx, spr[800h][edi]
                or      eax, spr[0C00h][edi]
                shr     ecx, 1
                or      ecx, spr[800h][ebx]
                mov     var_4, ebx
                mov     edx, ebx
                mov     esi, spr[0C00h][edx]
                mov     ebx, buf
                mov     edx, buf
                shr     eax, 1
                or      eax, esi
                mov     esi, spr[0C00h][edx]
                mov     edx, var_C
                shr     ecx, 1
                or      ecx, spr[800h][ebx]
                mov     ebx, var_C
                shr     eax, 1
                or      eax, esi
                mov     esi, spr[0C00h][edx]
                mov     edx, isdecrypt
                shr     ecx, 1
                or      ecx, spr[800h][ebx]
                mov     ebx, var_8
                shr     eax, 1
                or      eax, esi
                mov     esi, spr[0C00h][ebx]
                shr     ecx, 1
                or      ecx, spr[800h][ebx]
                shr     eax, 1
                or      eax, esi
                test    edx, edx
                jnz     loc_45D76D
                mov     edx, offset dword_61D77C
                mov     buf, edx

loc_45D6C2:                             ; CODE XREF: sub_45D5C0+1A2j
                mov     esi, eax
                shr     esi, 1Fh
                lea     edi, [eax+eax]
                or      esi, edi
                mov     edi, esi
                shl     edi, 1Ch
                mov     ebx, esi
                shr     ebx, 4
                or      edi, ebx
                xor     edi, [edx-4]
                xor     esi, [edx]
                mov     edx, edi
                shr     edx, 18h
                and     edx, 3Fh
                mov     edx, spr[edx*4]
                mov     ebx, edi
                shr     ebx, 10h
                and     ebx, 3Fh
                xor     edx, spr[200h][ebx*4]
                mov     ebx, esi
                shr     ebx, 18h
                and     ebx, 3Fh
                xor     edx, spr[100h][ebx*4]
                mov     ebx, edi
                shr     ebx, 8
                and     ebx, 3Fh
                xor     edx, spr[400h][ebx*4]
                mov     ebx, esi
                shr     ebx, 10h
                and     ebx, 3Fh
                xor     edx, spr[300h][ebx*4]
                mov     ebx, esi
                shr     ebx, 8
                and     ebx, 3Fh
                xor     edx, spr[500h][ebx*4]
                and     edi, 3Fh
                xor     edx, spr[600h][edi*4]
                and     esi, 3Fh
                xor     edx, spr[700h][esi*4]
                xor     edx, ecx
                mov     ecx, eax
                mov     eax, edx
                mov     edx, buf
                add     edx, 8
                cmp     edx, offset dword_61D77C+32*4
                mov     buf, edx
                jl      loc_45D6C2
                jmp     loc_45D81C
; ---------------------------------------------------------------------------

loc_45D76D:                             ; CODE XREF: sub_45D5C0+F3j
                mov     edx, offset dword_61D77C+30*4
                mov     buf, edx

loc_45D776:                             ; CODE XREF: sub_45D5C0+256j
                mov     esi, eax
                shr     esi, 1Fh
                lea     edi, [eax+eax]
                or      esi, edi
                mov     edi, esi
                shl     edi, 1Ch
                mov     ebx, esi
                shr     ebx, 4
                or      edi, ebx
                xor     edi, [edx-4]
                xor     esi, [edx]
                mov     edx, edi
                shr     edx, 18h
                and     edx, 3Fh
                mov     edx, spr[edx*4]
                mov     ebx, edi
                shr     ebx, 10h
                and     ebx, 3Fh
                xor     edx, spr[200h][ebx*4]
                mov     ebx, esi
                shr     ebx, 18h
                and     ebx, 3Fh
                xor     edx, spr[100h][ebx*4]
                mov     ebx, edi
                shr     ebx, 8
                and     ebx, 3Fh
                xor     edx, spr[400h][ebx*4]
                mov     ebx, esi
                shr     ebx, 10h
                and     ebx, 3Fh
                xor     edx, spr[300h][ebx*4]
                mov     ebx, esi
                shr     ebx, 8
                and     ebx, 3Fh
                xor     edx, spr[500h][ebx*4]
                and     edi, 3Fh
                xor     edx, spr[600h][edi*4]
                and     esi, 3Fh
                xor     edx, spr[700h][esi*4]
                xor     edx, ecx
                mov     ecx, eax
                mov     eax, edx
                mov     edx, buf
                sub     edx, 8
                cmp     edx, offset dword_61D77C
                mov     buf, edx
                jge     loc_45D776

loc_45D81C:                             ; CODE XREF: sub_45D5C0+1A8j
                movzx   edx, ch
                shl     edx, 2
                mov     var_C, edx
                mov     edx, eax
                shr     edx, 10h
                movzx   edx, dl
                shl     edx, 2
                mov     buf, eax
                mov     buf, edx
                mov     edx, ecx
                shr     edx, 10h
                movzx   edx, dl
                shl     edx, 2
                mov     esi, eax
                and     esi, 0FFh
                shl     esi, 2
                mov     isdecrypt, ecx
                mov     isdecrypt, edx
                mov     edx, spr[1000h][esi]
                shr     edx, 1
                mov     edi, ecx
                and     edi, 0FFh
                shl     edi, 2
                or      edx, spr[1000h][edi]
                movzx   ebx, ah
                shl     ebx, 2
                mov     var_4, ebx
                shr     edx, 1
                or      edx, spr[1000h][ebx]
                mov     ebx, var_C
                shr     edx, 1
                or      edx, spr[1000h][ebx]
                mov     ebx, buf
                shr     edx, 1
                or      edx, spr[1000h][ebx]
                mov     ebx, isdecrypt
                shr     edx, 1
                or      edx, spr[1000h][ebx]
                shr     eax, 18h
                shl     eax, 2
                mov     ebx, spr[1000h][eax]
                shr     edx, 1
                or      edx, ebx
                shr     ecx, 18h
                shl     ecx, 2
                mov     ebx, spr[1000h][ecx]
                shr     edx, 1
                or      edx, ebx
                mov     ebx, spr[1400h][esi]
                mov     esi, spr[1400h][edi]
                shr     ebx, 1
                or      ebx, esi
                mov     esi, var_4
                mov     edi, spr[1400h][esi]
                mov     esi, var_C
                shr     ebx, 1
                or      ebx, edi
                mov     edi, spr[1400h][esi]
                mov     esi, buf
                shr     ebx, 1
                or      ebx, edi
                mov     edi, spr[1400h][esi]
                mov     esi, isdecrypt
                shr     ebx, 1
                or      ebx, edi
                mov     edi, spr[1400h][esi]
                shr     ebx, 1
                or      ebx, edi
                mov     edi, spr[1400h][eax]
                mov     eax, spr[1400h][ecx]
                shr     ebx, 1
                or      ebx, edi
                shr     ebx, 1
                or      ebx, eax
                mov     eax, edx
                shr     eax, 18h
                mov     ecx, edx
                shr     ecx, 10h
                mov     byte ptr crypt_buf[0], al
                mov     byte ptr crypt_buf[1], cl
                mov     eax, edx
                shr     eax, 8
                mov     byte ptr crypt_buf[3], dl
                mov     byte ptr crypt_buf[2], al
                mov     ecx, ebx
                mov     edx, ebx
                mov     eax, ebx
                pop     edi
                shr     ecx, 18h
                shr     edx, 10h
                shr     eax, 8
                pop     esi
                mov     byte ptr crypt_buf[7], bl
                mov     byte ptr crypt_buf[4], cl
                mov     byte ptr crypt_buf[5], dl
                mov     byte ptr crypt_buf[6], al
				pop		edi
				pop		esi
				pop		edx
				pop		ecx
                pop     ebx
				pop		eax
	}
}

void set_key64(char *arg_0)
{
	wxUint32 var_ebp = 0;

	char varb[8];
	wxUint32 vari[3];

	__asm	{
				push	eax
                push    ebx
				push	ecx
				push	edx
                push    esi
                push    edi
                xor     edi, edi
                mov		var_ebp, 0
                mov     edx, offset spr2+10h
                mov     vari[0], 8

loc_45D3C8:                             ; CODE XREF: sub_45D3B0+51j
                mov     ecx, arg_0
                mov     al, [ecx]
                inc     ecx
                mov     arg_0, ecx
                mov     esi, 7

loc_45D3D8:                             ; CODE XREF: sub_45D3B0+4Bj
                test    al, al
                jns     short loc_45D3F7
                xor     ecx, ecx
                mov     cl, [edx]
                cmp     cl, 1Ch
                mov     ebx, 1
                jb      short loc_45D3F3
                sub     ecx, 1Ch
                shl     ebx, cl
                or      edi, ebx
                jmp     short loc_45D3F7
; ---------------------------------------------------------------------------

loc_45D3F3:                             ; CODE XREF: sub_45D3B0+38j
                shl     ebx, cl
                or      var_ebp, ebx

loc_45D3F7:                             ; CODE XREF: sub_45D3B0+2Aj
                                        ; sub_45D3B0+41j
                inc     edx
                shl     al, 1
                dec     esi
                jnz     short loc_45D3D8
                dec     vari[0]
                jnz     short loc_45D3C8
                mov     dword ptr vari[0], offset spr2
                mov     dword ptr vari[8], offset dword_61D77C

loc_45D413:                             ; CODE XREF: sub_45D3B0+175j
                mov     eax, dword ptr vari[0]
                movzx   eax, byte ptr [eax]
                mov     edx, 1Ch
                sub     edx, eax
                mov     esi, edi
                mov     ecx, edx
                shr     esi, cl
                mov     ecx, eax
                shl     edi, cl
                mov     ecx, edx
                mov     vari[4], 4
                or      esi, edi
                and     esi, 0FFFFFFFh
                mov     edi, esi
                mov     esi, var_ebp
                shr     esi, cl
                mov     ecx, eax
                shl     var_ebp, cl
                lea     eax, varb[0]
                or      esi, var_ebp
                and     esi, 0FFFFFFFh
                mov     var_ebp, esi
                mov     esi, offset spr2+48h
                lea     ebx, [ebx+0]

loc_45D460:                             ; CODE XREF: sub_45D3B0+D5j
                mov     byte ptr [eax], 0
                mov     dl, 20h

loc_45D465:                             ; CODE XREF: sub_45D3B0+C9j
                mov     cl, [esi]
                mov     ebx, edi
                shr     ebx, cl
                and     bl, 1
                inc     esi
                test    bl, bl
                jz      short loc_45D475
                or      [eax], dl

loc_45D475:                             ; CODE XREF: sub_45D3B0+C1j
                shr     dl, 1
                test    dl, dl
                jnz     short loc_45D465
                mov     ecx, dword ptr vari[4]
                inc     eax
                dec     ecx
                mov     dword ptr vari[4], ecx
                jnz     short loc_45D460
                mov     esi, offset spr2+60h
                mov     vari[4], 4

loc_45D494:                             ; CODE XREF: sub_45D3B0+110j
                mov     byte ptr [eax], 0
                mov     dl, 20h
//                lea     esp, [esp+0]

loc_45D4A0:                             ; CODE XREF: sub_45D3B0+104j
                mov     cl, [esi]
                mov     ebx, var_ebp
                shr     ebx, cl
                and     bl, 1
                inc     esi
                test    bl, bl
                jz      short loc_45D4B0
                or      [eax], dl

loc_45D4B0:                             ; CODE XREF: sub_45D3B0+FCj
                shr     dl, 1
                test    dl, dl
                jnz     short loc_45D4A0
                mov     ecx, dword ptr vari[4]
                inc     eax
                dec     ecx
                mov     dword ptr vari[4], ecx
                jnz     short loc_45D494
                movzx   edx, varb[2]
                movzx   eax, varb[4]
                xor     ecx, ecx
                mov     ch, varb[0]
                or      ecx, edx
                movzx   edx, varb[6]
                shl     ecx, 8
                or      ecx, eax
                mov     eax, dword ptr vari[8]
                shl     ecx, 8
                or      ecx, edx
                movzx   edx, varb[3]
                mov     [eax-4], ecx
                movzx   ecx, varb[1]
                shl     ecx, 8
                or      ecx, edx
                movzx   edx, varb[5]
                shl     ecx, 8
                or      ecx, edx
                movzx   edx, varb[7]
                shl     ecx, 8
                or      ecx, edx
                mov     edx, dword ptr vari[0]
                add     eax, 8
                mov     [eax-8], ecx
                inc     edx
                cmp     eax, offset dword_61D77C+32*4
                mov     dword ptr vari[8], eax
                mov     dword ptr vari[0], edx
                jl      loc_45D413
                pop     edi
                pop     esi
				pop		edx
				pop		ecx
                pop     ebx
				pop		eax
	}
}

struct card {
	char magic[4];
	char name[72];
	wxUint32 id[4];
};

card CARD = {"PFT", "", {0x67452301, 0xEFCDAB89, 0x98BADCFE, 0x10325476} };

void gen_card_name(card *crd)
{
	wxUint32 var_ebp = 0;

	wxUint32 varr[16];

	wxUint32 var_44 = 0;

	__asm {
                push    eax
                push    ebx
                push    ecx
                push    edx
                push    esi
                push    edi
                mov     eax, crd
				// my
				mov		ecx, eax
				add		ecx, 4
				// my
                add     ecx, 2
                lea     esi, varr[0]
                mov     edi, 10h

loc_45A827:                             ; CODE XREF: sub_45A810+3Bj
                movzx   ebx, byte ptr [ecx-1]
                xor     edx, edx
                mov     dh, [ecx+1]
                add     esi, 4
                add     ecx, 4
                mov     dl, [ecx-4]
                shl     edx, 8
                or      edx, ebx
                movzx   ebx, byte ptr [ecx-6]
                shl     edx, 8
                or      edx, ebx
                dec     edi
                mov     [esi-4], edx
                jnz     short loc_45A827
                mov     esi, [eax+50h]
                mov     edi, [eax+54h]
                mov     edx, [eax+58h]
                mov     eax, [eax+4Ch]
					push eax
					mov  eax, varr[0]
					mov	 var_ebp, eax
					pop eax
                mov     ebx, edi
                and     ebx, esi
                mov     ecx, esi
                not     ecx
                and     ecx, edx
                or      ecx, ebx
                add     ecx, var_ebp
                lea     ecx, [eax+ecx-28955B88h]
					push eax
					mov  eax, varr[4]
					mov	 var_ebp, eax
					pop eax
                mov     eax, ecx
                shl     ecx, 7
                shr     eax, 19h
                or      eax, ecx
                add     eax, esi
                mov     ecx, eax
                not     ecx
                and     ecx, edi
                mov     ebx, esi
                and     ebx, eax
                or      ecx, ebx
                add     ecx, var_ebp
					push eax
					mov  eax, varr[8]
					mov	 var_ebp, eax
					pop eax
                lea     edx, [edx+ecx-173848AAh]
                mov     ecx, edx
                shl     edx, 0Ch
                shr     ecx, 14h
                or      ecx, edx
                add     ecx, eax
                mov     edx, ecx
                not     edx
                and     edx, esi
                mov     ebx, ecx
                and     ebx, eax
                or      edx, ebx
                add     edx, var_ebp
                lea     edi, [edi+edx+242070DBh]
                mov     edx, edi
					push eax
					mov  eax, varr[0Ch]
					mov	 var_ebp, eax
					pop eax
                shl     edi, 11h
                shr     edx, 0Fh
                or      edx, edi
                add     edx, ecx
                mov     edi, edx
                not     edi
                and     edi, eax
                mov     ebx, ecx
                and     ebx, edx
                or      edi, ebx
                add     edi, var_ebp
					push eax
					mov  eax, varr[10h]
					mov	 var_ebp, eax
					pop eax
                lea     edi, [esi+edi-3E423112h]
                mov     esi, edi
                shr     edi, 0Ah
                shl     esi, 16h
                or      esi, edi
                add     esi, edx
                mov     edi, esi
                not     edi
                and     edi, ecx
                mov     ebx, edx
                and     ebx, esi
                or      edi, ebx
                add     edi, var_ebp
					push eax
					mov  eax, varr[14h]
					mov	 var_ebp, eax
					pop eax
                lea     edi, [eax+edi-0A83F051h]
                mov     eax, edi
                shl     edi, 7
                shr     eax, 19h
                or      eax, edi
                add     eax, esi
                mov     edi, eax
                not     edi
                mov     ebx, esi
                and     edi, edx
                and     ebx, eax
                or      edi, ebx
                add     edi, var_ebp
                lea     edi, [ecx+edi+4787C62Ah]
                mov     ecx, edi
                shl     edi, 0Ch
					push eax
					mov  eax, varr[18h]
					mov	 var_ebp, eax
					pop eax
                shr     ecx, 14h
                or      ecx, edi
                add     ecx, eax
                mov     edi, ecx
                not     edi
                and     edi, esi
                mov     ebx, ecx
                and     ebx, eax
                or      edi, ebx
                add     edi, var_ebp
                lea     edi, [edx+edi-57CFB9EDh]
                mov     edx, edi
                shl     edi, 11h
					push eax
					mov  eax, varr[1Ch]
					mov	 var_ebp, eax
					pop eax
                shr     edx, 0Fh
                or      edx, edi
                add     edx, ecx
                mov     edi, edx
                not     edi
                and     edi, eax
                mov     ebx, ecx
                and     ebx, edx
                or      edi, ebx
                add     edi, var_ebp
                lea     edi, [esi+edi-2B96AFFh]
                mov     esi, edi
                shr     edi, 0Ah
					push eax
					mov  eax, varr[20h]
					mov	 var_ebp, eax
					pop eax
                shl     esi, 16h
                or      esi, edi
                add     esi, edx
                mov     ebx, edx
                and     ebx, esi
                mov     edi, esi
                not     edi
                and     edi, ecx
                or      edi, ebx
                add     edi, var_ebp
                lea     edi, [eax+edi+698098D8h]
					push eax
					mov  eax, varr[24h]
					mov	 var_ebp, eax
					pop eax
                mov     eax, edi
                shl     edi, 7
                shr     eax, 19h
                or      eax, edi
                add     eax, esi
                mov     edi, eax
                not     edi
                and     edi, edx
                mov     ebx, esi
                and     ebx, eax
                or      edi, ebx
                add     edi, var_ebp
					push eax
					mov  eax, varr[28h]
					mov	 var_ebp, eax
					pop eax
                lea     edi, [ecx+edi-74BB0851h]
                mov     ecx, edi
                shl     edi, 0Ch
                shr     ecx, 14h
                or      ecx, edi
                add     ecx, eax
                mov     edi, ecx
                not     edi
                and     edi, esi
                mov     ebx, ecx
                and     ebx, eax
                or      edi, ebx
                add     edi, var_ebp
                lea     edi, [edx+edi-0A44Fh]
                mov     edx, edi
                shl     edi, 11h
                shr     edx, 0Fh
                or      edx, edi
                add     edx, ecx
                mov     edi, edx
                not     edi
                and     edi, eax
                mov     ebx, ecx
					push eax
					mov  eax, varr[2Ch]
					mov	 var_ebp, eax
					pop eax
                and     ebx, edx
                or      edi, ebx
                add     edi, var_ebp
                lea     edi, [esi+edi-76A32842h]
                mov     esi, edi
                shr     edi, 0Ah
					push eax
					mov  eax, varr[30h]
					mov	 var_ebp, eax
					pop eax
                shl     esi, 16h
                or      esi, edi
                add     esi, edx
                mov     edi, esi
                not     edi
                and     edi, ecx
                mov     ebx, edx
                and     ebx, esi
                or      edi, ebx
                add     edi, var_ebp
                lea     edi, [eax+edi+6B901122h]
					push eax
					mov  eax, varr[34h]
					mov	 var_ebp, eax
					pop eax
                mov     eax, edi
                shl     edi, 7
                shr     eax, 19h
                or      eax, edi
                add     eax, esi
                mov     edi, eax
                not     edi
                and     edi, edx
                mov     ebx, esi
                and     ebx, eax
                or      edi, ebx
                add     edi, var_ebp
                lea     edi, [ecx+edi-2678E6Dh]
                mov     ecx, edi
                shl     edi, 0Ch
                shr     ecx, 14h
                or      ecx, edi
                add     ecx, eax
                mov     edi, ecx
                not     edi
                mov     ebx, edi
                and     ebx, esi
                mov     var_ebp, ecx
                and     var_ebp, eax
                or      ebx, var_ebp
                add     ebx, varr[38h]
                lea     ebx, [edx+ebx-5986BC72h]
                mov     edx, ebx
                shl     ebx, 11h
                shr     edx, 0Fh
                or      edx, ebx
                add     edx, ecx
                mov     ebx, edx
                not     ebx
                mov     var_44, ebx
                and     ebx, eax
                mov     var_ebp, ecx
                and     var_ebp, edx
                or      ebx, var_ebp
					push eax
					mov  eax, varr[3Ch]
					mov	 var_ebp, eax
					pop eax
                add     ebx, var_ebp
                lea     ebx, [esi+ebx+49B40821h]
                mov     esi, ebx
                shr     ebx, 0Ah
                shl     esi, 16h
                or      esi, ebx
                and     edi, edx
                add     esi, edx
                mov     ebx, ecx
                and     ebx, esi
                or      edi, ebx
                add     edi, varr[4]
                lea     edi, [eax+edi-9E1DA9Eh]
                mov     eax, edi
                shl     edi, 5
                shr     eax, 1Bh
                or      eax, edi
                mov     edi, var_44
                add     eax, esi
                and     edi, esi
                mov     ebx, edx
                and     ebx, eax
                or      edi, ebx
                add     edi, varr[18h]
                lea     edi, [ecx+edi-3FBF4CC0h]
                mov     ecx, edi
                shl     edi, 9
                shr     ecx, 17h
                or      ecx, edi
                add     ecx, eax
                mov     edi, esi
                not     edi
                and     edi, eax
                mov     ebx, ecx
                and     ebx, esi
                or      edi, ebx
                add     edi, varr[2Ch]
                lea     edi, [edx+edi+265E5A51h]
                mov     edx, edi
                shl     edi, 0Eh
                shr     edx, 12h
                or      edx, edi
                add     edx, ecx
                mov     edi, eax
                not     edi
                and     edi, ecx
                mov     ebx, edx
                and     ebx, eax
                or      edi, ebx
                add     edi, varr[0]
                lea     edi, [esi+edi-16493856h]
                mov     esi, edi
                shr     edi, 0Ch
                shl     esi, 14h
                or      esi, edi
                add     esi, edx
                mov     edi, ecx
                not     edi
                and     edi, edx
                mov     ebx, ecx
                and     ebx, esi
                or      edi, ebx
                add     edi, varr[14h]
                lea     edi, [eax+edi-29D0EFA3h]
                mov     eax, edi
                shl     edi, 5
                shr     eax, 1Bh
                or      eax, edi
                mov     edi, edx
                not     edi
                and     edi, esi
                mov     ebx, edx
                add     eax, esi
                and     ebx, eax
                or      edi, ebx
                add     edi, varr[28h]
                lea     edi, [ecx+edi+2441453h]
                mov     ecx, edi
                shl     edi, 9
                shr     ecx, 17h
                or      ecx, edi
                add     ecx, eax
                mov     edi, esi
                not     edi
                and     edi, eax
                mov     ebx, ecx
                and     ebx, esi
                or      edi, ebx
                add     edi, var_ebp
                lea     edi, [edx+edi-275E197Fh]
                mov     edx, edi
                shr     edx, 12h
                shl     edi, 0Eh
                or      edx, edi
                add     edx, ecx
                mov     edi, eax
                not     edi
                and     edi, ecx
                mov     ebx, edx
                and     ebx, eax
                or      edi, ebx
                add     edi, varr[10h]
                lea     edi, [esi+edi-182C0438h]
                mov     esi, edi
                shr     edi, 0Ch
                shl     esi, 14h
                or      esi, edi
                add     esi, edx
                mov     edi, ecx
                not     edi
                and     edi, edx
                mov     ebx, ecx
                and     ebx, esi
                or      edi, ebx
                add     edi, varr[24h]
                lea     edi, [eax+edi+21E1CDE6h]
                mov     eax, edi
                shl     edi, 5
                shr     eax, 1Bh
                or      eax, edi
                add     eax, esi
                mov     edi, edx
                not     edi
                and     edi, esi
                mov     ebx, edx
                and     ebx, eax
                or      edi, ebx
                add     edi, varr[38h]
                lea     edi, [ecx+edi-3CC8F82Ah]
                mov     ecx, edi
                shl     edi, 9
                shr     ecx, 17h
                or      ecx, edi
                add     ecx, eax
                mov     edi, esi
                not     edi
                and     edi, eax
                mov     ebx, ecx
                and     ebx, esi
                or      edi, ebx
                add     edi, varr[0Ch]
                lea     edi, [edx+edi-0B2AF279h]
                mov     edx, edi
                shl     edi, 0Eh
                shr     edx, 12h
                or      edx, edi
                add     edx, ecx
                mov     edi, eax
                not     edi
                and     edi, ecx
                mov     ebx, edx
                and     ebx, eax
                or      edi, ebx
                add     edi, varr[20h]
                lea     edi, [esi+edi+455A14EDh]
                mov     esi, edi
                shr     edi, 0Ch
                shl     esi, 14h
                or      esi, edi
                mov     edi, ecx
                not     edi
                add     esi, edx
                and     edi, edx
                mov     ebx, ecx
                and     ebx, esi
                or      edi, ebx
                add     edi, varr[34h]
                lea     edi, [eax+edi-561C16FBh]
                mov     eax, edi
                shr     eax, 1Bh
                shl     edi, 5
                or      eax, edi
                add     eax, esi
                mov     edi, edx
                not     edi
                and     edi, esi
                mov     ebx, edx
                and     ebx, eax
                or      edi, ebx
                add     edi, varr[8]
                lea     edi, [ecx+edi-3105C08h]
                mov     ecx, edi
                shl     edi, 9
                shr     ecx, 17h
                or      ecx, edi
                add     ecx, eax
                mov     ebx, ecx
                and     ebx, esi
                mov     edi, esi
                not     edi
                and     edi, eax
                or      edi, ebx
                add     edi, varr[1Ch]
                lea     edi, [edx+edi+676F02D9h]
                mov     edx, edi
                shl     edi, 0Eh
                shr     edx, 12h
                or      edx, edi
                add     edx, ecx
                mov     edi, eax
                not     edi
                and     edi, ecx
                mov     ebx, edx
                and     ebx, eax
                or      edi, ebx
                add     edi, varr[30h]
                mov     ebx, varr[14h]
                lea     edi, [esi+edi-72D5B376h]
                mov     esi, edi
                shr     edi, 0Ch
                shl     esi, 14h
                or      esi, edi
                mov     edi, ecx
                xor     edi, edx
                add     esi, edx
                xor     edi, esi
                add     edi, ebx
                mov     ebx, varr[20h]
                lea     edi, [eax+edi-5C6BEh]
                mov     eax, edi
                shl     edi, 4
                shr     eax, 1Ch
                or      eax, edi
                mov     edi, edx
                xor     edi, esi
                add     eax, esi
                xor     edi, eax
                add     edi, ebx
                mov     ebx, varr[2Ch]
                lea     ecx, [ecx+edi-788E097Fh]
                mov     edi, ecx
                shl     ecx, 0Bh
                shr     edi, 15h
                or      edi, ecx
                add     edi, eax
                mov     ecx, edi
                xor     ecx, esi
                xor     ecx, eax
                add     ecx, ebx
                lea     ecx, [edx+ecx+6D9D6122h]
                mov     edx, ecx
                shr     edx, 10h
                shl     ecx, 10h
                or      edx, ecx
                add     edx, edi
                mov     ebx, edi
                xor     ebx, edx
                mov     ecx, ebx
                xor     ecx, eax
                add     ecx, varr[38h]
                lea     esi, [esi+ecx-21AC7F4h]
                mov     ecx, esi
                shr     esi, 9
                shl     ecx, 17h
                or      ecx, esi
                mov     esi, varr[4]
                add     ecx, edx
                xor     ebx, ecx
                add     ebx, esi
                lea     ebx, [eax+ebx-5B4115BCh]
                mov     eax, ebx
                shl     ebx, 4
                shr     eax, 1Ch
                or      eax, ebx
                mov     ebx, varr[10h]
                add     eax, ecx
                mov     esi, edx
                xor     esi, ecx
                xor     esi, eax
                add     esi, ebx
                lea     edi, [edi+esi+4BDECFA9h]
                mov     esi, edi
                shl     edi, 0Bh
                mov     ebx, varr[1Ch]
                shr     esi, 15h
                or      esi, edi
                add     esi, eax
                mov     edi, esi
                xor     edi, ecx
                xor     edi, eax
                add     edi, ebx
                lea     edi, [edx+edi-944B4A0h]
                mov     edx, edi
                shl     edi, 10h
                shr     edx, 10h
                or      edx, edi
                add     edx, esi
                mov     edi, esi
                xor     edi, edx
                mov     ebx, edi
                xor     ebx, eax
                add     ebx, varr[28h]
                lea     ebx, [ecx+ebx-41404390h]
                mov     ecx, ebx
                shr     ebx, 9
                shl     ecx, 17h
                or      ecx, ebx
                mov     ebx, varr[34h]
                add     ecx, edx
                xor     edi, ecx
                add     edi, ebx
                mov     ebx, varr[0]
                lea     edi, [eax+edi+289B7EC6h]
                mov     eax, edi
                shl     edi, 4
                shr     eax, 1Ch
                or      eax, edi
                mov     edi, edx
                xor     edi, ecx
                add     eax, ecx
                xor     edi, eax
                add     edi, ebx
                mov     ebx, varr[0Ch]
                lea     edi, [esi+edi-155ED806h]
                mov     esi, edi
                shl     edi, 0Bh
                shr     esi, 15h
                or      esi, edi
                add     esi, eax
                mov     edi, esi
                xor     edi, ecx
                xor     edi, eax
                add     edi, ebx
                lea     edx, [edx+edi-2B10CF7Bh]
                mov     edi, edx
                shr     edi, 10h
                shl     edx, 10h
                or      edi, edx
                add     edi, esi
                mov     edx, esi
                xor     edx, edi
                mov     ebx, edx
                xor     ebx, eax
                add     ebx, varr[18h]
                lea     ebx, [ecx+ebx+4881D05h]
                mov     ecx, ebx
                shr     ebx, 9
                shl     ecx, 17h
                or      ecx, ebx
                add     ecx, edi
                mov     ebx, varr[24h]
                xor     edx, ecx
                add     edx, ebx
                mov     ebx, varr[30h]
                lea     edx, [eax+edx-262B2FC7h]
                mov     eax, edx
                shl     edx, 4
                shr     eax, 1Ch
                or      eax, edx
                mov     edx, edi
                xor     edx, ecx
                add     eax, ecx
                xor     edx, eax
                add     edx, ebx
                lea     esi, [esi+edx-1924661Bh]
                mov     edx, esi
                shl     esi, 0Bh
                mov     ebx, varr[8]
                shr     edx, 15h
                or      edx, esi
                add     edx, eax
                mov     esi, edx
                xor     esi, ecx
                xor     esi, eax
                add     esi, var_ebp
                lea     edi, [edi+esi+1FA27CF8h]
                mov     esi, edi
                shl     edi, 10h
                shr     esi, 10h
                or      esi, edi
                add     esi, edx
                mov     edi, edx
                xor     edi, esi
                xor     edi, eax
                add     edi, ebx
                lea     edi, [ecx+edi-3B53A99Bh]
                mov     ebx, varr[0]
                mov     ecx, edi
                shr     edi, 9
                shl     ecx, 17h
                or      ecx, edi
                mov     edi, edx
                not     edi
                add     ecx, esi
                or      edi, ecx
                xor     edi, esi
                add     edi, ebx
                mov     ebx, varr[1Ch]
                lea     edi, [eax+edi-0BD6DDBCh]
                mov     eax, edi
                shl     edi, 6
                shr     eax, 1Ah
                or      eax, edi
                add     eax, ecx
                mov     edi, esi
                not     edi
                or      edi, eax
                xor     edi, ecx
                add     edi, ebx
                mov     ebx, varr[38h]
                lea     edi, [edx+edi+432AFF97h]
                mov     edx, edi
                shl     edi, 0Ah
                shr     edx, 16h
                or      edx, edi
                mov     edi, ecx
                add     edx, eax
                not     edi
                or      edi, edx
                xor     edi, eax
                add     edi, ebx
                lea     edi, [esi+edi-546BDC59h]
                mov     esi, edi
                shl     edi, 0Fh
                mov     ebx, varr[14h]
                shr     esi, 11h
                or      esi, edi
                add     esi, edx
                mov     edi, eax
                not     edi
                or      edi, esi
                xor     edi, edx
                add     edi, ebx
                lea     edi, [ecx+edi-36C5FC7h]
                mov     ecx, edi
                shr     edi, 0Bh
                mov     ebx, varr[30h]
                shl     ecx, 15h
                or      ecx, edi
                add     ecx, esi
                mov     edi, edx
                not     edi
                or      edi, ecx
                xor     edi, esi
                add     edi, ebx
                lea     edi, [eax+edi+655B59C3h]
                mov     eax, edi
                shl     edi, 6
                mov     ebx, varr[0Ch]
                shr     eax, 1Ah
                or      eax, edi
                add     eax, ecx
                mov     edi, esi
                not     edi
                or      edi, eax
                xor     edi, ecx
                add     edi, ebx
                lea     edi, [edx+edi-70F3336Eh]
                mov     edx, edi
                shl     edi, 0Ah
                mov     ebx, varr[28h]
                shr     edx, 16h
                or      edx, edi
                add     edx, eax
                mov     edi, ecx
                not     edi
                or      edi, edx
                xor     edi, eax
                add     edi, ebx
                lea     edi, [esi+edi-100B83h]
                mov     ebx, varr[4]
                mov     esi, edi
                shl     edi, 0Fh
                shr     esi, 11h
                or      esi, edi
                mov     edi, eax
                not     edi
                add     esi, edx
                or      edi, esi
                xor     edi, edx
                add     edi, ebx
                mov     ebx, varr[20h]
                lea     edi, [ecx+edi-7A7BA22Fh]
                mov     ecx, edi
                shr     edi, 0Bh
                shl     ecx, 15h
                or      ecx, edi
                mov     edi, edx
                not     edi
                add     ecx, esi
                or      edi, ecx
                xor     edi, esi
                add     edi, ebx
                lea     edi, [eax+edi+6FA87E4Fh]
                mov     eax, edi
                shl     edi, 6
                shr     eax, 1Ah
                or      eax, edi
                mov     edi, esi
                add     eax, ecx
                not     edi
                or      edi, eax
                xor     edi, ecx
                add     edi, var_ebp
                lea     edi, [edx+edi-1D31920h]
                mov     edx, edi
                shl     edi, 0Ah
					push eax
					mov  eax, varr[18h]
					mov	 var_ebp, eax
					pop eax
                shr     edx, 16h
                or      edx, edi
                add     edx, eax
                mov     edi, ecx
                not     edi
                or      edi, edx
                xor     edi, eax
                add     edi, var_ebp
                lea     edi, [esi+edi-5CFEBCECh]
                mov     esi, edi
                shl     edi, 0Fh
					push eax
					mov  eax, varr[34h]
					mov	 var_ebp, eax
					pop eax
                shr     esi, 11h
                or      esi, edi
                add     esi, edx
                mov     edi, eax
                not     edi
                or      edi, esi
                xor     edi, edx
                add     edi, var_ebp
                lea     edi, [ecx+edi+4E0811A1h]
                mov     ecx, edi
                shr     edi, 0Bh
					push eax
					mov  eax, varr[10h]
					mov	 var_ebp, eax
					pop eax
                shl     ecx, 15h
                or      ecx, edi
                add     ecx, esi
                mov     edi, edx
                not     edi
                or      edi, ecx
                xor     edi, esi
                add     edi, var_ebp
                lea     edi, [eax+edi-8AC817Eh]
					push eax
					mov  eax, varr[2Ch]
					mov	 var_ebp, eax
					pop eax
                mov     eax, edi
                shl     edi, 6
                shr     eax, 1Ah
                or      eax, edi
                mov     edi, esi
                not     edi
                add     eax, ecx
                or      edi, eax
                xor     edi, ecx
                add     edi, var_ebp
					push eax
					mov  eax, varr[8]
					mov	 var_ebp, eax
					pop eax
                lea     edi, [edx+edi-42C50DCBh]
                mov     edx, edi
                shl     edi, 0Ah
                mov     ebx, varr[24h]
                shr     edx, 16h
                or      edx, edi
                add     edx, eax
                mov     edi, ecx
                not     edi
                or      edi, edx
                xor     edi, eax
                add     edi, var_ebp
                lea     esi, [esi+edi+2AD7D2BBh]
                mov     edi, esi
                shl     esi, 0Fh
                shr     edi, 11h
                or      edi, esi
                mov     esi, eax
                not     esi
                add     edi, edx
                or      esi, edi
                xor     esi, edx
                add     esi, ebx
                lea     ecx, [ecx+esi-14792C6Fh]
                mov     esi, crd
                mov     ebx, [esi+4Ch]
                add     ebx, eax
                mov     [esi+4Ch], ebx
                mov     eax, ecx
                mov     ebx, [esi+50h]
                shl     eax, 15h
                shr     ecx, 0Bh
                or      eax, ecx
                add     eax, ebx
                add     eax, edi
                mov     [esi+50h], eax
                mov     eax, [esi+54h]
                add     eax, edi
                mov     [esi+54h], eax
                mov     eax, [esi+58h]
                add     eax, edx
                mov     [esi+58h], eax

				pop		edi
				pop		esi
				pop		edx
				pop		ecx
                pop     ebx
				pop		eax
	}
}

void crypt(char *buf, int len, int param)
{
	len = (len+7)&0xfffffff8;

	while (len>=8) {
		memcpy(crypt_buf, buf, 8);
		des_decrypt(param);
		memcpy(buf, crypt_buf, 8);
		buf+=8;
		len-=8;
	}
}

void unpack_key(login_pkt *pkt)
{
	for (int index=0; index<8; index++) {
		char h[3];
		int c;
		strncpy(h, pkt->key+index*2, 2);
		h[2] = 0;
		sscanf(h, "%x", &c);
		pkt->key[index] = ~c;
	}
	pkt->key[7] = 0;
}

void bin2hex(unsigned char *bin, char *str, int len)
{
	*str = 0;
	for (int index=0; index<len; index++) {
		char h[8];
		sprintf(h, "%02X", bin[index]);
		strcat(str, h);
	}
}

bool client::Create(TCPSocket& socket, int port, int protocol, wxUint32 address)
{
	m_port = port;
	m_protocol = protocol;
	m_address = address;

	if (!m_sock.Attach(socket))
		return false;

	m_sock.SetBlockMode(true);

	if (wxThread::Create()!=wxTHREAD_NO_ERROR)
		return false;

	return true;
}

wxString unstr(const char *str, int len)
{
	wxString res;

	for (int index=0; index<len; index++) {
		if (str[index])
			res+=str[index];
	}

	return res;
}

wxString msg1 = _T("Now we will use local verification:o)");
wxString msg2 = _T("Enjoy!");

/*
wxUint8 limohu9999[232] = {0xE8,0x39,0x9D,0x61,0x33,0x25,0x7C,0x1B,0x0A,0xC2,0x0F,0x06,0xA1,0x1A,0x06,0x40,0xB3,0x7B,0x66,0xBE,0xA4,0xEA,0x28,0x11,0x80,0xDC,0xA0,0x78,0xD5,0xAF,0xD4,0x1D,0xCA,0xAC,0x31,0xC8,0x90,0x37,0xF6,0x43,0x0A,0x08,0xC8,0xAB,0xEE,0x8C,0x65,0x89,0x0E,0x49,0x6B,0x55,0x06,0xD2,0x79,0x53,0xF3,0xED,0x92,0x5C,0x1B,0x28,0x72,0x61,0x49,0xE3,0x06,0xE8,0x7C,0xE7,0xD2,0x84,0xE8,0x8D,0xDD,0x7F,0x8F,0x69,0xDE,0x12,0xF7,0xD5,0x32,0x9C,0x7E,0x55,0xBF,0x35,0x6C,0x32,0xE9,0xF1,0xD7,0xFC,0x0E,0x41,0x8D,0x4B,0xFA,0xF6,0x85,0xF4,0x04,0x74,0xF0,0x8F,0xD9,0x07,0xBB,0xF3,0x7B,0x71,0x17,0x99,0x0F,0xE1,0xFC,0xEE,0x7E,0x42,0x6D,0x36,0x4A,0x1C,0x0F,0xE0,0x33,0xD4,0xF1,0x5A,0xCF,0xB0,0x3A,0xB2,0x4C,0xB7,0x8C,0x43,0x29,0xF4,0x5E,0xAE,0x7A,0x53,0xD5,0x2E,0x00,0xA6,0xDD,0xDA,0xD3,0xF0,0xBA,0x95,0x5A,0xA7,0x4B,0x58,0x0A,0x5C,0x0F,0x1F,0x2E,0x2E,0x1E,0x44,0xF0,0x5F,0x17,0x4E,0x29,0x26,0x89,0x51,0x8B,0x8D,0xC6,0x1E,0xD5,0xA2,0xAC,0x79,0x83,0xE1,0xFE,0x12,0xAD,0xA1,0x37,0x58,0xD1,0x0F,0xDF,0x16,0xB8,0xB4,0xE0,0x2B,0x86,0x2B,0xB9,0x45,0x4B,0xBE,0xEA,0x26,0xDD,0xCA,0x03,0x4D,0xAF,0x98,0xBB,0x43,0x26,0xDD,0xCA,0xAC,0x31,0xC8,0x90,0x37,0xF6,0x43,0xCE,0x7F,0x8C,0x32,0x4A,0x97,0xE4,0x00};
wxUint8 zoophyte2000[232]={0x98,0xD5,0x03,0xC6,0x84,0x9B,0xA1,0x09,0xCF,0xA5,0xA9,0x7C,0x03,0xE0,0x6D,0x35,0x73,0xF1,0x7A,0xAC,0xF0,0x90,0xCD,0xA5,0x57,0xDE,0x0F,0x24,0x11,0xE2,0xB8,0x14,0xC6,0x14,0x10,0xF0,0x74,0xDE,0xA1,0xC9,0xA9,0xCE,0x30,0xD7,0x13,0x9B,0x99,0xF8,0x9A,0xFF,0x84,0x38,0x9C,0xA8,0x0B,0x11,0xDE,0x28,0x14,0x5A,0x3C,0xAD,0x24,0xDD,0xDD,0x13,0x17,0x9B,0x56,0xD3,0x1A,0xDE,0x01,0xD9,0x90,0xCB,0xD4,0xF4,0x23,0xC7,0x3E,0xED,0xC8,0xF8,0x4D,0xCA,0x93,0x5B,0x25,0xAB,0x9E,0x77,0x15,0xB1,0x40,0xEA,0x54,0x18,0x26,0x09,0x99,0x69,0x7B,0x2B,0x28,0xB3,0x56,0xB2,0xD1,0x75,0xAC,0x59,0x94,0x43,0x28,0x34,0x15,0x05,0xAB,0xCB,0x92,0xB5,0xDD,0xFF,0xD1,0xDC,0x29,0x68,0xA0,0x52,0xF8,0x5F,0x52,0xCA,0x2A,0x20,0x81,0xB0,0x1C,0x4F,0xA3,0x8E,0xD3,0x68,0x4E,0xB2,0x5F,0x82,0x2C,0x61,0x7E,0x1F,0x24,0xBA,0xA2,0x53,0x33,0x2B,0xA7,0xD2,0x0B,0xA3,0x4F,0x8C,0x08,0x15,0x9A,0x27,0x15,0xAB,0xEC,0x45,0x4F,0x01,0x1C,0x90,0x2F,0xC8,0x08,0x76,0xEA,0x6A,0xBF,0x74,0xC0,0x4B,0xA2,0xA2,0x2D,0xF8,0x45,0x6B,0x8C,0x13,0x37,0x58,0x2B,0xFF,0x80,0x0A,0x75,0x0B,0xD7,0x05,0x7F,0x40,0x94,0x23,0x8E,0x9C,0x79,0xA4,0x73,0xE3,0xF0,0x5E,0xC6,0x14,0x10,0xF0,0x74,0xDE,0xA1,0xC9,0x59,0xCD,0x29,0xDA,0xAF,0xE8,0xC1,0x00};
wxUint8 zoophyte2001[232]={0x52,0xE7,0x68,0x4D,0x55,0x20,0x63,0x71,0x8F,0xC4,0xD2,0xE5,0x09,0xFB,0x79,0x67,0x0B,0x5D,0xB3,0xCD,0x82,0x1B,0x62,0xA6,0x5E,0x01,0x8F,0x10,0x3D,0x93,0xD4,0x62,0x94,0x09,0x2A,0x94,0x16,0x3C,0x5C,0xAD,0xC4,0x1D,0xC9,0xBF,0xB3,0x2C,0x0B,0x34,0xE8,0x36,0x99,0xB1,0xA7,0xC4,0x38,0x88,0xCE,0x70,0x39,0xE9,0x79,0xDA,0xC8,0x15,0xB5,0x05,0x38,0xFA,0x4F,0xF2,0x62,0xCE,0xB4,0x8B,0x47,0xE6,0x40,0xC4,0x70,0x02,0x4A,0x16,0x4A,0x85,0x73,0x01,0x8D,0x15,0xCB,0x7A,0x7F,0x74,0xA9,0xC9,0x20,0x44,0x5F,0xC6,0x05,0xC7,0xA9,0x81,0x9D,0x0B,0x4B,0xDE,0x6F,0x27,0x97,0x04,0xEA,0xA3,0x1A,0xD6,0xB0,0xD2,0x9D,0xD8,0xB4,0x09,0x63,0x33,0x0F,0x4A,0xA1,0x23,0x3E,0x67,0x1B,0x1F,0x4B,0xEA,0x98,0x8C,0x22,0xF9,0xE3,0x7F,0x15,0xF9,0x0F,0x85,0x88,0xDC,0x17,0x0E,0xCE,0x4E,0xCF,0xEB,0x96,0x33,0x33,0x01,0x90,0xB7,0x4B,0x4A,0xC0,0xF1,0xFC,0x5F,0xDA,0x66,0x34,0x1E,0x3F,0x30,0xDB,0x73,0xAD,0x7A,0xF1,0xD8,0x50,0xBA,0x0C,0xF9,0x66,0xC8,0xD4,0x33,0xA3,0xD8,0xF3,0xE0,0xA4,0x3F,0x0C,0xA8,0x8D,0xF2,0x45,0x09,0xE3,0x0A,0x4C,0x49,0x25,0xCD,0xA6,0x89,0x7D,0xA7,0xB6,0xB9,0x14,0x72,0x60,0x35,0xC0,0x15,0xE4,0xDF,0x18,0x23,0x94,0x09,0x2A,0x94,0x16,0x3C,0x5C,0xAD,0x7A,0x8F,0xBF,0x91,0xE7,0xB4,0x4F,0x00};
wxUint8 oooooooooooo[232]={0x40,0x21,0x3A,0x63,0xB9,0x91,0x13,0x54,0xD0,0x8B,0xD9,0x7B,0x03,0xC6,0x4A,0x1E,0x29,0xA7,0xEC,0x42,0x17,0xB9,0x7F,0xB4,0x6C,0x3C,0xE1,0x18,0x5C,0x9D,0x5C,0xBD,0x59,0xA3,0x21,0x2F,0x9E,0x18,0x14,0xDD,0xBB,0xE6,0xE4,0x2E,0xDF,0xAA,0x78,0x98,0xB1,0x45,0x03,0x36,0x7D,0x69,0xCA,0xD6,0xB1,0x45,0x03,0x36,0x7D,0x69,0xCA,0xD6,0x83,0x27,0x0B,0x54,0x70,0xFF,0xB6,0xCE,0x6E,0xEE,0xC3,0x32,0x52,0xEF,0x31,0xC2,0x72,0x3A,0x5C,0x46,0x44,0xF3,0x41,0xD9,0x9B,0x9A,0x64,0xB6,0x03,0x6E,0x60,0x2B,0xDA,0x7F,0x31,0x78,0x97,0x8C,0x36,0xD8,0xBF,0x62,0x3D,0x63,0x7A,0xED,0xC5,0xAF,0xE2,0xCD,0x53,0x67,0x99,0x48,0x42,0xAC,0x1D,0x18,0x3A,0xA0,0x2C,0xE6,0xAD,0xF8,0xB9,0x57,0xD4,0x62,0x3F,0x43,0x74,0x99,0x83,0x5F,0x77,0x9A,0xDF,0x2F,0x42,0x6B,0x86,0x39,0x31,0x29,0x93,0xED,0x27,0x42,0x15,0xEA,0x74,0x83,0xF1,0xE4,0x1D,0xE4,0x0F,0xEC,0xFE,0x41,0x22,0x46,0x62,0x35,0x69,0x49,0x35,0x7E,0x91,0x23,0xD5,0x1A,0x55,0xFC,0xD8,0x87,0x94,0x7B,0x11,0xAF,0x5E,0xA9,0x2B,0x6F,0x8F,0xBB,0x12,0x3F,0xA6,0x8E,0x04,0x99,0x04,0xD6,0x2E,0x77,0x85,0xD7,0x59,0xBD,0x3F,0x6F,0xCE,0xF5,0x93,0x17,0xC3,0x32,0xCC,0xAC,0xD8,0x08,0x59,0xA3,0x21,0x2F,0x9E,0x18,0x14,0xDD,0xDB,0x1B,0xA6,0x93,0xCF,0x05,0xD3,0x00};
wxUint8 oooooooo2000[232]={0x7B,0x17,0x2E,0x05,0xB2,0x96,0x5D,0x85,0x4F,0xFC,0x35,0x48,0x00,0xE6,0x28,0x1A,0x49,0xDA,0x24,0x88,0x55,0x9B,0x92,0xA2,0xED,0xE3,0xB9,0x55,0x46,0x4D,0x48,0xAF,0x4A,0x23,0x6E,0xE4,0x69,0x88,0x5B,0x86,0x8F,0xC5,0xE2,0xDC,0x65,0x16,0x6C,0x03,0x04,0x80,0x19,0xE1,0x2E,0x37,0xF8,0x52,0xEE,0x06,0xE3,0x58,0xD2,0x27,0x01,0x73,0x4F,0xC9,0x83,0x66,0x54,0x27,0x33,0xB0,0x62,0xBD,0xBF,0x17,0x5D,0x03,0xB4,0x16,0x4A,0xD9,0x64,0x96,0x68,0x15,0x48,0x96,0xC2,0xD7,0x54,0x1E,0x8B,0xAA,0x98,0xD4,0xD2,0xE2,0x59,0x35,0x73,0x15,0x0A,0x27,0xE8,0x4F,0xE7,0xB5,0x3C,0x09,0xA3,0xC7,0xF9,0x58,0x83,0xCC,0x70,0xF7,0xC0,0x3D,0x00,0x10,0x71,0x3F,0xCE,0xC3,0x40,0x40,0x80,0x3C,0x0E,0x37,0x9C,0x82,0xAA,0x31,0xC5,0x15,0x09,0xA8,0x61,0x27,0x00,0x14,0x60,0xB7,0xB4,0xDD,0x7E,0x29,0xFB,0x67,0xC3,0xFE,0x80,0x4B,0x04,0x41,0xCF,0xE7,0xCF,0xD7,0xF8,0x27,0x1C,0x8E,0x7B,0x98,0xC4,0xF9,0xCE,0x2F,0xB5,0x4D,0x9E,0xCA,0xDF,0xCC,0x78,0xE9,0xAE,0xA1,0xF9,0x21,0x84,0x64,0x8B,0x50,0x3E,0x79,0xEF,0xA6,0x24,0x7A,0xD0,0xC8,0xF9,0xF4,0xB0,0x6A,0x56,0xE9,0xA5,0x62,0x13,0x82,0x4D,0xC6,0xDC,0x3E,0x6F,0x82,0x32,0xCA,0x5A,0x8D,0x4A,0x23,0x6E,0xE4,0x69,0x88,0x5B,0x86,0x19,0x08,0xCB,0xBD,0x60,0x7D,0xC8,0x00};
wxUint8 pppppppppppp[232]={0x31,0x7B,0x35,0x1D,0xA9,0xD6,0xCB,0x89,0xFB,0x19,0x9A,0x3E,0x2C,0x4A,0x5E,0x68,0xF7,0xAB,0xEA,0x1A,0x1D,0xCF,0xCE,0x79,0xC3,0xBE,0xAD,0xA2,0x45,0xB4,0x22,0x34,0xBB,0x12,0xCB,0xF5,0xA8,0x86,0x43,0xE6,0xD3,0xD8,0x32,0x50,0x29,0xA1,0x5F,0xC9,0x8C,0xC2,0x00,0x14,0x82,0x63,0x02,0x5D,0x8C,0xC2,0x00,0x14,0x82,0x63,0x02,0x5D,0x47,0xA8,0x78,0xCF,0xCD,0xEE,0xA8,0x60,0x65,0x48,0x39,0x1B,0xC6,0x1C,0xD6,0xC9,0xA0,0xBA,0x82,0x55,0x02,0x33,0xD9,0x76,0xC4,0x74,0x74,0xA5,0xF9,0x53,0xBC,0x1A,0x11,0xAE,0x3D,0x33,0x73,0x9F,0xEE,0x81,0xAB,0x6F,0x38,0xD4,0x30,0x58,0xAF,0xEE,0x5D,0xCF,0x60,0xF5,0x2D,0xB8,0xE0,0x61,0x65,0xFF,0x08,0x7A,0xBD,0x09,0xFA,0xA0,0x93,0x77,0xC8,0xD4,0xA7,0x11,0x88,0x9D,0x53,0x9C,0x80,0x94,0x6A,0x08,0xDD,0x8A,0xC8,0xC5,0xE3,0xD0,0xAC,0x93,0x96,0xE4,0x8A,0x87,0x73,0x22,0x66,0xDF,0x99,0x5C,0xE8,0x03,0xE3,0xCF,0x81,0x7F,0xBE,0x1C,0x59,0x5A,0x91,0xE7,0x4C,0xB6,0x07,0xA8,0x7D,0x8D,0xF5,0xA3,0x9C,0x6C,0xC9,0x89,0xA8,0x34,0xCD,0x5E,0xD6,0x2D,0xB7,0x67,0xC6,0x88,0xC1,0xF7,0xE9,0x14,0x41,0xC6,0xAE,0x2C,0x57,0x32,0xD2,0x5D,0x7D,0x07,0x92,0x80,0xD3,0x6C,0xB4,0x1D,0x9C,0x40,0xBB,0x12,0xCB,0xF5,0xA8,0x86,0x43,0xE6,0x43,0xBB,0x0D,0x17,0x6C,0xC2,0xAF,0x00};
*/


void client::login1(char *keykey, login_pkt2 *request)
{
	wxUint32 cs;
	log_reply_pkt2 reply;

	wxString log_msg = wxString::Format("%s, server:%s, port:%d, protocol:%d", unstr(request->name, request->name_len*2), iptos(request->srv_addr), request->port, request->protocol);
	if (m_handler) {
		wxCommandEvent event(mwEVT_USER_INFO);

		event.SetString(log_msg);
		wxPostEvent(m_handler, event);
	}

	memset(&reply, 0, sizeof(reply));
	reply.len = 2;
	reply.log_ff = 0xff;
	reply.log_func = 0x0;
	reply.len+= 2;
	reply.enabled = 1;
	reply.len+= 4;

	//			reply.reserved1 = 0;
	//			reply.len+= 2;
	reply.srv_addr = request->srv_addr;
	reply.len+= 4;
	reply.port = request->port;
	reply.len+= 4;
	reply.protocol0 = request->protocol;
	reply.len+= 2;
	reply.protocol1 = request->protocol;
	reply.len+= 2;
	reply.protocol2 = request->protocol;
	reply.len+= 4;
	reply.protocol3 = 0x10038;
	//			reply.protocol3 = 0x10050;
	reply.len+= 4;

	memset(&reply.unknown, 0, sizeof(reply.unknown));
	reply.len+= 40;


	char *msg_area = reply.messages;
	strcpy(msg_area, msg1.c_str());
	msg_area+=msg1.Len()+1;
	reply.len+= msg1.Len()+1;
	strcpy(msg_area, msg2.c_str());
	reply.len+= msg2.Len()+1;

	reply.len = ((reply.len-2+7)&0xfffffff8)+2;
	reply.len+=8;

	set_key64(keykey);
	crypt((char *)&reply.log_ff, reply.len-2, 0);
	cs = checksum((char *)&reply.log_ff, reply.len-2);
	memcpy(((char *)&reply)+reply.len, &cs, 4);
	reply.len+=4;

	//			set_key64(keykey);
	//			crypt((char *)&reply.log_ff, reply.len-2, 1);

	m_sock.Send(&reply, reply.len);
}



void client::login2(char *keykey, login_pkt2 *request)
{
	wxUint32 cs;
	log_reply_pkt1055 reply;

	wxString log_msg = wxString::Format("%s, server:%s, port:%d, protocol:%d", unstr(request->name, request->name_len*2), iptos(request->srv_addr), request->port, request->protocol);
	if (m_handler) {
		wxCommandEvent event(mwEVT_USER_INFO);

		event.SetString(log_msg);
		wxPostEvent(m_handler, event);
	}

	memset(&reply, 0, sizeof(reply));
	reply.len = 2;
	reply.log_ff = 0xff;
	reply.log_func = 0x0;
	reply.len+= 2;
	reply.enabled = 1;
	reply.len+= 4;

	//			reply.reserved1 = 0;
	//			reply.len+= 2;
	reply.srv_addr = request->srv_addr;
	reply.len+= 4;
	reply.port = request->port;
	reply.len+= 4;
	reply.protocol0 = request->protocol;
	reply.len+= 2;
	reply.protocol1 = request->protocol;
	reply.len+= 2;
	reply.protocol2 = request->protocol;
	reply.len+= 4;
	reply.protocol3 = 0x10038;
	reply.len+= 4;

	reply.protocol4 = request->protocol;
	reply.len+= 4;
	reply.protocol5 = request->protocol;
	reply.len+= 4;
	reply.protocol6 = request->protocol;
	reply.len+= 4;
	reply.protocol7 = request->protocol;
	reply.len+= 4;

	memset(&reply.unknown, 0, sizeof(reply.unknown));
	reply.len+= 40;

	char *msg_area = reply.messages;
	strcpy(msg_area, msg1.c_str());
	msg_area+=msg1.Len()+1;
	reply.len+= msg1.Len()+1;
	strcpy(msg_area, msg2.c_str());
	reply.len+= msg2.Len()+1;

	reply.len = ((reply.len-2+7)&0xfffffff8)+2;
	reply.len+=8;

	set_key64(keykey);
	crypt((char *)&reply.log_ff, reply.len-2, 0);
	cs = checksum((char *)&reply.log_ff, reply.len-2);
	memcpy(((char *)&reply)+reply.len, &cs, 4);
	reply.len+=4;

	//			set_key64(keykey);
	//			crypt((char *)&reply.log_ff, reply.len-2, 1);

	m_sock.Send(&reply, reply.len);
}



void client::login3(char *keykey, login_pkt2 *request)
{
	wxUint32 cs;
	//log_reply_pkt1055 reply;
    log_reply_pkt1068 reply;
	wxUint32 i = 0;
	FILE *fp;


	wxString log_msg = wxString::Format("%s, server:%s, port:%d, protocol:%d", unstr(request->name, request->name_len*2), iptos(request->srv_addr), request->port, request->protocol);
	if (m_handler) {
		wxCommandEvent event(mwEVT_USER_INFO);

		event.SetString(log_msg);
		wxPostEvent(m_handler, event);
	}

	memset(&reply, 0, sizeof(reply));
	memset(account_key,0,sizeof(account_key));
	reply.len = 2;
	reply.log_ff = 0xff;
	reply.len += 1;
	reply.log_func = 0x0;
	reply.len += 1;
	reply.enabled = 1;
	reply.len+= 4;

	//			reply.reserved1 = 0;
	//			reply.len+= 2;
	reply.version = (wxUint16)(request->version);
	reply.len+= 2;
	reply.unknown_1 = 0x270f;
	//reply.unknown_1 = 0x0000;
	reply.len+= 2;
	reply.srv_addr = request->srv_addr;
	reply.len+= 4;
	reply.port = request->port;
	reply.len+= 4;
	reply.protocol = request->protocol;
	reply.len+= 4;
	reply.unknow_2= 0x00010045;
	//reply.unknow_2= 0x00000000;
	reply.len+= 4;
	reply.unknow_3= 0x03;
	//reply.unknow_3= 0x00;
	reply.len+= 4;
	reply.unknow_4= 0x01;
	//reply.unknow_4= 0x00;
	reply.len+= 4;

#ifdef use_dat_file	
	{
		int j = 0;
		char *directory;
		char account_local[64];
		char *filepath;
		directory = "user\\";
		strcpy(account_local, directory);
        	filepath = account_local;
/*
		while( j < request->name_len)
		{
			account_local[strlen(directory)+j] = request->name[2*j];
			j++;
		}
		*(filepath + strlen(directory) + request->name_len) = '\0';
*/
		strcat(account_local,unstr(request->name, request->name_len*2));
		strcat(account_local,".dat");

#ifdef debugfile
		fp = fopen("c:\\filepath.txt","w");
		if (fp == NULL)
		abort();
		//assert(fp);
		fprintf(fp, "%s", filepath);
		fclose(fp);
#endif


       	fp = fopen(filepath,"rb");
		if (fp == NULL)
		{
			wxString log_msg = wxString::Format("     User %s dat file is not exsit! Only an error for OOG.", unstr(request->name, request->name_len*2));
			if (m_handler) {
				wxCommandEvent event(mwEVT_USER_INFO);
				event.SetString(log_msg);
				wxPostEvent(m_handler, event);
			}
			//MessageBox(NULL,"User key file not exist!",NULL,NULL);
			//return;
		} else {
			fread((char *)account_key,1, 80 , fp);
			fclose(fp);
		}

	}
	while(i < 80)
	{
		reply.verification[i] =  account_key[i];
		//reply.verification[i] =  key_limohu9999[i];
		i++;
	}
#else
	{   
		char account_name[40];
        strcpy(account_name,unstr(request->name, request->name_len*2));

#ifdef debugfile
		fp = fopen("c:\\account.txt","w");
		if (fp == NULL)
		abort();
		//assert(fp);
		fprintf(fp, "%s", account_name);
		fclose(fp);
#endif
		GetHash_1068(account_name); //Hash is store in part_tmp[32]
	}

	while(i < 32)
	{
		reply.verification[48 + i] = part_tmp[i];
		i++;
	}

#endif
	reply.len+= 80;
	char *msg_area = reply.messages;
	strcpy(msg_area, msg1.c_str());
	msg_area+=msg1.Len()+1;
	reply.len+= msg1.Len()+1;
	strcpy(msg_area, msg2.c_str());
	reply.len+= msg2.Len()+1;

	reply.len = ((reply.len-2+7)&0xfffffff8)+2;
	reply.len+=8;

#ifdef debugfile
	fp = fopen("c:\\packet5.txt","wb");
	if (fp == NULL)
	abort();
	//assert(fp);
	fwrite((char *)&reply.log_ff, 1, reply.len-2, fp);
	fclose(fp);
#endif

	set_key64(keykey);
	crypt((char *)&reply.log_ff, reply.len-2, 0);
	cs = checksum((char *)&reply.log_ff, reply.len-2);
	memcpy(((char *)&reply)+reply.len, &cs, 4);
	reply.len+=4;


	//			set_key64(keykey);
	//			crypt((char *)&reply.log_ff, reply.len-2, 1);


	m_sock.Send(&reply, reply.len);
}

void client::login4(char *keykey, login_pkt2 *request)
{
	wxUint32 cs;
	//log_reply_pkt1055 reply;
    log_reply_pkt1068 reply;
	wxUint32 i = 0;
	FILE *fp;


	wxString log_msg = wxString::Format("%s, server:%s, port:%d, protocol:%d", unstr(request->name, request->name_len*2), iptos(request->srv_addr), request->port, request->protocol);
	if (m_handler) {
		wxCommandEvent event(mwEVT_USER_INFO);

		event.SetString(log_msg);
		wxPostEvent(m_handler, event);
	}

	memset(&reply, 0, sizeof(reply));
	memset(account_key,0,sizeof(account_key));
	reply.len = 2;
	reply.log_ff = 0xff;
	reply.len += 1;
	reply.log_func = 0x0;
	reply.len += 1;
	reply.enabled = 1;
	reply.len+= 4;


	reply.version = (wxUint16)(request->version);
	reply.len+= 2;
	reply.unknown_1 = 0x270f;
	reply.len+= 2;
	reply.srv_addr = request->srv_addr;
	reply.len+= 4;
	reply.port = request->port;
	reply.len+= 4;
	reply.protocol = request->protocol;
	reply.len+= 4;
	reply.unknow_2= 0x00010045;
	reply.len+= 4;
	reply.unknow_3= 0x03;
	reply.len+= 4;
	reply.unknow_4= 0x01;
	reply.len+= 4;



	{   
		char account_name[40];
        strcpy(account_name,unstr(request->name, request->name_len*2));
		GetHash_1071(account_name); //Hash is store in part_tmp[32]
	}

	while(i < 32)
	{
		reply.verification[48 + i] = part_tmp[i];
		i++;
	}

	reply.len+= 80;
	char *msg_area = reply.messages;
	strcpy(msg_area, msg1.c_str());
	msg_area+=msg1.Len()+1;
	reply.len+= msg1.Len()+1;
	strcpy(msg_area, msg2.c_str());
	reply.len+= msg2.Len()+1;

	reply.len = ((reply.len-2+7)&0xfffffff8)+2;
	reply.len+=8;

	set_key64(keykey);
	crypt((char *)&reply.log_ff, reply.len-2, 0);
	cs = checksum((char *)&reply.log_ff, reply.len-2);
	memcpy(((char *)&reply)+reply.len, &cs, 4);
	reply.len+=4;

	m_sock.Send(&reply, reply.len);
}

void client::send_game_data(char *keykey, login_pkt2 *request)
{
	wxUint32 cs;
	game_data_pkt1056 reply;
/*
	wxString log_msg = wxString::Format("Get [GameData]");
	if (m_handler) {
		wxCommandEvent event(mwEVT_USER_INFO);

		event.SetString(log_msg);
		wxPostEvent(m_handler, event);
	}
*/
	memset(&reply, 0, sizeof(reply));
	reply.len = 2;
	reply.log_ff = 0xff;
	reply.log_func = 0x1;
	reply.len+= 2;
	reply.data1 = 0xFFFFDE4A;
	reply.len+= 4;
	reply.data2 = 0;
	reply.len+= 4;
	reply.data2 = 0;
	reply.len+= 4;


	reply.len = ((reply.len-2+7)&0xfffffff8)+2;
	reply.len+=8;

	set_key64(keykey);
	crypt((char *)&reply.log_ff, reply.len-2, 0);
	cs = checksum((char *)&reply.log_ff, reply.len-2);
	memcpy(((char *)&reply)+reply.len, &cs, 4);
	reply.len+=4;

	//			set_key64(keykey);
	//			crypt((char *)&reply.log_ff, reply.len-2, 1);

	m_sock.Send(&reply, reply.len);
}

wxThread::ExitCode client::Entry()
{
	wxUint32 cs;
	char buff[1024];
#ifdef debugfile
	FILE *fp;
#endif

	int len = m_sock.Recv(buff, sizeof(buff));
/*
		#ifdef debugfile
			fp = fopen("c:\\get1.txt","wb");
			if (fp == NULL)
				abort();
			//assert(fp);
			fwrite((char *)buff, 1, len, fp);
			fclose(fp);
		#endif
*/

		
	if (len<16 || *(wxUint16 *)&buff<16)
		return (ExitCode) wxTHREAD_NO_ERROR;

	if (*(wxUint16 *)&buff!=0x70) {
/*
		#ifdef debugfile
			{
			fp = fopen("c:\\get2.txt","wb");
			if (fp == NULL)
				abort();
			//assert(fp);
			fwrite((char *)buff, 1, len, fp);
			fclose(fp);
			}
		#endif
	*/
		// after 10.5.0
		login_pkt2 *request;
		request = (login_pkt2 *)buff;
		cs = *(wxUint32 *)(((char *)request)+request->len-4);
		if (cs==checksum(buff+2, request->len-4-2)) {
			char keykey[16];

			memcpy(keykey, (((char *)request)+request->len-12), 8);
			set_key64(keykey);

			crypt((char *)&request->reserved1, request->len-14, 1);

			switch (request->reserved1>>8) {
				case 04:
					send_game_data(keykey, request);
					break;
				case 00:
					switch (request->version) {
					case 1053:
					case 1054:
						//login1(keykey, request);
						login1(keykey, request);
						break;
					case 1055:
					case 1056:
					case 1057:
					case 1058:
					case 1059:
					case 1060:
					case 1061:
					case 1062:
					case 1063:
					case 1064:
					case 1065:
					case 1066:
					case 1067:
						login2(keykey, request);
						break;
					case 1068:
					case 1069:
					case 1070:
						login3(keykey, request);
						break;
					case 1071:
						login4(keykey, request);
						break;
					default:
						login4(keykey, request);
						break;
					}
/*			
				default:
					 send_game_data(keykey, request);
					 break;
*/					
			}
		}
	} else	{
		// before 10.5.0
		login_pkt *request;
		request = (login_pkt *)buff;

		cs = request->cs0;
		request->cs0 = 0;
		if (cs==checksum(buff, request->len)) {
			memset(dword_61D77C, 0, 0x20);

			unpack_key(request);
			set_key64(request->key);
			crypt((char *)&request->version, 0x48, 1);

			set_key64(request->key);
			crypt((char *)&request->crypted_name, 40, 1);

			log_reply_pkt reply;
			memset(&reply, 0, sizeof(log_reply_pkt));
			reply.len = sizeof(log_reply_pkt);
			reply.version = 0x416;
			reply.enabled = 1;
			reply.port = request->port;
			reply.protocol = request->protocol;
			reply.srv_addr = request->srv_addr;

			//		reply.dummy1 = 0x6661;
			reply.name_cs = checksum(request->crypted_name, request->name_len*2); // ????
			//		reply.dummy3 = 0x66666663;
			//		reply.dummy4 = 0x66666664;

			memset(&CARD, sizeof(CARD), 0);
			strcpy(CARD.magic, "PFT");
			memcpy(CARD.name, request->crypted_name, request->name_len*2);

			CARD.name[request->name_len*2] = 0x80;
			CARD.name[0x38] = request->name_len<<4;

			CARD.id[0] = 0x67452301;
			CARD.id[1] = 0xEFCDAB89;
			CARD.id[2] = 0x98BADCFE;
			CARD.id[3] = 0x10325476;
			gen_card_name(&CARD);
			bin2hex((unsigned char *)&CARD.id, reply.card_num, 16);

			memcpy(&reply.name0, request->crypted_name, 8);
			set_key64(request->key);
			crypt((char *)&reply.name0, 8, 0);

			wxString msg1 = _T("Now we will use local verification");
			wxString msg2 = _T("Enjoy!");
			char *msg_area = reply.messages;
			strcpy(msg_area, msg1.c_str());
			msg_area+=msg1.Len()+1;
			strcpy(msg_area, msg2.c_str());
			reply.msg1_len = msg1.Len()+1;
			reply.msg2_len = msg2.Len()+1;


			wxString log_msg = wxString::Format("%s, server #%d, card '%s'", unstr(request->crypted_name, request->name_len*2), request->srv_num, reply.card_num);
			if (m_handler) {
				wxCommandEvent event(mwEVT_USER_INFO);

				event.SetString(log_msg);
				wxPostEvent(m_handler, event);
			}

			set_key64(request->key);
			crypt((char *)&reply.version, sizeof(log_reply_pkt)-8, 0);
			reply.cs0 = checksum((char *)&reply, sizeof(log_reply_pkt));
			m_sock.Send(&reply, sizeof(log_reply_pkt));
		}
	}
	return (ExitCode) wxTHREAD_NO_ERROR;
}

//Following code is add for MD5

#define S11 7
#define S12 12
#define S13 17
#define S14 22
#define S21 5
#define S22 9
#define S23 14
#define S24 20
#define S31 4
#define S32 11
#define S33 16
#define S34 23
#define S41 6
#define S42 10
#define S43 15
#define S44 21

static void MD5Transform(UINT4 [4], unsigned char [64]);
static void Encode(unsigned char *, UINT4 *, unsigned int);
static void Decode(UINT4 *, unsigned char *, unsigned int);
static void MD5_memcpy(POINTER , POINTER , unsigned int);
static void MD5_memset(POINTER, int, unsigned int);

static unsigned char PADDING[64] = {
  0x80, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

/* F, G, H and I are basic MD5 functions. */
#define F(x, y, z) (((x) & (y)) | ((~x) & (z)))
#define G(x, y, z) (((x) & (z)) | ((y) & (~z)))
#define H(x, y, z) ((x) ^ (y) ^ (z))
#define I(x, y, z) ((y) ^ ((x) | (~z)))

/* ROTATE_LEFT rotates x left n bits. */
#define ROTATE_LEFT(x, n) (((x) << (n)) | ((x) >> (32-(n))))

/* FF, GG, HH, and II transformations for rounds 1, 2, 3, and 4.
Rotation is separate from addition to prevent recomputation. */
#define FF(a, b, c, d, x, s, ac) { \
 (a) += F ((b), (c), (d)) + (x) + (UINT4)(ac); \
 (a) = ROTATE_LEFT ((a), (s)); \
 (a) += (b); \
  }
#define GG(a, b, c, d, x, s, ac) { \
 (a) += G ((b), (c), (d)) + (x) + (UINT4)(ac); \
 (a) = ROTATE_LEFT ((a), (s)); \
 (a) += (b); \
  }
#define HH(a, b, c, d, x, s, ac) { \
 (a) += H ((b), (c), (d)) + (x) + (UINT4)(ac); \
 (a) = ROTATE_LEFT ((a), (s)); \
 (a) += (b); \
  }
#define II(a, b, c, d, x, s, ac) { \
 (a) += I ((b), (c), (d)) + (x) + (UINT4)(ac); \
 (a) = ROTATE_LEFT ((a), (s)); \
 (a) += (b); \
  }

/* MD5 initialization. Begins an MD5 operation, writing a new context. */
void MD5Init (MD5_CTX *context) /* context */
{
  context->count[0] = context->count[1] = 0;
  /* Load magic initialization constants.*/
  context->state[0] = 0x67452301;
  context->state[1] = 0xefcdab89;
  context->state[2] = 0x98badcfe;
  context->state[3] = 0x10325476;
}

/* MD5 block update operation. Continues an MD5 message-digest
  operation, processing another message block, and updating the
  context. */
void MD5Update (MD5_CTX *context, unsigned char *input, unsigned int inputLen)
{
  unsigned int i, index, partLen;

  /* Compute number of bytes mod 64 */
  index = (unsigned int)((context->count[0] >> 3) & 0x3F);

  /* Update number of bits */
  if ((context->count[0] += ((UINT4)inputLen << 3))

   < ((UINT4)inputLen << 3))
 context->count[1]++;
  context->count[1] += ((UINT4)inputLen >> 29);

  partLen = 64 - index;

  /* Transform as many times as possible.*/
  if (inputLen >= partLen) {
 MD5_memcpy((POINTER)&context->buffer[index], (POINTER)input, partLen);
 MD5Transform (context->state, context->buffer);

 for (i = partLen; i + 63 < inputLen; i += 64)
   MD5Transform (context->state, &input[i]);

 index = 0;
  }
  else
 i = 0;

  /* Buffer remaining input */
  MD5_memcpy
 ((POINTER)&context->buffer[index], (POINTER)&input[i],
  inputLen-i);
}

/* MD5 finalization. Ends an MD5 message-digest operation, writing the
  the message digest and zeroizing the context. */
void MD5Final (unsigned char digest[16],MD5_CTX *context)
{
  unsigned char bits[8];
  unsigned int index, padLen;

  /* Save number of bits */
  Encode (bits, context->count, 8);

  /* Pad out to 56 mod 64.*/
  index = (unsigned int)((context->count[0] >> 3) & 0x3f);
  padLen = (index < 56) ? (56 - index) : (120 - index);
  MD5Update (context, PADDING, padLen);

  /* Append length (before padding) */
  MD5Update (context, bits, 8);

  /* Store state in digest */
  Encode (digest, context->state, 16);

  /* Zeroize sensitive information.*/
  MD5_memset ((POINTER)context, 0, sizeof (*context));
}

/* MD5 basic transformation. Transforms state based on block. */
static void MD5Transform (UINT4 state[4], unsigned char block[64])
{
  UINT4 a = state[0], b = state[1], c = state[2], d = state[3], x[16];

  Decode (x, block, 64);

  /* Round 1 */
  FF (a, b, c, d, x[ 0], S11, 0xd76aa478); /* 1 */
  FF (d, a, b, c, x[ 1], S12, 0xe8c7b756); /* 2 */
  FF (c, d, a, b, x[ 2], S13, 0x242070db); /* 3 */
  FF (b, c, d, a, x[ 3], S14, 0xc1bdceee); /* 4 */
  FF (a, b, c, d, x[ 4], S11, 0xf57c0faf); /* 5 */
  FF (d, a, b, c, x[ 5], S12, 0x4787c62a); /* 6 */
  FF (c, d, a, b, x[ 6], S13, 0xa8304613); /* 7 */
  FF (b, c, d, a, x[ 7], S14, 0xfd469501); /* 8 */
  FF (a, b, c, d, x[ 8], S11, 0x698098d8); /* 9 */
  FF (d, a, b, c, x[ 9], S12, 0x8b44f7af); /* 10 */
  FF (c, d, a, b, x[10], S13, 0xffff5bb1); /* 11 */
  FF (b, c, d, a, x[11], S14, 0x895cd7be); /* 12 */
  FF (a, b, c, d, x[12], S11, 0x6b901122); /* 13 */
  FF (d, a, b, c, x[13], S12, 0xfd987193); /* 14 */
  FF (c, d, a, b, x[14], S13, 0xa679438e); /* 15 */
  FF (b, c, d, a, x[15], S14, 0x49b40821); /* 16 */

 /* Round 2 */
  GG (a, b, c, d, x[ 1], S21, 0xf61e2562); /* 17 */
  GG (d, a, b, c, x[ 6], S22, 0xc040b340); /* 18 */
  GG (c, d, a, b, x[11], S23, 0x265e5a51); /* 19 */
  GG (b, c, d, a, x[ 0], S24, 0xe9b6c7aa); /* 20 */
  GG (a, b, c, d, x[ 5], S21, 0xd62f105d); /* 21 */
  GG (d, a, b, c, x[10], S22,  0x2441453); /* 22 */
  GG (c, d, a, b, x[15], S23, 0xd8a1e681); /* 23 */
  GG (b, c, d, a, x[ 4], S24, 0xe7d3fbc8); /* 24 */
  GG (a, b, c, d, x[ 9], S21, 0x21e1cde6); /* 25 */
  GG (d, a, b, c, x[14], S22, 0xc33707d6); /* 26 */
  GG (c, d, a, b, x[ 3], S23, 0xf4d50d87); /* 27 */

  GG (b, c, d, a, x[ 8], S24, 0x455a14ed); /* 28 */
  GG (a, b, c, d, x[13], S21, 0xa9e3e905); /* 29 */
  GG (d, a, b, c, x[ 2], S22, 0xfcefa3f8); /* 30 */
  GG (c, d, a, b, x[ 7], S23, 0x676f02d9); /* 31 */
  GG (b, c, d, a, x[12], S24, 0x8d2a4c8a); /* 32 */

  /* Round 3 */
  HH (a, b, c, d, x[ 5], S31, 0xfffa3942); /* 33 */
  HH (d, a, b, c, x[ 8], S32, 0x8771f681); /* 34 */
  HH (c, d, a, b, x[11], S33, 0x6d9d6122); /* 35 */
  HH (b, c, d, a, x[14], S34, 0xfde5380c); /* 36 */
  HH (a, b, c, d, x[ 1], S31, 0xa4beea44); /* 37 */
  HH (d, a, b, c, x[ 4], S32, 0x4bdecfa9); /* 38 */
  HH (c, d, a, b, x[ 7], S33, 0xf6bb4b60); /* 39 */
  HH (b, c, d, a, x[10], S34, 0xbebfbc70); /* 40 */
  HH (a, b, c, d, x[13], S31, 0x289b7ec6); /* 41 */
  HH (d, a, b, c, x[ 0], S32, 0xeaa127fa); /* 42 */
  HH (c, d, a, b, x[ 3], S33, 0xd4ef3085); /* 43 */
  HH (b, c, d, a, x[ 6], S34,  0x4881d05); /* 44 */
  HH (a, b, c, d, x[ 9], S31, 0xd9d4d039); /* 45 */
  HH (d, a, b, c, x[12], S32, 0xe6db99e5); /* 46 */
  HH (c, d, a, b, x[15], S33, 0x1fa27cf8); /* 47 */
  HH (b, c, d, a, x[ 2], S34, 0xc4ac5665); /* 48 */

  /* Round 4 */
  II (a, b, c, d, x[ 0], S41, 0xf4292244); /* 49 */
  II (d, a, b, c, x[ 7], S42, 0x432aff97); /* 50 */
  II (c, d, a, b, x[14], S43, 0xab9423a7); /* 51 */
  II (b, c, d, a, x[ 5], S44, 0xfc93a039); /* 52 */
  II (a, b, c, d, x[12], S41, 0x655b59c3); /* 53 */
  II (d, a, b, c, x[ 3], S42, 0x8f0ccc92); /* 54 */
  II (c, d, a, b, x[10], S43, 0xffeff47d); /* 55 */
  II (b, c, d, a, x[ 1], S44, 0x85845dd1); /* 56 */
  II (a, b, c, d, x[ 8], S41, 0x6fa87e4f); /* 57 */
  II (d, a, b, c, x[15], S42, 0xfe2ce6e0); /* 58 */
  II (c, d, a, b, x[ 6], S43, 0xa3014314); /* 59 */
  II (b, c, d, a, x[13], S44, 0x4e0811a1); /* 60 */
  II (a, b, c, d, x[ 4], S41, 0xf7537e82); /* 61 */
  II (d, a, b, c, x[11], S42, 0xbd3af235); /* 62 */
  II (c, d, a, b, x[ 2], S43, 0x2ad7d2bb); /* 63 */
  II (b, c, d, a, x[ 9], S44, 0xeb86d391); /* 64 */

  state[0] += a;
  state[1] += b;
  state[2] += c;
  state[3] += d;

  /* Zeroize sensitive information. */
  MD5_memset ((POINTER)x, 0, sizeof (x));
}

/* Encodes input (UINT4) into output (unsigned char). Assumes len is
  a multiple of 4. */
static void Encode (unsigned char *output, UINT4 *input,unsigned int len)
{
  unsigned int i, j;

  for (i = 0, j = 0; j < len; i++, j += 4) {
 output[j] = (unsigned char)(input[i] & 0xff);
 output[j+1] = (unsigned char)((input[i] >> 8) & 0xff);
 output[j+2] = (unsigned char)((input[i] >> 16) & 0xff);
 output[j+3] = (unsigned char)((input[i] >> 24) & 0xff);
  }
}

/* Decodes input (unsigned char) into output (UINT4). Assumes len is
  a multiple of 4. */
static void Decode (UINT4 *output, unsigned char *input, unsigned int len)
{
  unsigned int i, j;

  for (i = 0, j = 0; j < len; i++, j += 4)
 output[i] = ((UINT4)input[j]) | (((UINT4)input[j+1]) << 8) |
   (((UINT4)input[j+2]) << 16) | (((UINT4)input[j+3]) << 24);
}

/* Note: Replace "for loop" with standard memcpy if possible. */

static void MD5_memcpy (POINTER output, POINTER input, unsigned int len)
{
  unsigned int i;

  for (i = 0; i < len; i++)

 output[i] = input[i];
}

/* Note: Replace "for loop" with standard memset if possible. */
static void MD5_memset(POINTER output, int value, unsigned int len)
{
  unsigned int i;
  for (i = 0; i < len; i++)
 ((char *)output)[i] = (char)value;
}


char *MD5String (const char *string)
{
	int i;
	MD5_CTX context;
	unsigned char digest[16];
	char *result=(char *)malloc(33);

	MD5Init (&context);
	MD5Update (&context, (unsigned char*)string, strlen(string));
	MD5Final (digest, &context);

	for (i=0; i<16; i++)
		sprintf(result+2*i, "%02x", digest[i]);
	result[32]=0;
	return result;
}

void ToUpperCase(char *string)
{
    char ch;
	for (unsigned int i=0; i < strlen(string); i++)
	{
	   ch = *(string + i); 
	   string[i] = ((ch>='a'&&ch<='z')?ch-'a'+'A':ch);
	}
}

void ToLowerCase(char *string)
{
    char ch;
	for (unsigned int i=0; i < strlen(string); i++)
	{
	   ch = *(string + i); 
	   string[i] = ((ch>='A'&&ch<='Z')?ch+'a'-'A':ch);
	}
}

void GetHash_1068(char *name)
{
	char *p_part1;
	char *p_part2;
	char *p_parttmp;
	int len;
	char part1[32];
	char part2[32];
	char *md5;

	p_part1 = part1;
	p_part2 = part2;
	p_parttmp = part_tmp;
	len = strlen(name);
	memset(p_part1,0,32);
	memset(p_part2,0,32);
	
	{
		for(int i = len,j = 1;i>0;j++,i--)
		{
            part_tmp[i-1] =*(name + i -1) + j;
		}
		

	}
	
	
	strncpy(p_part1,p_parttmp,len/2);
	strncpy(p_part2,p_parttmp + len/2,(len+1)/2);
	ToLowerCase(p_part1);
	ToLowerCase(p_part2);

	md5 = MD5String(p_part1);
	ToUpperCase(md5);
	strcpy(p_parttmp,md5);
	free(md5);

	md5 = MD5String(p_part2);
	ToUpperCase(md5);
	strcat(p_parttmp,md5);
	free(md5);

	md5 = MD5String(p_parttmp);
	ToUpperCase(md5);
	strcpy(p_parttmp,md5);
	free(md5);
}


void GetHash_1071(char *name)
{
	char *p_part1;
	char *p_part2;
	char *p_parttmp;
	int len;
	char part1[32];
	char part2[32];
	char *md5;

	p_part1 = part1;
	p_part2 = part2;
	p_parttmp = part_tmp;
	len = strlen(name);
	memset(p_part1,0,32);
	memset(p_part2,0,32);
	
	{
		for(int i = len,j = 1;i>0;j++,i--)
		{
            part_tmp[i-1] =*(name + i -1) + j;
		}
		

	}
	
	
	strncpy(p_part1,p_parttmp,len/2);
	strncpy(p_part2,p_parttmp + len/2,(len+1)/2);

	ToLowerCase(p_part1);
	ToLowerCase(p_part2);


	md5 = MD5String(p_part1);
	ToUpperCase(md5);
	strcpy(p_parttmp,md5);
	free(md5);

	md5 = MD5String(p_part2);
	ToUpperCase(md5);
	strcat(p_parttmp,md5);
	free(md5);

	p_parttmp[63] = 0;

	md5 = MD5String(p_parttmp);
	ToUpperCase(md5);
	strcpy(p_parttmp,md5);
	free(md5);
}