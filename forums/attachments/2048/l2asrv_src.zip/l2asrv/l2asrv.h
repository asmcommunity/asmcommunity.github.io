/////////////////////////////////////////////////////////////////////////////
// Name:        L2ASrv.h
// Purpose:     
// Author:      
// Modified by: 
// Created:     05/30/05 19:30:50
// RCS-ID:      
// Copyright:   
// Licence:     
/////////////////////////////////////////////////////////////////////////////

#ifndef _L2ASrv_H_
#define _L2ASrv_H_

#if defined(__GNUG__) && !defined(__APPLE__)
#pragma interface "L2ASrv.cpp"
#endif

/*!
 * Includes
 */

////@begin includes
#include "wx/image.h"
////@end includes

/*!
 * Forward declarations
 */

////@begin forward declarations
////@end forward declarations

/*!
 * Control identifiers
 */

////@begin control identifiers
////@end control identifiers

/*!
 * L2ASrvApp class declaration
 */

class L2ASrvApp: public wxApp
{    
    DECLARE_CLASS( L2ASrvApp )
    DECLARE_EVENT_TABLE()

public:
    /// Constructor
    L2ASrvApp();

    /// Initialises the application
    virtual bool OnInit();

    /// Called on exit
    virtual int OnExit();

////@begin L2ASrvApp event handler declarations

////@end L2ASrvApp event handler declarations

////@begin L2ASrvApp member function declarations

////@end L2ASrvApp member function declarations

////@begin L2ASrvApp member variables
////@end L2ASrvApp member variables
};

/*!
 * Application instance declaration 
 */

////@begin declare app
DECLARE_APP(L2ASrvApp)
////@end declare app

#endif
    // _L2ASrv_H_
