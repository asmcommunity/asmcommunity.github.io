The sample test app was build in Visual Basic 6.0

The AsmCtrl.ocx should be registered before loading the test app.

ernie@surfree.com

