The sample test app was build in Visual Basic 6.0

The MyCom.dll should be registered before loading the test app.

ernie@surfree.com

