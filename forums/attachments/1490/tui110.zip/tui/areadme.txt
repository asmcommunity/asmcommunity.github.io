TUI - A Time-based User Interface


Tui is a utility that displays all files found on all fixed disk partitions in
a pseudo 3D perspective view, with newer files nearest and older files farther
away. It allows searching in file names, paths and data as well as grouping of
similar files and thumbnailing of text and image files. It has been tested on
Win98SE and WinXP.

There is a help file explaining usage which is available when Tui is started.

TUI.EXE is all that is required and can be run from anywhere however creating
a directory for it will keep it and the files it generates together. When run
for the first time it creates a database TUI.DBB and a settings file TUI.INI,
both of which appear when you close it down.

A temp file, TUI.TMP, is created and destroyed as the database is updated.

If there are problems then deleting all but TUI.EXE and starting over again
can help.

Plugins must be stored in a directory called 'plugin'.

You are free to use, modify or play with it in any way you wish. It comes with
NO warranty. Use Tui at your own risk as no responsiblity for its use is given
or will be accepted.


Updates:

V1.00 Jan 2006		First release

V1.10 March 2006	Rough fix for hidden dialog text on laptops - by 
			increasing text box sizes. The only file modified is
			\res\tui.rc


DavK

