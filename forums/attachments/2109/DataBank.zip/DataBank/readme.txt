DataBank organizer by Ultrano

I have had more than 6 watches, called "databank", that had the ability to display text notifications at any time I want. But their leash isn't good, and the "enter" button gets worn out easily. As I need something to remind me when to do fitness, and remind me of my food being currently cooked, I had to make such a proggie. I think it is enough reliable, but anyway, I included src code so that you can customize it. If I ever find time, I'll make the organizer look more like a real thing :)). (I mean, with photoreallistic images and real sound and feel). 
 As many people might notice, this app is way out of my style. Any ideas on upgrade are welcome to ultrano@ultrano.com 
 Ah, I code in XASM, maybe it'll help you decode the structure of the file. www.ultrano.com/download/XASM.zip

commands I use:
a, t, d, now, l, m, hide
