// conloader.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

int main()
{
	TCHAR szMod[256];
	GetModuleFileName(GetModuleHandle(NULL), szMod, 256);	
	_tcscpy(&szMod[_tcslen(szMod)-4], _T(".exe"));
	HMODULE hExe = LoadLibraryEx(szMod, NULL, DONT_RESOLVE_DLL_REFERENCES);
	IMAGE_NT_HEADERS *nth = (IMAGE_NT_HEADERS*)(DWORD_PTR(hExe) + PIMAGE_DOS_HEADER(hExe)->e_lfanew);
	DWORD_PTR pEntry = nth->OptionalHeader.AddressOfEntryPoint + DWORD_PTR(hExe);
	// have to build IAT ourself
	// unprotect IAT
	LPVOID pIat = (LPVOID)(DWORD_PTR(hExe) + nth->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IAT].VirtualAddress);
	DWORD cbIat = nth->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IAT].Size;
	DWORD flOldProt;
	VirtualProtect(pIat, cbIat, PAGE_EXECUTE_READWRITE, &flOldProt);
	IMAGE_IMPORT_DESCRIPTOR* idt = (IMAGE_IMPORT_DESCRIPTOR*)(
		DWORD_PTR(hExe) + nth->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT].VirtualAddress);
	while(idt->Characteristics)
	{
		// load this library
		HMODULE hLib = LoadLibrary((LPCTSTR)(DWORD_PTR(hExe)+idt->Name));
		IMAGE_THUNK_DATA *th1 = (IMAGE_THUNK_DATA*)(DWORD_PTR(hExe) + idt->FirstThunk);
		IMAGE_THUNK_DATA *th2 = (IMAGE_THUNK_DATA*)(DWORD_PTR(hExe) + idt->OriginalFirstThunk);
		while(th1->u1.Function)
		{
			//DWORD flOldProt;
			//VirtualProtect((LPVOID)(DWORD_PTR)th1->u1.Function, 4, PAGE_EXECUTE_READWRITE, &flOldProt);
			if(th2->u1.Ordinal & 0x80000000)
			{
				th1->u1.Function = (DWORD)(DWORD_PTR)GetProcAddress(hLib, (LPCSTR)(DWORD_PTR)(th2->u1.Ordinal & 0xffff));
			}
			else
			{
				LPCSTR szFuncName = (LPCSTR)(DWORD_PTR(hExe) + th2->u1.AddressOfData + 2);
				th1->u1.Function = (DWORD)(DWORD_PTR)GetProcAddress(hLib, szFuncName);
			}
			// next thunk
			th1++;
			th2++;
		}
		// next descriptor
		idt++;
	}
	// restore IAT protection
	DWORD dummy;
	VirtualProtect(pIat, cbIat, flOldProt, &dummy);
	__asm {
		mov eax,pEntry
		call eax
	}
	return 0;
}


// old idea

//HANDLE hStdIn, hStdOut, hStdErr;
//
//HANDLE hStdInPipeR, hStdInPipeW;
//HANDLE hStdOutPipeR, hStdOutPipeW;
//HANDLE hStdErrPipeR, hStdErrPipeW;
//
//DWORD WINAPI PumpStdIn(LPVOID lpvParam)
//{
//	DWORD dw;
//	BYTE buf;
//	DWORD mode;
//	GetConsoleMode(hStdIn, &mode);
//	mode &= ~ENABLE_LINE_INPUT;
//	SetConsoleMode(hStdIn, mode);
//	for(;;)
//	{
//		if(!ReadFile(hStdIn, &buf, 1, &dw, NULL) || dw == NULL)
//			break;
//		if(!WriteFile(hStdInPipeW, &buf, 1, &dw, NULL) || dw == NULL)
//			break;
//	}
//	WriteFile(hStdOut, "stdin pump quit\r\n", 17, &dw, NULL);
//	return 0;
//}
//
//DWORD WINAPI PumpStdOut(LPVOID lpvParam)
//{
//	DWORD dw;
//	BYTE buf;
//	for(;;)
//	{
//		if(!ReadFile(hStdOutPipeR, &buf, 1, &dw, NULL) || dw == NULL)
//			break;
//		if(!WriteFile(hStdOut, &buf, 1, &dw, NULL) || dw == NULL)
//			break;
//	}
//	return 0;
//}
//
//DWORD WINAPI PumpStdErr(LPVOID lpvParam)
//{
//	DWORD dw;
//	BYTE buf;
//	for(;;)
//	{
//		if(!ReadFile(hStdErrPipeR, &buf, 1, &dw, NULL) || dw == NULL)
//			break;
//		if(!WriteFile(hStdErr, &buf, 1, &dw, NULL) || dw == NULL)
//			break;
//	}
//	return 0;
//}
//
//int main()
//{
//	// get std handles
//	hStdIn = GetStdHandle(STD_INPUT_HANDLE);
//	hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
//	hStdErr = GetStdHandle(STD_ERROR_HANDLE);
//	// make security attributes
//	SECURITY_ATTRIBUTES sat;
//	sat.nLength = sizeof(sat);
//	sat.lpSecurityDescriptor = NULL;
//	sat.bInheritHandle = TRUE;
//	// make pipes
//	// -stdin
//	CreatePipe(&hStdInPipeR, &hStdInPipeW, &sat, 0);
//	// -stdout
//	CreatePipe(&hStdOutPipeR, &hStdOutPipeW, &sat, 0);
//	// -stderr
//	CreatePipe(&hStdErrPipeR, &hStdErrPipeW, &sat, 0);
//
//	PROCESS_INFORMATION pi;
//	STARTUPINFO si;
//	ZeroMemory(&si, sizeof(si));
//	si.cb			= sizeof(si);
//	si.dwFlags		= STARTF_USESTDHANDLES;
//	si.hStdInput	= hStdInPipeR;
//	si.hStdOutput	= hStdOutPipeW;
//	si.hStdError	= hStdErrPipeW;
//	DWORD dw;
//	BOOL b = CreateProcess("guicon.exe", NULL, NULL, NULL, TRUE, 0, NULL, NULL, &si, &pi);
//	if(!b)
//	{
//		WriteFile(si.hStdOutput, "spawn failed\r\n", 14, &dw, NULL);
//		return -1;
//	}
//	// start pump threads
//	CreateThread(NULL, 0, PumpStdIn, NULL, 0, NULL);
//	CreateThread(NULL, 0, PumpStdOut, NULL, 0, NULL);
//	CreateThread(NULL, 0, PumpStdErr, NULL, 0, NULL);
//	// wait for program to exit
//	WaitForSingleObject(pi.hProcess, INFINITE);
//	GetExitCodeProcess(pi.hProcess, &dw);
//	return (int)dw;
//}
