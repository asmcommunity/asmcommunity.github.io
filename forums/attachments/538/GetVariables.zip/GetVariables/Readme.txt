To build, you will need:

[MASM32 v.8.0]  - get at http://www.movsd.com
[Four-F KmdKit] - get at http://www.masmforum.com/website/tutorials/kmdtute/index.html

Thnx to:
  Win32AsmCommunity, for always inspiring me to write my best in Asm
  Four-F, for your precious kernel mode development kit
  Rootkit community

Edgar Barbosa, a.k.a Opc0de
