#define WIN32_LEAN_AND_MEAN
#include <stdio.h>
#include <math.h>

#define NOWINDOWS

#ifdef NOWINDOWS
#include <time.h>
#else
#include <windows.h>
#endif

#define _PIby180 (0.017453292519943295769236907684886)
#define ToRad(degree) ((degree) * _PIby180) // converts degrees to radians

#define DIV0  (1.0/1.0)
#define DIV1 -(1.0/6.0)
#define DIV2  (1.0/120.0)
#define DIV3 -(1.0/5040.0)
#define DIV4  (1.0/362880.0)
#define DIV5 -(1.0/39916800.0)
#define DIV6  (1.0/6227020800.0)
#define DIV7 -(1.0/1307674368000.0)

#define SINEDEG 60     // degree for which the sine is to be calculated
#define TESTS 10000000 // number of iterations for each test

//precalculated stuff
const double divisor[]  = {DIV0, DIV1, DIV2, DIV3, DIV4, DIV5, DIV6, DIV7},
            exponents[] = {1.0, 3.0, 5.0, 7.0, 9.0, 11.0, 13.0, 15.0};

// calculates the sine of a given radian
float sine(float radians, long precision) {
    float sum;
    register long i;

    precision &= 7;
    sum = 0;
    i = 0;

    do {
        sum += (float)(pow(radians, exponents[i]) * divisor[i]);
        i++;
    } while (i <= precision);

    return sum;
}

// does the same as the above one
float sine2(float radian, long precision) {
    float sum, dummy;

    __asm {
        mov     eax, [precision]
        xor     ecx, ecx
        and     eax, 7
        mov     [sum], ecx
        fld     dword ptr [radian]
nxtpass:
        fld     st
        fmul    qword ptr [ecx*8+divisor]
        fxch    st(1)
        fmul    dword ptr [radian]
        fxch    st(1)
        fadd    dword ptr [sum]
        fxch    st(1)
        fmul    dword ptr [radian]
        fxch    st(1)
        inc     ecx
        fstp    [sum]
        cmp     ecx, eax
        jbe     nxtpass

        fstp    dword ptr [dummy]
    }
    return sum;
}

// calculates sine using only simple 'fsin'
float sine3(float degree) {
    float temp;
    
    __asm {
        fld     dword ptr [degree]
        fsin
        fstp    dword ptr [temp]
    }
    return temp;
}

int __cdecl main(int argc, char *argv[]) {
    unsigned long i, j, extime;

    // print "welcome" screen showing correct value returned by MSVCRT's "sin"
    printf("proper sine value: %.20e\r\n\r\napproximated values:            time (ms)\r\n", sin(ToRad(SINEDEG)));

    for (i=0; i<8; i++) {  // 8 iterate through 8 precisions
        j = 0;

        // get actual time
        #ifdef NOWINDOWS
        extime = clock();
        #else
        extime = GetTickCount();
        #endif

        // do intensive test 'TESTS'-times.
        do {
            sine2((float)ToRad(SINEDEG), i);
            j++;
        } while (j < TESTS);

        // get actual time
        #ifdef NOWINDOWS
        extime = (clock() - extime);
        #else
        extime = (GetTickCount() - extime);
        #endif

        // print the result for this iteration
        printf("%u: %.20e   (%5u)\r\n", i+1, sine2((float)ToRad(SINEDEG), i), extime);
    }

    j = 0;

    // get actual time
    #ifdef NOWINDOWS
    extime = clock();
    #else
    extime = GetTickCount();
    #endif

    // do intensive test 'TESTS'-times.
    do {
        sin((float)ToRad(SINEDEG));
        j++;
    } while (j < TESTS);

    // get actual time
    #ifdef NOWINDOWS
    extime = (clock() - extime);
    #else
    extime = (GetTickCount() - extime);
    #endif

    // print the result for MSVCRT's  "sin"
    printf("\r\n\r\nMSVCRT's 'sin' time: %u\r\n\r\n", extime);

    // print the correct value returned by math unit
    printf("fsin value: %.20e\r\n", sine3((float)ToRad(SINEDEG)));

    j = 0;

    // get actual time
    #ifdef NOWINDOWS
    extime = clock();
    #else
    extime = GetTickCount();
    #endif

    // do intensive test 'TESTS'-times.
    do {
        sine3((float)ToRad(SINEDEG));
        j++;
    } while (j < TESTS);

    // get actual time
    #ifdef NOWINDOWS
    extime = (clock() - extime);
    #else
    extime = (GetTickCount() - extime);
    #endif

    // print the result for math unit's "fsin"
    printf("fsin time: %u\r\n\r\n", extime);

    return 0;
}