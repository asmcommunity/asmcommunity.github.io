
#include "stdafx.h"

char* Name     = "My C++ Plugin";
char* Author   = "Fabr�cio";
char* Version  = "1.0";
char* Id	   = "CPP1";



BOOL APIENTRY DllMain( HANDLE hModule,DWORD  ul_reason_for_call,LPVOID lpReserved){

	switch(ul_reason_for_call){
		case DLL_PROCESS_ATTACH:;
		case DLL_PROCESS_DETACH:;
		case DLL_THREAD_ATTACH:;
		case DLL_THREAD_DETACH:;
	};
	return TRUE;
}

int Main(HWND hWnd,DWORD hBlock,DWORD _null){
	/*	Do your stuff in here
		hWnd   : Handle to the main window.
		hBlock : Pointer to the main memory block.
		_null  : Not used.
	*/
	

	MessageBox(hWnd,"Hello ! Im coming from a Cpp compiled DLL.",Name,MB_ICONINFORMATION);
	return TRUE;
}


int Init(){
	// Do your initialization in here.
	// return TRUE for ok processing or FALSE for an error.
	return TRUE;
}

char* retName()		{return Name;}
char* retAuthor()	{return Author;}
char* retVersion()	{return Version;}
char* retId()		{return Id;}
