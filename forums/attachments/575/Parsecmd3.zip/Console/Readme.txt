The C startup code for console applications ( startc.asm ) can handle quoted command line parameters.

Please copy the file crtdll.lib to c:\masm32\lib to compile the console examples. 

All for the console examples, type something like :

test "alpha" beta gamma

The output should look like this :

Command line parameter 1 = test
Command line parameter 2 = alpha
Command line parameter 3 = beta
Command line parameter 4 = gamma


