//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Rebar.rc
//
#define IDI_ICON1                       100
#define IDM_ABOUT                       100
#define IDD_ABOUTBOX                    101
#define IDM_EXIT                        101
#define IDB_BACKGROUND                  102
#define IDM_TOP                         102
#define IDB_LOGO                        103
#define IDM_LEFT                        103
#define IDM_GENERICMENU                 104
#define IDM_RIGHT                       104
#define IDM_BOTTOM                      105

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         107
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
