FIRST-BEER LICENSE AGREEMENT

IMPORTANT-READ CAREFULLY: 
This End-User License Agreement ("EULA") is a legal agreement between you (either an individual or a single entity)
and ALL OTHER NAMED PARTIES mentioned within this EULA, for the SOURCE CODE which accompanies this EULA.
YOU AGREE TO BE BOUND BY THE TERMS OF THIS EULA BY READING, EDITING, COPYING, OR OTHERWISE USING THE SOURCE CODE.
IF YOU DO NOT AGREE, DO NOT READ THIS DOCUMENT, OR THE SOURCE CODE.
YOU MAY RETURN IT TO YOUR PLACE OF PURCHASE FOR A FULL REFUND, IF APPLICABLE.
YOU MAY ADD YOUR OWN NAME TO THE LIST OF NAMED PARTIES below.
YOU MAY NOT ALTER THIS EULA IN ANY OTHER WAY.

1. GRANT OF LICENSE. We, The Authors, grant  you the following rights provided that you comply with all terms and conditions of this EULA:
1.1 Installation and use.
You can do whatever you like with the SOURCE CODE, provided that:
- This EULA must ALWAYS accompany the SOURCE CODE.
- The SOURCE CODE may not be executed by more than one processor at any one time or on any single Workstation Computer.
1.2 Beer Clause.
If you find the SOURCE CODE useful, and by some twist of fate you should meet myself or any OTHER NAMED PARTY,
YOU AGREE TO BUY THE FIRST BEER.

2. AUTHORS AND OTHER PARTIES.
Evil Homer (Author)
