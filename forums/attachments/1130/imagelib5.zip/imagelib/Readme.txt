Concering the functions BitmapFromMemory, BitmapFromFile and BitmapFromResource
the statements :

	invoke	CoInitialize, NULL	; at the beginning of the source code

	invoke	CoUninitialize	; at the end of the source code

should be included to initialize and uninitiaize COM

Many thanks to f0dder ,  El_Choni , lamer, KetilO and QvasiModo for the corrections.

http://win.asmcommunity.net/board/index.php?topic=10650.0
http://win.asmcommunity.net/board/index.php?topic=18776.msg145356#msg145356
http://www.masmforum.com/simple/index.php?topic=2743.0
http://win.asmcommunity.net/board/index.php?topic=22185.msg166983#msg166983
http://www.masmforum.com/simple/index.php?topic=937.msg23228#msg23228

November 2005

Vortex