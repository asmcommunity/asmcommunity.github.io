				           External Scanner for Fasm
					
					   Version 3.40 Beta 2
				   ===============================


The Fasmw package (Fasm for Windows) comes with the standard include file set containing all
the  necessary  Win 32 API  function  declarations. These include files  eliminates  the  need  of 
"manual"  building   of   import  sections  for   Fasm  source  files.  As  an  alternative,  this  tool
allows the automated  building  process  of  the  import  table.  The  scanner  supports  also  the
investigation + declaration of external functions for MS COFF output.

The tool requires one initialization file named scan.ini This file must be  filled  with the names of
DLLs containing the external functions used in the asm source files. The tool  creates  always  a 
file with the .imp extension covering all the declarations of external functions.

With the -o switch, you can give other names to the output file instead of the default name of listing file with the .imp
extension :

scan filename.asm -f -o:functions.inc

A typical scan.ini file should contain the usual DLLs:

	kernel32.dll
	user32.dll
	gdi32.dll
	opengl32.dll
	comctl32.dll
	comdlg32.dll

Put a semicolon if you want to skip one or more DLLs:
	
	;comdlg32.dll

In order to "scan" efficiently the source files, it is preferable to specify the frequently  used DLLs
at the top of list. You can put any valid DLL name to the list.

The quick example demonstrates the use of the scanner building the import section for
the source file Msgbox.asm

	scan Msgbox.asm

The tool outputs a file named Msgbox.imp containing the import section with the required
functions:

section '.idata' import data readable writeable

  library kernel32,'kernel32.dll',\
          user32,'user32.dll'

  import kernel32,\
         ExitProcess,'ExitProcess'

  import user32,\
         MessageBox,'MessageBoxA'

Notice that by default, the scanner operates case sensitive. Instructions scanned:
( all characters lower case )

	invoke
	cinvoke
	call ( call and ccall in Tasm source files )
	ccall
	include

The "case sensitive" mode is usefull to "by-pass" include files which doesn't contain any API function.
Skipping these type of include files ( especially large ones ) reduces the work of the tool: 

	Include '%fasminc%\win32a.inc'
	Include '%fasminc%\macro\if.inc'
 
Notice that here, Include begins with upper case " I " instead of lower case "i"

Another method to skip an include file is to put the symbols  ;*  at the end of the line:

	include 'constants.inc' ;*   While "scanning" , this file is omitted.  

Include files with the .imp extension are not processed as they usually contain function declarations:

	include 'asmfile.imp'

To switch to "case insensitive" mode, use the -is option:

	scan filename.asm -f -is

Scan will report all unmatched function names. Also,If none of the external functions are matched, the tool
emits the following the error message:

	No any imported function(s) or check scan.ini for a missing DLL name

If  the  tool  is  invoked  with  only  one  commandline parameter  -  the source  file  name  then  the  default
switch  -f  ( scan for direct Fasm executable file creation ) is assumed.

The optional switch -cd forces the tool to read scan.ini from the current directory. By default, scan gets scan.ini from
the directory where the tool is executed. This switch allows the user to create custom scan.ini files for different asm
projects.

In order to link correctly  Fasm  MS  COFF  object  files,  the  tool  follows  the  decoration  conventions  like
functions names with the leading underscore.

Important  notice  for  Fasm  MS COFF  output  to  be  linked  with   MS Link   \   PoLink,  code  sections
should be declared as the following to avoid duplicate code sections: 

	section '.text' code readable executable

Here is the list of switches intended for Fasm.

	-f  : Fasm

		This is the default switch creating the import section for direct Fasm PE output

	-g  : Fasm+GoLink

		The tool creates an .imp file to link Fasm MS COFF object files with GoLink

	-a  : Fasm+Alink

		The tool creates an .imp file to link Fasm MS COFF object files with Alink
	
	-dc : FASM+MS Link\PoLink (Direct call)
	-ic  : FASM+MS Link\PoLink (Indirect call)

		The tool creates an .imp file to link Fasm MS COFF object files with MS Link \ PoLink

The tool which is freeware can be re-distributed with the only condition that this user manual
and the scan.ini file are accompaigned with the tool scan.exe

Various demonstration examples are included in the package. They are assembled with Fasm V1.64

Originally, the tool was intended to support Fasm. Later, I decided to support also other assemblers such
as Masm,Tasm,LzAsm and HLA.

Scan returns 0 if the process is terminated without errors.

Error codes returned by Scan V3.40 Beta 1

1 - Unable to open filename.ext
2 - Error in command line parameters
3 - File name without extension
4 - Unable to open scan.ini 
5 - Unable to open filename.dll
6 - filename.dll doesn't export any function(s)
7 - No any imported function(s) or check scan.ini for a missing DLL name(s)
8 - Unable to create destination file

Suggestions,reports for any possible bugs are always welcomed.

You can contact me at:

vortex_1@hotmail.com

Happy scannings : )

Vortex
						
October 2005