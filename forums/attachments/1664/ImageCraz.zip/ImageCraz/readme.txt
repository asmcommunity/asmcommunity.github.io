This example was downloaded from Masmwizard.com
this example was written in Altra32 and was really
made to be compiled in that IDE, All though you can
use other methods.

Zcoder....