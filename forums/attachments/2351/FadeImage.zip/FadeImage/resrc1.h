//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by rsrc.rc
//
//#define IDC_NAME                        1001
#define IDC_CREDIT 						1002
//#define IDC_GROUPBOX2	 				1004
#define IDC_HELP 						1005

#define IDC_LBLCOMPANY 					1006
#define IDC_LBLVERSION					1008
#define IDC_LBLPRODUCT					1007
#define IDC_FADEOUT						1010
#define IDC_FADEIN 						1071

#define IDC_GROUPBOX 					3000
//#define IDC_GEN                      	3001
#define IDC_EXIT                        3002
//#define IDC_SERIAL                      3003
#define IDC_BMP							3004					

#define IDM_EXIT                        32003
#define IDC_STATIC                      -1

#define IDI_ICON		 			    105
#define IDB_MAINBMP                     107





