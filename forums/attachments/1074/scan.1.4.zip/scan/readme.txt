scanning import with Vortex's scan from WinAsm Studio
(yet raw)
place "scan.dll" into winasm\add-ins