int __stdcall sum(int x , int y)
{
  return(x+y);
}
