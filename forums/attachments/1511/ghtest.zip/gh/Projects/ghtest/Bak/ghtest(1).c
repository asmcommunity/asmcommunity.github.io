#include <stdio.h>

int main()
{
	int i = 0
	printf("Hello World!\n");
	return 0;
}