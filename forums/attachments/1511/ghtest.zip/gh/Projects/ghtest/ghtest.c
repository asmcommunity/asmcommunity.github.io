include <stdlib.h>

int main()
{
	int i = 0;
	printf("Hello World!\n", x);
	return 0;
}