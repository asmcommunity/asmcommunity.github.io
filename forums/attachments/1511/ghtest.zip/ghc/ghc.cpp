#include <stdio.h>

int main()
{
	printf("Compiling \"D:\\gh\\Projects\\ghtest\\ghtest.c\" file...\n");
	printf("ccv850 -c -cpu=v850e -list -c -Osize -registermode=22 -DOSREG22 -sda=all -prepare_dispose -passsource -g -dual_debug -no_callt -DSECOND_PASS_COMPILATION -DUSED_RAM_SIZE_ALL_NEAR -DOSEK_VECTOR\n");
	printf("\"D:\\gh\\Projects\\ghtest\\ghtest.c\", line 1: error #77-D: this\n");
	printf("          declaration has no storage class or type specifier\n");
	printf("  include <stdlib.h>\n");
	printf("  ^\n");
	printf("\n");
	printf("\"D:\\gh\\Projects\\ghtest\\ghtest.c\", line 1: error #65: expected a \";\"\n");
	printf("  include <stdlib.h>\n");
	printf("          ^\n");
	printf("\n");
	printf("\"D:\\gh\\Projects\\ghtest\\ghtest.c\", line 1: warning #1-D: last line\n");
	printf("          of file ends without a newline\n");
	printf("  }\n");
	printf("   ^\n");
	printf("\n");
	printf("\"D:\\gh\\Projects\\ghtest\\ghtest.c\", At end of source: warning #12-D:\n");
	printf("          parsing restarts here after previous syntax error\n");
	printf("\n");
	return 0;
}
