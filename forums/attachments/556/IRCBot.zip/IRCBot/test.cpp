// test.cpp for windows sockets

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <winsock.h>
#include <stdio.h>
#include <string.h>
#include <process.h>

#define P_JOIN      0         //  :#C
#define P_PART      1         //  #C :U
#define P_PRIVMSG   2         //  #C :Text
#define P_NICK      3         //  :NICK


char szOFile[256];



int         bRunning = 0;
char        myName[128];
char        szNICK[128];
char        szUSER[128];
char        szCOMMAND[128];
char        szCHANNEL[128];
char        szTEXT[8192];
char        szREST[8192];    
char        szCmds[5][10] = {"help","ban","unban","op","deop"};
SOCKET      s;


int ParseRest(int n) {
    char    _l[256];

    switch (n) {
        case P_JOIN:
            if (sscanf(szREST,"%[ :]%s",_l,szCHANNEL))
                return 1;
        break;
        case P_PART:
            if (sscanf(szREST,"%[ ]%s",_l,szCHANNEL))
                return 1;
        break;
        case P_PRIVMSG:
            if (sscanf(szREST,"%[ ]%[^ \r\n:]%[ :]%[^\n\r]",_l,szCHANNEL,_l,szTEXT))
                return 1;
        break;
        case 3:
            if (sscanf(szREST,"%[ :]%s",_l,szTEXT))
                return 1;
        break;
    }
    return 0;
}

int WhichCmd(char* src,char* c,char* p1,char* p2) {
    int i;
    char    _l[256];
    FILE*       f;

    c[0]='\0';

    f = fopen(szOFile,"rt");
    if(f) {
        while(fgets(_l,256,f)) {
            if (strnicmp(_l,szNICK,strlen(szNICK)) == 0) goto LBL_0000001;
        }
        fclose(f);
    }

    return 0;
LBL_0000001:    
    sscanf(src,"%s%s%s",c,p1,p2);
    for (i = 0;i < 5;i++) {
        if (strcmpi(c,szCmds[i]) == 0) return i+1;
    }
    return 0;
}

void    JoinAction(int b,int n) {
    FILE*       f;
    char    _l[256];
    char    _c[30];
    char    _p1[30];
    char    _p2[30];

    if (!b) return;
    _c[0] = '\0';
    _p1[0] = '\0';
    _p2[0] = '\0';
    switch(n) {
    case P_JOIN:
            f = fopen(szOFile,"rt");
            if(f) {
                while(fgets(_l,256,f)) {
                    if (strnicmp(_l,szNICK,strlen(szNICK)) == 0) {
                        sprintf(_l,"MODE %s +o-b %s\n",szCHANNEL,szNICK);
                        send(s,_l,strlen(_l),0);
                        sprintf(_l,"PRIVMSG %s :ZmeY IRC channel bot 0.9 beta for Windows NT\n",szNICK);
                        send(s,_l,strlen(_l),0);
                        sprintf(_l,"PRIVMSG %s :You have permissions to command me.\n",szNICK);
                        send(s,_l,strlen(_l),0);
                        printf("\nOP MODE SENT TO %s ON CHANNEL %s\n",szNICK,szCHANNEL);
                        break;
                    }
                }
                fclose(f);
            }
    break;
    case P_PRIVMSG:
        printf("\nPRIVMSG to %s\n",szCHANNEL);
        if (strcmpi(szCHANNEL,myName) == 0) {
            sprintf(_l,"PRIVMSG %s :ZmeY IRC channel bot 0.9 beta for Windows NT\n",szNICK);
            send(s,_l,strlen(_l),0);
            switch (WhichCmd(szTEXT,_c,_p1,_p2)) {
            case 1:
                sprintf(_l,"PRIVMSG %s :Valid commands are: help,ban ch nc,unban ch nc,op ch nc,deop ch nc\n",szNICK);
                send(s,_l,strlen(_l),0);
                sprintf(_l,"PRIVMSG %s :ch is channel name in form #<channel> , nc is nick of a person\n",szNICK);
                send(s,_l,strlen(_l),0);                
                sprintf(_l,"PRIVMSG %s :End of help\n",szNICK);
                send(s,_l,strlen(_l),0);
            break;
            case 2:
                sprintf(_l,"MODE %s +b %s\n",_p1,_p2);
                send(s,_l,strlen(_l),0);
                sprintf(_l,"PRIVMSG %s :%s banned from %s\n",szNICK,_p2,_p1);
                send(s,_l,strlen(_l),0);
            break;
            case 3:
                sprintf(_l,"MODE %s -b %s!*@*\n",_p1,_p2);
                send(s,_l,strlen(_l),0);
                sprintf(_l,"PRIVMSG %s :%s unbanned from %s\n",szNICK,_p2,_p1);
                send(s,_l,strlen(_l),0);
            break;
            case 4:
                sprintf(_l,"MODE %s +o %s\n",_p1,_p2);
                send(s,_l,strlen(_l),0);
                sprintf(_l,"PRIVMSG %s :%s opped on %s\n",szNICK,_p2,_p1);
                send(s,_l,strlen(_l),0);
            break;
            case 5:
                sprintf(_l,"MODE %s -o %s\n",_p1,_p2);
                send(s,_l,strlen(_l),0);
                sprintf(_l,"PRIVMSG %s :%s deopped on %s\n",szNICK,_p2,_p1);
                send(s,_l,strlen(_l),0);
            break;
            default:
                sprintf(_l,"PRIVMSG %s :%s! You are not authorized.\n",szNICK,szNICK);
                send(s,_l,strlen(_l),0);
            }
            
            printf("\nRESPOND SENT TO %s\n",szNICK);
            break;
        }
    break;
    
    }
}


  

void    Receiver(void* lpv) {
static    char    _l[8192];
static    char    _t[8];
    int     i;
    
    do {
        i = recv(s,_l,8191,0);
        if (!i || i == SOCKET_ERROR) break;
        _l[8192]='\0';
        _l[i]='\0';
        
        
        i = sscanf(_l,":%[^!\n\r ]!%s%s%[^\n\r]",szNICK,szUSER,szCOMMAND,szREST);

        if (i == 4) {
            printf("DETECT COMMAND: |%s|\n",szCOMMAND);
            if (strcmpi(szCOMMAND,"JOIN") == 0) JoinAction(ParseRest(P_JOIN),P_JOIN);                
            if (strcmpi(szCOMMAND,"PART") == 0) JoinAction(ParseRest(P_PART),P_PART);
            if (strcmpi(szCOMMAND,"PRIVMSG") == 0) JoinAction(ParseRest(P_PRIVMSG),P_PRIVMSG);
            if (strcmpi(szCOMMAND,"NICK") == 0) JoinAction(ParseRest(P_NICK),P_NICK);
        } else {
            strncpy(_t,_l,4);
            _t[4] = '\0';
            if (strcmpi(_t,"PING") == 0) {
                send(s,"PONG\n",strlen("PONG\n"),0);
            }
        }
    } while (1);
    bRunning = 0;
    _endthread();
}


int main(int narg,char* varg[]) {
    sockaddr_in     sin;
    int             nRead = 0;
    char            _l[257];
    u_short         usPort;
    WSAData         wsd;
    HOSTENT*        phent;

    
    if (narg < 5) {
        printf("usage: test hostname port nick channel opfile");
        return 1;
    }
    if (WSAStartup(0x101,&wsd) != 0) {
        printf("winsock not initalized");
        return 4;
    }
    phent = gethostbyname(varg[1]);
    if (!phent) {
        printf("can't find host");
        return 5;
    }
    if (narg > 5) {
        strncpy(szOFile,varg[5],256);
    } 
    sscanf(varg[2],"%hd",&usPort);
    sin.sin_family      = AF_INET;
    sin.sin_port        = htons(usPort);
    memcpy(&sin.sin_addr,phent->h_addr,phent->h_length);
    printf("addr: %d.%d.%d.%d:%d\n",
            sin.sin_addr.S_un.S_un_b.s_b1,
            sin.sin_addr.S_un.S_un_b.s_b2,
            sin.sin_addr.S_un.S_un_b.s_b3,
            sin.sin_addr.S_un.S_un_b.s_b4,usPort);

LBL_RECONNECT:
    s = socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
    if (s == SOCKET_ERROR) {
        printf("error getting socket");
        return 2;
    }
    printf("\nConnecting .........\n");
    if (connect(s,(sockaddr*)&sin,sizeof(sockaddr_in)) == SOCKET_ERROR) {
        printf("\nsocket error\n");
        goto LBL_RECONNECT;
    }
    bRunning = 1;
    strcpy(myName,varg[3]);
    
    
    sprintf(_l,"USER %s asmodeus.zmey micle.zmey :ZmeY IRC channel bot beta 1\n",varg[3]);
    send(s,_l,strlen(_l),0);
    printf("\n%s",_l);
    sprintf(_l,"NICK %s\n",varg[3]);
    send(s,_l,strlen(_l),0);
    printf("\n%s",_l);
    _beginthread(Receiver,65535,NULL);
    Sleep(1000);
    sprintf(_l,"JOIN %s\n",varg[4]);
    send(s,_l,strlen(_l),0);
    printf("\n%s",_l);
    
    while (bRunning) {
        Sleep(200000);
        sprintf(_l,"JOIN %s\n",varg[4]);
        send(s,_l,strlen(_l),0);
    }
    printf("\nConnection lost !!!\n");
    closesocket(s);
    goto LBL_RECONNECT;
    WSACleanup();
    return 0;
}
