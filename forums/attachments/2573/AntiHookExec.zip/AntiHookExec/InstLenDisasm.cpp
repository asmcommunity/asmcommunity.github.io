//*******************************************************************************************************
// AntiHookExec.cpp : Defines the entry point for the console application.
//
// Version 1.00
// Copyright (c) 2004 Chew Keong TAN
// All rights reserved.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, and/or sell copies of the Software, and to permit persons
// to whom the Software is furnished to do so, provided that the above
// copyright notice(s) and this permission notice appear in all copies of
// the Software and that both the above copyright notice(s) and this
// permission notice appear in supporting documentation.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT
// OF THIRD PARTY RIGHTS. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
// HOLDERS INCLUDED IN THIS NOTICE BE LIABLE FOR ANY CLAIM, OR ANY SPECIAL
// INDIRECT OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING
// FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT,
// NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION
// WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
//
//*******************************************************************************************************
#include <windows.h>

#define OP_HAS_MODRM		0x00000001
#define OP_PREFIX			0x00000002
#define OP_TWOBYTE_OP		0x00000004
#define OP_HAS_IMM1			0x00000008
#define OP_HAS_IMM2			0x00000010
#define OP_HAS_IMM4			0x00000020
#define OP_OPSIZE_PREFIX	0x00000040
#define OP_ADRSIZE_PREFIX	0x00000080
#define OP_CHECK_66			0x00000100
#define OP_CHECK_67			0x00000200
#define OP_HAS_DISP8		0x00000400
#define OP_HAS_DISP16		0x00000800
#define OP_HAS_DISP32		0x00001000
#define OP_UNDEFINED		0xFFFFFFFF

DWORD OneByteOpCode[] =
{
	OP_HAS_MODRM,		// ADD Eb, Gb		00
	OP_HAS_MODRM,		// ADD Ev, Gv
	OP_HAS_MODRM,		// ADD Gb, Eb
	OP_HAS_MODRM,		// ADD Gv, Ev
	OP_HAS_IMM1,		// ADD AL, Ib
	OP_CHECK_66,		// ADD eAX, Iv
	0,					// PUSH ES
	0,					// POP ES			07
	OP_HAS_MODRM,		// OR Eb, Gb
	OP_HAS_MODRM,		// OR Ev, Gv
	OP_HAS_MODRM,		// OR Gb, Eb
	OP_HAS_MODRM,		// OR Gv, Ev
	OP_HAS_IMM1,		// OR AL, Ib
	OP_CHECK_66,		// OR eAX, Iv
	0,					// PUSH CS
	OP_TWOBYTE_OP,		// 2-byte Escape	0F


	OP_HAS_MODRM,		// ADC Eb, Gb		10
	OP_HAS_MODRM,		// ADC Ev, Gv
	OP_HAS_MODRM,		// ADC Gb, Eb
	OP_HAS_MODRM,		// ADC Gv, Ev
	OP_HAS_IMM1,		// ADC AL, Ib
	OP_CHECK_66,		// ADC eAX, Iv
	0,					// PUSH SS
	0,					// POP SS			17
	OP_HAS_MODRM,		// SBB Eb, Gb		
	OP_HAS_MODRM,		// SBB Ev, Gv
	OP_HAS_MODRM,		// SBB Gb, Eb
	OP_HAS_MODRM,		// SBB Gv, Ev
	OP_HAS_IMM1,		// SBB AL, Ib
	OP_CHECK_66,		// SBB eAX, Iv
	0,					// PUSH DS
	0,					// POP DS			1F

	OP_HAS_MODRM,		// AND Eb, Gb		20
	OP_HAS_MODRM,		// AND Ev, Gv
	OP_HAS_MODRM,		// AND Gb, Eb
	OP_HAS_MODRM,		// AND Gv, Ev
	OP_HAS_IMM1,		// AND AL, Ib
	OP_CHECK_66,		// AND eAX, Iv
	OP_PREFIX,			// ES-Seg PREFIX	26
	0,					// DAA				27
	OP_HAS_MODRM,		// SUB Eb, Gb		
	OP_HAS_MODRM,		// SUB Ev, Gv
	OP_HAS_MODRM,		// SUB Gb, Eb
	OP_HAS_MODRM,		// SUB Gv, Ev
	OP_HAS_IMM1,		// SUB AL, Ib
	OP_CHECK_66,		// SUB eAX, Iv
	OP_PREFIX,			// CS-Seg PREFIX	2E
	0,					// DAS				2F

	OP_HAS_MODRM,		// XOR Eb, Gb		30
	OP_HAS_MODRM,		// XOR Ev, Gv
	OP_HAS_MODRM,		// XOR Gb, Eb
	OP_HAS_MODRM,		// XOR Gv, Ev
	OP_HAS_IMM1,		// XOR AL, Ib
	OP_CHECK_66,		// XOR eAX, Iv
	OP_PREFIX,			// SS-Seg PREFIX	36
	0,					// AAA				37
	OP_HAS_MODRM,		// CMP Eb, Gb		
	OP_HAS_MODRM,		// CMP Ev, Gv
	OP_HAS_MODRM,		// CMP Gb, Eb
	OP_HAS_MODRM,		// CMP Gv, Ev
	OP_HAS_IMM1,		// CMP AL, Ib
	OP_CHECK_66,		// CMP eAX, Iv
	OP_PREFIX,			// DS-Seg PREFIX	3E
	0,					// AAS				3F

	0,					// INC eAX			40
	0,					// INC eCX
	0,					// INC eDX
	0,					// INC eBX
	0,					// INC eSP
	0,					// INC eBP
	0,					// INC eSI
	0,					// INC eDI
	0,					// DEC eAX
	0,					// DEC eCX
	0,					// DEC eDX
	0,					// DEC eBX
	0,					// DEC eSP
	0,					// DEC eBP
	0,					// DEC eSI
	0,					// DEC eDI			4F
	
	0,					// POP eAX			50
	0,					// POP eCX
	0,					// POP eDX
	0,					// POP eBX
	0,					// POP eSP
	0,					// POP eBP
	0,					// POP eSI
	0,					// POP eDI
	0,					// PUSH eAX
	0,					// PUSH eCX
	0,					// PUSH eDX
	0,					// PUSH eBX
	0,					// PUSH eSP
	0,					// PUSH eBP
	0,					// PUSH eSI
	0,					// PUSH eDI			5F

	0,					// PUSHA/PUSHAD		60
	0,					// POPA/POPAD		61
	OP_HAS_MODRM,		// BOUND Gv, Ma		62
	OP_HAS_MODRM,		// ARPL Ew, Gw		63 /r
	OP_PREFIX,			// FS-Seg PREFIX	64
	OP_PREFIX,			// GS-Seg PREFIX	65
	OP_PREFIX + OP_OPSIZE_PREFIX,			// OpdSize PREDIX		66
	OP_PREFIX + OP_ADRSIZE_PREFIX,			// AddrSize PREFIX		67

	OP_CHECK_66,							// PUSH Iv				68
	OP_HAS_MODRM + OP_CHECK_66,				// IMUL Gv, Ev, Iv		69
	OP_HAS_IMM1,							// PUSH Ib				6A
	OP_HAS_MODRM + OP_HAS_IMM1,				// IMUL Gv, Ev, Ib		6B
	0,										// INS/INSB Yb, DX		6C
	0,										// INS/INSW/INSD Yv, DX	6D
	0,										// OUTS/OUTSB DX, Xb	6E
	0,										// OUTS/OUTSW/OUTSD DX, Xv	6F

	OP_HAS_IMM1,							// JO Jb				70
	OP_HAS_IMM1,							// JNO Jb
	OP_HAS_IMM1,							// JB/NAE/C Jb
	OP_HAS_IMM1,							// JNB/AE/NC Jb
	OP_HAS_IMM1,							// JZ/E Jb
	OP_HAS_IMM1,							// JNZ/NE Jb
	OP_HAS_IMM1,							// JBE/NA Jb
	OP_HAS_IMM1,							// JNBE/A Jb			77
	OP_HAS_IMM1,							// JS Jb
	OP_HAS_IMM1,							// JNS Jb
	OP_HAS_IMM1,							// JP/PE Jb
	OP_HAS_IMM1,							// JNP/PO Jb
	OP_HAS_IMM1,							// JL/NGE Jb
	OP_HAS_IMM1,							// JNL/GE Jb
	OP_HAS_IMM1,							// JLE/NG Jb
	OP_HAS_IMM1,							// JNLE/G Jb			7F

	OP_HAS_MODRM + OP_HAS_IMM1,				// Eb, Ib				80
	OP_HAS_MODRM + OP_CHECK_66,				// Ev, Iv				81
	OP_HAS_MODRM + OP_HAS_IMM1,				// Ev, Ib				82
	OP_HAS_MODRM + OP_HAS_IMM1,				// Ev, Ib				83

	OP_HAS_MODRM,							// TEST Eb, Gb			84
	OP_HAS_MODRM,							// TEST Ev, Gv			85
	OP_HAS_MODRM,							// XCHG Eb, Gb			86
	OP_HAS_MODRM,							// XCHG Ev, Gv			87
	OP_HAS_MODRM,							// MOV Eb, Gb			88
	OP_HAS_MODRM,							// MOV Ev, Gv			89
	OP_HAS_MODRM,							// MOV Gb, Eb			8A
	OP_HAS_MODRM,							// MOV Gv, Ev			8B
	OP_HAS_MODRM,							// MOV Ew, Sw			8C

	OP_HAS_MODRM,							// LEA Gv, M			8D
	OP_HAS_MODRM,							// MOV Sw, Ew			8E
	OP_HAS_MODRM,							// POP Ev				8F

	0,					// NOP					90
	0,					// XCHG eAX, eCX		91
	0,					// XCHG eAX, eDX		92
	0,					// XCHG eAX, eBX		93
	0,					// XCHG eAX, eSP		94
	0,					// XCHG eAX, eBP		95
	0,					// XCHG eAX, eSI		96
	0,					// XCHG eAX, eDI		97
	0,					// CBW/CWDE				98
	0,					// CWD/CDQ				99
	OP_CHECK_66 + OP_HAS_IMM2,				// CALLF Ap				9A	(w/o opsize mod == 6 bytes imm, w opsize mod == 4 byte imm)
	0,					// FWAIT/WAIT			9B
	0,					// PUSHF/PUSHFD	Fv		9C
	0,					// POPF/POPFD Fv		9D
	0,					// SAHF
	0,					// LAHF					9F

	OP_CHECK_67,		// MOV AL, 0b				A0		Ob = 2 byte or 4 byte addr depending of addrsize prefix
	OP_CHECK_67,		// MOV eAX, 0v				A1
	OP_CHECK_67,		// MOV 0b, AL				A2		Ob = 2 byte or 4 byte addr depending of addrsize prefix
	OP_CHECK_67,		// MOV 0v, eAX				A3
	0,					// MOVS/MOVSB Xb, Yb		A4
	0,					// MOVS/MOVSW/MOVSD Xv, Yv	A5
	0,					// CMPS/CMPSB Xb, Yb		A6
	0,					// CMPS/CMPSW/CMPSD Xv, Yv	A7
	OP_HAS_IMM1,		// TEST AL, Ib				A8
	OP_CHECK_66,		// TEST eAX, Iv				A9
	0,					// STOS/STOSB Yb, AL		AA
	0,					// STOS/STOSW/STOSD Yv, eAX		AB
	0,					// LODS/LODSB AL, Xb			AC
	0,					// LODS/LODSW/ODSD eAX, Xv		AD
	0,					// SCAS/SCASB AL, Yb			AE
	0,					// SCAS/SCASW/SCASD eAX, Xv		AF

	OP_HAS_IMM1,		// MOV AL, Ib				B0
	OP_HAS_IMM1,		// MOV CL, Ib
	OP_HAS_IMM1,		// MOV DL, Ib
	OP_HAS_IMM1,		// MOV BL, Ib
	OP_HAS_IMM1,		// MOV AH, Ib
	OP_HAS_IMM1,		// MOV CH, Ib
	OP_HAS_IMM1,		// MOV DH, Ib
	OP_HAS_IMM1,		// MOV BH, Ib
	OP_CHECK_66,		// MOV eAX, Iv				B8
	OP_CHECK_66,		// MOV eCX, Iv				B9
	OP_CHECK_66,		// MOV eDX, Iv				BA
	OP_CHECK_66,		// MOV eBX, Iv				BB
	OP_CHECK_66,		// MOV eSP, Iv				BC
	OP_CHECK_66,		// MOV eBP, Iv				BD
	OP_CHECK_66,		// MOV eSI, Iv				BE
	OP_CHECK_66,		// MOV eDI, Iv				BF

	OP_HAS_MODRM + OP_HAS_IMM1,		// Eb, Ib		C0
	OP_HAS_MODRM + OP_HAS_IMM1,		// Ev, Ib		C1
	OP_HAS_IMM2,					// RETN Iw		C2
	0,								// RETN			C3
	OP_HAS_MODRM,					// LES Gv, Mp	C4
	OP_HAS_MODRM,					// LDS Gv, Mp	C5
	OP_HAS_MODRM + OP_HAS_IMM1,		// MOV Eb, Ib	C6
	OP_HAS_MODRM + OP_CHECK_66,		// MOV Ev, Iv	C7

	OP_HAS_IMM2 + OP_HAS_IMM1,		// ENTER Iw, Ib	C8
	0,								// LEAVE
	OP_HAS_IMM2,					// RETF Iw
	0,								// RETF
	0,								// INT 3		CC
	OP_HAS_IMM1,					// INT Ib		CD
	0,								// INTO
	0,								// IRET			CF

	OP_HAS_MODRM,		// Eb, 1	D0
	OP_HAS_MODRM,		// Ev, 1	D1
	OP_HAS_MODRM,		// Eb, CL	D2
	OP_HAS_MODRM,		// Ev, CL	D3
	OP_HAS_IMM1,		// AAM Ib
	OP_HAS_IMM1,		// AAD Ib
	0,					// SALC		D6
	0,					// XLAT/XLATB D7

	OP_HAS_MODRM,		// ESC to coprocessor	D8
	OP_HAS_MODRM,		// ESC to coprocessor	D9
	OP_HAS_MODRM,		// ESC to coprocessor	DA
	OP_HAS_MODRM,		// ESC to coprocessor	DB
	OP_HAS_MODRM,		// ESC to coprocessor	DC
	OP_HAS_MODRM,		// ESC to coprocessor	DD
	OP_HAS_MODRM,		// ESC to coprocessor	DE
	OP_HAS_MODRM,		// ESC to coprocessor	DF

	OP_HAS_IMM1,		// LOOPNE/LOOPNZ Jb		E0
	OP_HAS_IMM1,		// LOOPE/LOOPZ Jb		E1
	OP_HAS_IMM1,		// LOOP Jb				E2
	OP_HAS_IMM1,		// JCXZ/JECXZ Jb		E3
	OP_HAS_IMM1,		// IN AL, Ib			E4
	OP_HAS_IMM1,		// IN eAX, Ib			E5
	OP_HAS_IMM1,		// OUT Ib, AL			E6
	OP_HAS_IMM1,		// OUT Ib, eAX			E7

	OP_CHECK_66,		// CALL Jv				E8
	OP_CHECK_66,		// JMP Jv				E9
	OP_CHECK_66 + OP_HAS_IMM2,		// JMP Ap	EA
	OP_HAS_IMM1,			// JMP Jb				EB
	0,					// IN AL, DX			EC
	0,					// IN eAX, DX			ED
	0,					// OUT DX, AL			EE
	0,					// OUT DX, eAX			EF

	OP_PREFIX,			// LOCK			F0
	0,					// INT1			F1
	OP_PREFIX,			// REPNE		F2
	OP_PREFIX,			// REP/REPE		F3
	0,					// HLT			F4
	0,					// CMC			F5
	OP_HAS_MODRM,		// Eb			F6
	OP_HAS_MODRM,		// Ev			F7
	0,					// CLC
	0,					// STC
	0,					// CLI
	0,					// STI
	0,					// CLD
	0,					// STD
	OP_HAS_MODRM,		// INC/DEC		FE
	OP_HAS_MODRM		// INC/DEC		FF
};


DWORD TwoByteOpCode[] =
{
	OP_HAS_MODRM,		// Grp6 1A		00
	OP_HAS_MODRM,		// Grp7 1A		01
	OP_HAS_MODRM,		// LAR Gv, Ew	02
	OP_HAS_MODRM,		// LSL Gv, Ew	03
	OP_UNDEFINED,		//				04
	0,					// SYSCALL		05
	0,					// CLTS			06
	0,					// SYSRET		07

	0,					// INVD			08
	0,					// WBINVD		09
	OP_UNDEFINED,		//				0A
	0,					// UD2			0B
	OP_UNDEFINED,		//				0C
	OP_UNDEFINED,		//				0D
	0,					// FEMMS		0E
	OP_UNDEFINED,		//				0F

	OP_HAS_MODRM,		// movups Vps, Wps	10
	OP_HAS_MODRM,		// movups Wps, Vps	11
	OP_HAS_MODRM,		// movlps Wq, Vq  movhlps Vq, Vq	12
	OP_HAS_MODRM,		// movlps Vq, Wq	13
	OP_HAS_MODRM,		// unpcklps Vps, Wq	14
	OP_HAS_MODRM,		// unpckhps Vps, Wq	15
	OP_HAS_MODRM,		// movhps Vq, Wq	16
	OP_HAS_MODRM,		// movhps Wq, Vq	17

	OP_HAS_MODRM,		// PREFATCH 1D		18
	OP_UNDEFINED,		// 19
	OP_UNDEFINED,		// 1A
	OP_UNDEFINED,		// 1B
	OP_UNDEFINED,		// 1C
	OP_UNDEFINED,		// 1D
	OP_UNDEFINED,		// 1E
	OP_UNDEFINED,		// 1F

	OP_HAS_MODRM,		// MOV Rd, Cd		20
	OP_HAS_MODRM,		// MOV Rd, Dd		21
	OP_HAS_MODRM,		// MOV Cd, Rd		22
	OP_HAS_MODRM,		// MOV Dd, Rd		23
	OP_UNDEFINED,		// 24 (MOV Rd, Td)??
	OP_UNDEFINED,		// 25
	OP_UNDEFINED,		// 26 (MOV Td, Rd)??
	OP_UNDEFINED,		// 27

	OP_HAS_MODRM,		// MOVAPS Vps, Wps	28
	OP_HAS_MODRM,		// MOVAPS Wps, Vps	29
	OP_HAS_MODRM,		// CVTPI2PS Vps, Qq		2A
	OP_HAS_MODRM,		// MOVNTPS Wps, Vps		2B
	OP_HAS_MODRM,		// CVTTPS2PI Qq, Wps	2C
	OP_HAS_MODRM,		// CVTPS2PI Qq Wps		2D
	OP_HAS_MODRM,		// UCOMISS Vss, Wss		2E
	OP_HAS_MODRM,		// COMISS Vps, Wps		2F

	0,					// WRMSR			30
	0,					// RDTSC			31
	0,					// RDMSR			32
	0,					// RDPMC			33
	0,					// SYSENTER			34
	0,					// SYSEXIT			35
	OP_UNDEFINED,		// 36
	OP_UNDEFINED,		// 37
	OP_UNDEFINED,		// 38
	OP_UNDEFINED,		// 39
	OP_UNDEFINED,		// 3A
	OP_UNDEFINED,		// 3B
	OP_UNDEFINED,		// 3C
	OP_UNDEFINED,		// 3D
	OP_UNDEFINED,		// 3E
	OP_UNDEFINED,		// 3F

	OP_HAS_MODRM,		// CMOVO Gv, Ev				40
	OP_HAS_MODRM,		// CMOVNO Gv, Ev			41
	OP_HAS_MODRM,		// CMOVB/C/NAE Gv, Ev		42
	OP_HAS_MODRM,		// CMOVAE/NB/NC Gv, Ev		43
	OP_HAS_MODRM,		// CMOVE/Z Gv, Ev			44
	OP_HAS_MODRM,		// CMOVNE/NZ Gv, Ev			45
	OP_HAS_MODRM,		// CMOVBE/NA Gv, Ev			46
	OP_HAS_MODRM,		// CMOVA/NBE Gv, Ev			47

	OP_HAS_MODRM,		// CMOVS Gv, Ev				48
	OP_HAS_MODRM,		// CMOVNS Gv, Ev			49
	OP_HAS_MODRM,		// CMOVP/PE Gv, Ev			4A
	OP_HAS_MODRM,		// CMOVNP/PO Gv, Ev			4B
	OP_HAS_MODRM,		// CMOVL/NGE Gv, Ev			4C
	OP_HAS_MODRM,		// CMOVNL/GE Gv, Ev			4D
	OP_HAS_MODRM,		// CMOVLE/NG Gv, Ev			4E
	OP_HAS_MODRM,		// CMOVNLE/G Gv, Ev			4F

	OP_HAS_MODRM,		// MOVMSKPS Ed, Vps			50
	OP_HAS_MODRM,		// SQRTPS Vps, Wps			51
	OP_HAS_MODRM,		// RSQRTPS Vps, Wps			52
	OP_HAS_MODRM,		// RCPPS Vps, Wps			53
	OP_HAS_MODRM,		// ANDPS Vps, Wps			54
	OP_HAS_MODRM,		// ANDNPS Vps, Wps			55
	OP_HAS_MODRM,		// ORPS Vps, Wps			56
	OP_HAS_MODRM,		// XORPS Vps, Wps			57

	OP_HAS_MODRM,		// ADDPS Vps, Wps			58
	OP_HAS_MODRM,		// MULPS Vps, Wps			59
	OP_UNDEFINED,		// 5A
	OP_UNDEFINED,		// 5B
	OP_HAS_MODRM,		// SUBPS Vps, Wps			5C
	OP_HAS_MODRM,		// MINPS Vps, Wps			5D
	OP_HAS_MODRM,		// DIVPS Vps, Wps			5E
	OP_HAS_MODRM,		// MAXPS Vps, Wps			5F

	OP_HAS_MODRM,		// punpcklbw Pq, Qd			60
	OP_HAS_MODRM,		// punpcklwd Pq, Qd			61
	OP_HAS_MODRM,		// punpckldq Pq, Qd			62
	OP_HAS_MODRM,		// packsswb Pq, Qd			63
	OP_HAS_MODRM,		// pcmpgtb Pq, Qd			64
	OP_HAS_MODRM,		// pcmpgtw Pq, Qd			65
	OP_HAS_MODRM,		// pcmpgtd Pq, Qd			66
	OP_HAS_MODRM,		// packuswb Pq, Qd			67

	OP_HAS_MODRM,		// punpckhbw Pq, Qd			68
	OP_HAS_MODRM,		// punpckhwd Pq, Qd			69
	OP_HAS_MODRM,		// punpckhdq Pq, Qd			6A
	OP_HAS_MODRM,		// packssdw Pq, Qd			6B
	OP_UNDEFINED,		// 6C
	OP_UNDEFINED,		// 6D
	OP_HAS_MODRM,		// movd Pd, Ed				6E
	OP_HAS_MODRM,		// movq Pq, Qq				6F

	OP_HAS_MODRM + OP_HAS_IMM1,		// pshufw Pq, Qq, Ib		70
	OP_HAS_MODRM + OP_HAS_IMM1,		// pshimw Pq, Qq			71
	OP_HAS_MODRM + OP_HAS_IMM1,		// pshimd Pq, Qq			72
	OP_HAS_MODRM + OP_HAS_IMM1,		// pshimq Pq, Qq			73
	OP_HAS_MODRM,		// pcmpeqb Pq, Qq			74
	OP_HAS_MODRM,		// pcmpeqw Pq, Qq			75
	OP_HAS_MODRM,		// pcmpeqd Pq, Qq			76
	0,					// emms						77
	OP_UNDEFINED,		// 78
	OP_UNDEFINED,		// 79
	OP_UNDEFINED,		// 7A
	OP_UNDEFINED,		// 7B
	OP_UNDEFINED,		// 7C
	OP_UNDEFINED,		// 7D
	OP_HAS_MODRM,		// movd Ed, Pd				7E
	OP_HAS_MODRM,		// movq Qq, Pq				7F

	OP_CHECK_66,		// JO Jv				80
	OP_CHECK_66,		// JNO Jv				81
	OP_CHECK_66,		// JB/C/NAE Jv			82
	OP_CHECK_66,		// JAE/NB/NC Jv			83
	OP_CHECK_66,		// JE/Z Jv				84
	OP_CHECK_66,		// JNE/NZ Jv			85
	OP_CHECK_66,		// JBE/NA Jv			86
	OP_CHECK_66,		// JA/NBE Jv			87
	
	OP_CHECK_66,		// JS Jv				88
	OP_CHECK_66,		// JNS Jv				89
	OP_CHECK_66,		// JP/PE Jv				8A
	OP_CHECK_66,		// JNP/PO Jv			8B
	OP_CHECK_66,		// JL/NGE Jv			8C
	OP_CHECK_66,		// JNL/GE Jv			8D
	OP_CHECK_66,		// JLE/NG Jv			8E
	OP_CHECK_66,		// JNLE/G Jv			8F

	OP_HAS_MODRM,			//SETO Eb				90
	OP_HAS_MODRM,			//SETNO Eb				91
	OP_HAS_MODRM,			//SETB/C/NAE Eb			92
	OP_HAS_MODRM,			//SETAE/NB/NC Eb		93
	OP_HAS_MODRM,			//SETE/Z Eb				94
	OP_HAS_MODRM,			//SETNE/NZ Eb			95
	OP_HAS_MODRM,			//SETBE/NA Eb			96
	OP_HAS_MODRM,			//SETA/NBE Eb			97

	OP_HAS_MODRM,			//SETS Eb				98
	OP_HAS_MODRM,			//SETNS Eb				99
	OP_HAS_MODRM,			//SETP/PE Eb			9A
	OP_HAS_MODRM,			//SETNP/PO Eb			9B
	OP_HAS_MODRM,			//SETL/NGE Eb			9C
	OP_HAS_MODRM,			//SETNL/GE Eb			9D
	OP_HAS_MODRM,			//SETLE/NG Eb			9E
	OP_HAS_MODRM,			//SETNLE/G Eb			9F

	0,								// PUSH FS			A0
	0,								// POP FS			A1
	0,								// CPUID			A2
	OP_HAS_MODRM,					// BT Ev, Gv		A3
	OP_HAS_MODRM + OP_HAS_IMM1,		// SHLD Ev, Gv, Ib	A4
	OP_HAS_MODRM,					// SHLD Ev, Gv, CL	A5
	OP_UNDEFINED,					// A6
	OP_UNDEFINED,					// A7
	
	0,								// PUSH GS			A8
	0,								// POP GS			A9
	0,								// RSM				AA
	OP_HAS_MODRM,					// BTS Ev, Gv		AB
	OP_HAS_MODRM + OP_HAS_IMM1,		// SHRD Ev, Gv, Ib	AC
	OP_HAS_MODRM,					// SHRD Ev, Gv, CL	AD
	OP_HAS_MODRM,					// FXSAVE			AE
	OP_HAS_MODRM,					// IMUL Gv, Ev		AF

	OP_HAS_MODRM,					// CMPXCHG Eb, Gb	B0
	OP_HAS_MODRM,					// CMPXCHG Ev, Gv	B1
	OP_HAS_MODRM,					// LSS Mp			B2
	OP_HAS_MODRM,					// BTR Ev, Gv		B3
	OP_HAS_MODRM,					// LFS Mp			B4
	OP_HAS_MODRM,					// LGS Mp			B5
	OP_HAS_MODRM,					// MOVZX Gv, Eb		B6
	OP_HAS_MODRM,					// MOVZX Gv, Ew		B7

	OP_UNDEFINED,					// B8
	0,								// UD				B9
	OP_HAS_MODRM + OP_HAS_IMM1,		// Ev, Ib			BA
	OP_HAS_MODRM,					// BTC Ev, Gv		BB
	OP_HAS_MODRM,					// BSF Gv, Ev		BC
	OP_HAS_MODRM,					// BSR Gv, Ev		BD
	OP_HAS_MODRM,					// MOVSX Gv, Eb		BE
	OP_HAS_MODRM,					// MOVSX Gv, Ew		BF

	OP_HAS_MODRM,					// XADD Eb, Gb			C0
	OP_HAS_MODRM,					// XADD Ev, Gv			C1
	OP_HAS_MODRM + OP_HAS_IMM1,		// CMPPS Vps, Wps, Ib	C2
	OP_UNDEFINED,					// C3
	OP_HAS_MODRM + OP_HAS_IMM1,		// PINSRW Pq, Ed, Ib	C4
	OP_HAS_MODRM + OP_HAS_IMM1,		// PEXTRW Gd, Pq, Ib	C5
	OP_HAS_MODRM + OP_HAS_IMM1,		// SHUFPS Vps, Wps, Ib	C6
	OP_HAS_MODRM,					// Group 9(1A)			C7

	0,					// BSWAP EAX		C8
	0,					// BSWAP EAX		C9
	0,					// BSWAP EAX		CA
	0,					// BSWAP EAX		CB
	0,					// BSWAP EAX		CC
	0,					// BSWAP EAX		CD
	0,					// BSWAP EAX		CE
	0,					// BSWAP EAX		CF

	OP_UNDEFINED,		// D0
	OP_HAS_MODRM,		// PSRLW Pq, Qq		D1
	OP_HAS_MODRM,		// PSRLD Pq, Qq		D2
	OP_HAS_MODRM,		// PSRLQ Pq, Qq		D3
	OP_UNDEFINED,		// D4
	OP_HAS_MODRM,		// PMULLW Pq, Qq	D5
	OP_UNDEFINED,		// D6
	OP_HAS_MODRM,		// PMOVMSKB Gd, Pq	D7

	OP_HAS_MODRM,		// PSUBUSB Pq, Qq		D8
	OP_HAS_MODRM,		// PSUBUSW Pq, Qq		D9
	OP_HAS_MODRM,		// PMINUB Pq, Qq		DA
	OP_HAS_MODRM,		// PAND Pq, Qq			DB
	OP_HAS_MODRM,		// PADDUSB Pq, Qq		DC
	OP_HAS_MODRM,		// PADDUSW Pq, Qq		DD
	OP_HAS_MODRM,		// PMAXUB Pq, Qq		DE
	OP_HAS_MODRM,		// PANDN Pq, Qq			DF

	OP_HAS_MODRM,		// PAVGB Pq, Qq			E0
	OP_HAS_MODRM,		// PSRAW Pq, Qq			E1
	OP_HAS_MODRM,		// PSRAD Pq, Qq			E2
	OP_HAS_MODRM,		// PAVGW Pq, Qq			E3
	OP_HAS_MODRM,		// PMULHUW Pq, Qq		E4
	OP_HAS_MODRM,		// PMULHW Pq, Qq		E5
	OP_UNDEFINED,		// E6
	OP_HAS_MODRM,		// MOVNTQ Wq, Vq		E7

	OP_HAS_MODRM,		// PSUBSB Pq, Qq		E8
	OP_HAS_MODRM,		// PSUBSW Pq, Qq		E9
	OP_HAS_MODRM,		// PMINSW Pq, Qq		EA
	OP_HAS_MODRM,		// POR Pq, Qq			EB
	OP_HAS_MODRM,		// PADDSB Pq, Qq		EC
	OP_HAS_MODRM,		// PADDSW Pq, Qq		ED
	OP_HAS_MODRM,		// PMAXSW Pq, Qq		EE
	OP_HAS_MODRM,		// PXOR Pq, Qq			EF

	OP_UNDEFINED,		// F0
	OP_HAS_MODRM,		// PSLLW Pq, Qq			F1
	OP_HAS_MODRM,		// PSLLD Pq, Qq			F2
	OP_HAS_MODRM,		// PSLLQ Pq, Qq			F3
	OP_UNDEFINED,		// F4
	OP_HAS_MODRM,		// PMADDWD Pq, Qq		F5
	OP_HAS_MODRM,		// PSADBW Pq, Qq		F6
	OP_HAS_MODRM,		// MASKMOVQ Ppi, Qpi	F7

	OP_HAS_MODRM,		// PSUBB Pq, Qq			F8
	OP_HAS_MODRM,		// PSUBW Pq, Qq			F9
	OP_HAS_MODRM,		// PSUBD Pq, Qq			FA
	OP_UNDEFINED,		// FB
	OP_HAS_MODRM,		// PADDB Pq, Qq			FC
	OP_HAS_MODRM,		// PADDW Pq, Qq			FD
	OP_HAS_MODRM,		// PADDD Pq, Qq			FE
	OP_UNDEFINED,		// FF

};



DWORD getInstLength(unsigned char *opcodeStart)
{
	DWORD flag = 0;
	unsigned char *instPtr1 = opcodeStart; 
	unsigned char opcode;

	do
	{		
		flag &= (~OP_PREFIX);
		opcode = *instPtr1++;
		flag |= OneByteOpCode[opcode];

		if(opcode == 0xF6)		// need to handle TEST inst since it has an imm (TEST /0 Ib)
		{
			if(!(*instPtr1 & 0x38))		//reg/op of modrm == 0 (becos TEST /O)
				flag |= OP_HAS_IMM1;
		}
		else if(opcode == 0xF7)	// need to handle TEST inst since it has an imm (TEST /0 Iv)
		{
			if(!(*instPtr1 & 0x38))		//reg/op of modrm == 0 (becos TEST /O)
				flag |= OP_CHECK_66;
										// the rest, DIV, IDIV, IMUL, MUL, NEG, NOT have no imm.
		}

		if(flag & OP_TWOBYTE_OP)
		{
			flag &= (~OP_TWOBYTE_OP);
			flag |= TwoByteOpCode[*instPtr1++];
		}
		if(flag == OP_UNDEFINED)
			flag = 0;
	}
	while(flag & OP_PREFIX);

	//printf("Flag = %X\n", flag);
	if(flag & OP_CHECK_66)
	{				
		if(flag & OP_OPSIZE_PREFIX)
		{
			//printf("Has OP Prefix\n");
			flag |= OP_HAS_IMM2;
		}
		else
		{
			//printf("Has NO OP Prefix\n");
			flag |= OP_HAS_IMM4;
		}
	}

	if(flag & OP_CHECK_67)
	{		
		if(flag & OP_ADRSIZE_PREFIX)
			flag |= OP_HAS_IMM2;
		else
			flag |= OP_HAS_IMM4;
	}

	if(flag & OP_HAS_MODRM)
	{
		DWORD modrm = *instPtr1++;
		DWORD mod = modrm >> 6;
		DWORD rm = modrm & 0x7;

		//printf("modrm = %X, mod = %d, rm = %d\n", modrm, mod, rm);
		if(flag & OP_ADRSIZE_PREFIX)
		{
			if(mod == 1)
				flag |= OP_HAS_DISP8;
			else if(mod == 2)
				flag |= OP_HAS_DISP16;
			else if(mod == 0 && rm == 6)
				flag |= OP_HAS_DISP16;
		}
		else
		{
			if(mod == 1)
				flag |= OP_HAS_DISP8;
			else if(mod == 2)
				flag |= OP_HAS_DISP32;
			else if(mod == 0 && rm == 5)
				flag |= OP_HAS_DISP32;
			if(mod < 3 && rm == 4)
			{
				DWORD sibBase = (*instPtr1++) & 0x7;
				if(mod == 0 && sibBase == 5)
					flag |= OP_HAS_DISP32;
			}
		}
	}

	if(flag & OP_HAS_IMM1)
		instPtr1++;
	if(flag & OP_HAS_IMM2)
		instPtr1 += 2;
	if(flag & OP_HAS_IMM4)
		instPtr1 += 4;
	if(flag & OP_HAS_DISP8)
		instPtr1++;
	if(flag & OP_HAS_DISP16)
		instPtr1 += 2;
	if(flag & OP_HAS_DISP32)
		instPtr1 += 4;

	return (DWORD)instPtr1 - (DWORD)opcodeStart;
}


unsigned char oneByteSafeOpSet[] = 
	"\x40\x48\xF8\xF9\xF5";

BOOL genReturnInst(unsigned char *buffer, int size, DWORD retAddr)
{
	unsigned char antiDisasmByte;

	if(size < 9 || size > 127)
		return FALSE;

	for(int i = 0; i < size; i++)
	{
		buffer[i] = oneByteSafeOpSet[rand() % (sizeof(oneByteSafeOpSet) - 1)];
	}

	if(size < 14)
	{
		buffer[0] = 0x68;			// PUSH Iv
		*((DWORD *)&buffer[1]) = retAddr;

		do
		{
			antiDisasmByte = rand() % 256;
		} 
		while(OneByteOpCode[antiDisasmByte] == 0 || OneByteOpCode[antiDisasmByte] & OP_HAS_MODRM ||
			  OneByteOpCode[antiDisasmByte] & OP_PREFIX);

		buffer[5] = 0xEB;						// JMP
		buffer[6] = (size - 2) - 6;				// Ib
		buffer[size-2] = antiDisasmByte;		// RET
		buffer[size-1] = 0xC3;					// RET
	}
	else
	{
		int pos = (rand() % (size - 11)) + 2;		// + 2 for 2 bytes of JMP short Jb

		do
		{
			antiDisasmByte = rand() % 256;
		} 
		while(OneByteOpCode[antiDisasmByte] == 0 || OneByteOpCode[antiDisasmByte] & OP_HAS_MODRM ||
			OneByteOpCode[antiDisasmByte] & OP_PREFIX);

		buffer[pos] = antiDisasmByte;							// for anti-disasm
	
		buffer[pos+1] = 0x68;									// PUSH Iv
		*((DWORD *)&buffer[pos+2]) = retAddr;

		int pos2 = (rand() % (pos - 1));						// position of JMP short Jb
		buffer[pos2] = 0xEB;
		buffer[pos2+1] = pos - pos2 - 1;


		int pos3 = pos + 6;		// anti-disasm byte + size of PUSH Iv
		int sizeLeft = size - pos3;
		//printf("Size Left = %d\n", sizeLeft);

		pos3 += (rand() % (sizeLeft - 3));
		buffer[pos3] = 0xEB;									// JMP short Jb

		int pos4 = pos3 + 2;
		sizeLeft = size - pos4;
		//printf("Size Left = %d\n", sizeLeft);
		pos4 += (rand() % (sizeLeft - 1));

		do
		{
			antiDisasmByte = rand() % 256;
		} 
		while(OneByteOpCode[antiDisasmByte] == 0 || OneByteOpCode[antiDisasmByte] & OP_HAS_MODRM ||
			OneByteOpCode[antiDisasmByte] & OP_PREFIX);

		buffer[pos3+1] = pos4 - pos3 - 1;
		buffer[pos4] = antiDisasmByte;
		buffer[pos4+1] = 0xC3;									// RET

		
	}
	return TRUE;
}



BOOL hasAntiDisasmJMP(unsigned char *codeStart, DWORD numBytes)
{
	DWORD len = 0;
	DWORD jmpToPos = -1;
	unsigned char *codePos = codeStart;
	BOOL result = TRUE;

	while(len < numBytes)
	{
		DWORD curLen = getInstLength(codePos);

		if(jmpToPos == -1)			// check only the first JMP
		{
			if(*codePos == 0xEB)
			{
				// short JMP Ib
				jmpToPos = (DWORD)(*(codePos + 1)) + len + 2;
				if(jmpToPos >= numBytes)
					jmpToPos = -1;		
			}
		}

		if(len == jmpToPos)		// normal jmp
		{			
			result = FALSE;
			break;
		}
		len += curLen;
		codePos += curLen;
	}

	if(jmpToPos == -1)
		result = FALSE;

	return result;
}
