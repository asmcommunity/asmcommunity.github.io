//*******************************************************************************************************
// AntiHookExec.cpp : Defines the entry point for the console application.
//
// Version 1.00
// Copyright (c) 2004 Chew Keong TAN
// All rights reserved.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, and/or sell copies of the Software, and to permit persons
// to whom the Software is furnished to do so, provided that the above
// copyright notice(s) and this permission notice appear in all copies of
// the Software and that both the above copyright notice(s) and this
// permission notice appear in supporting documentation.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT
// OF THIRD PARTY RIGHTS. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
// HOLDERS INCLUDED IN THIS NOTICE BE LIABLE FOR ANY CLAIM, OR ANY SPECIAL
// INDIRECT OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING
// FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT,
// NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION
// WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
//
// Usage:
// AntiHookExec <exe filename>
//
// This program will attempt to rid itself of userspace API hooks and execute <exe filename> 
//
// The following steps will be taken.
// 1) API Restoration.  
//    This program will attempt to detect any changes to the memory image of ntdll.dll by comparing
//    it against the disk image.  If there are any changes, the memory image will be patch by
//    referencing the disk image.
//
// 2) Import Table Restoration.
//    This program will attempt to restore the import tables in the memory image of kernel32.dll by
//	  comparing it against the disk image.
//
// 3) Obtain the memory address of CreateProcessA using the disk image of kernel32.dll, and use 
//    this address to execute <exe filename>
//
//*******************************************************************************************************

#include <stdio.h>
#include <windows.h>
#include "InstLenDisasm.h"

#define KERNEL32	"\\kernel32.dll"
#define NTDLL		"\\ntdll.dll"


typedef DWORD (WINAPI *ORIGVirtualQuery)(
    LPCVOID lpAddress,
    PMEMORY_BASIC_INFORMATION lpBuffer,
    DWORD dwLength);

ORIGVirtualQuery gVirtualQuery;


typedef BOOL (WINAPI *ORIGVirtualProtect)(
    LPVOID lpAddress,
    DWORD dwSize,
    DWORD flNewProtect,
    PDWORD lpflOldProtect);

ORIGVirtualProtect gVirtualProtect;


#define IMAGE_SCN_CNT_CODE			0x00000020
#define IMAGE_SCN_MEM_EXECUTE		0x20000000


struct PE_Header 
{
	unsigned long signature;
	unsigned short machine;
	unsigned short numSections;
	unsigned long timeDateStamp;
	unsigned long pointerToSymbolTable;
	unsigned long numOfSymbols;
	unsigned short sizeOfOptionHeader;
	unsigned short characteristics;
};

struct PE_ExtHeader
{
	unsigned short magic;
	unsigned char majorLinkerVersion;
	unsigned char minorLinkerVersion;
	unsigned long sizeOfCode;
	unsigned long sizeOfInitializedData;
	unsigned long sizeOfUninitializedData;
	unsigned long addressOfEntryPoint;
	unsigned long baseOfCode;
	unsigned long baseOfData;
	unsigned long imageBase;
	unsigned long sectionAlignment;
	unsigned long fileAlignment;
	unsigned short majorOSVersion;
	unsigned short minorOSVersion;
	unsigned short majorImageVersion;
	unsigned short minorImageVersion;
	unsigned short majorSubsystemVersion;
	unsigned short minorSubsystemVersion;
	unsigned long reserved1;
	unsigned long sizeOfImage;
	unsigned long sizeOfHeaders;
	unsigned long checksum;
	unsigned short subsystem;
	unsigned short DLLCharacteristics;
	unsigned long sizeOfStackReserve;
	unsigned long sizeOfStackCommit;
	unsigned long sizeOfHeapReserve;
	unsigned long sizeOfHeapCommit;
	unsigned long loaderFlags;
	unsigned long numberOfRVAAndSizes;
	unsigned long exportTableAddress;
	unsigned long exportTableSize;
	unsigned long importTableAddress;
	unsigned long importTableSize;
	unsigned long resourceTableAddress;
	unsigned long resourceTableSize;
	unsigned long exceptionTableAddress;
	unsigned long exceptionTableSize;
	unsigned long certFilePointer;
	unsigned long certTableSize;
	unsigned long relocationTableAddress;
	unsigned long relocationTableSize;
	unsigned long debugDataAddress;
	unsigned long debugDataSize;
	unsigned long archDataAddress;
	unsigned long archDataSize;
	unsigned long globalPtrAddress;
	unsigned long globalPtrSize;
	unsigned long TLSTableAddress;
	unsigned long TLSTableSize;
	unsigned long loadConfigTableAddress;
	unsigned long loadConfigTableSize;
	unsigned long boundImportTableAddress;
	unsigned long boundImportTableSize;
	unsigned long importAddressTableAddress;
	unsigned long importAddressTableSize;
	unsigned long delayImportDescAddress;
	unsigned long delayImportDescSize;
	unsigned long COMHeaderAddress;
	unsigned long COMHeaderSize;
	unsigned long reserved2;
	unsigned long reserved3;
};


struct SectionHeader
{
	unsigned char sectionName[8];
	unsigned long virtualSize;
	unsigned long virtualAddress;
	unsigned long sizeOfRawData;
	unsigned long pointerToRawData;
	unsigned long pointerToRelocations;
	unsigned long pointerToLineNumbers;
	unsigned short numberOfRelocations;
	unsigned short numberOfLineNumbers;
	unsigned long characteristics;
};

struct MZHeader
{
	unsigned short signature;
	unsigned short partPag;
	unsigned short pageCnt;
	unsigned short reloCnt;
	unsigned short hdrSize;
	unsigned short minMem;
	unsigned short maxMem;
	unsigned short reloSS;
	unsigned short exeSP;
	unsigned short chksum;
	unsigned short exeIP;
	unsigned short reloCS;
	unsigned short tablOff;
	unsigned short overlay;
	unsigned char reserved[32];
	unsigned long offsetToPE;
};


struct ImportDirEntry
{
	DWORD importLookupTable;
	DWORD timeDateStamp;
	DWORD fowarderChain;
	DWORD nameRVA;
	DWORD importAddressTable;
};

DWORD myStrlenA(char *ptr)
{
	DWORD len = 0;
	while(*ptr)
	{
		len++;
		ptr++;
	}

	return len;
}


BOOL myStrcmpA(char *str1, char *str2)
{
	while(*str1 && *str2)
	{
		if(*str1 == *str2)
		{
			str1++;
			str2++;
		}
		else
		{
			return FALSE;
		}
	}

	if(*str1 && !*str2)
	{
		return FALSE;
	}
	else if(*str2 && !*str1)
	{
		return FALSE;
	}

	return TRUE;	
}


//*******************************************************************************************************
// Fills the various structures with info of a PE image.  The PE image is located at modulePos.
//
//*******************************************************************************************************

bool readPEInfo(char *modulePos, MZHeader *outMZ, PE_Header *outPE, PE_ExtHeader *outpeXH,
				SectionHeader **outSecHdr)
{
	// read MZ Header
	MZHeader *mzH;
	mzH = (MZHeader *)modulePos;

	if(mzH->signature != 0x5a4d)		// MZ
	{
		printf("File does not have MZ header\n");
		return false;
	}

	// read PE Header
	PE_Header *peH;
	peH = (PE_Header *)(modulePos + mzH->offsetToPE);

	if(peH->sizeOfOptionHeader != sizeof(PE_ExtHeader))
	{
		printf("Unexpected option header size.\n");
		
		return false;
	}

	// read PE Ext Header
	PE_ExtHeader *peXH;
	peXH = (PE_ExtHeader *)((char *)peH + sizeof(PE_Header));

	// read the sections
	SectionHeader *secHdr = (SectionHeader *)((char *)peXH + sizeof(PE_ExtHeader));

	*outMZ = *mzH;
	*outPE = *peH;
	*outpeXH = *peXH;
	*outSecHdr = secHdr;

	return true;
}


typedef struct _LDR_MODULE
{	
	LIST_ENTRY InInitOrderList;
	PVOID BaseAddress; 
	PVOID EntryPoint; 
	ULONG SizeOfImage; 
	LPWSTR FullDllName; 
	LPWSTR BaseDllName; 
	ULONG Flags; 
	SHORT LoadCount; 
	SHORT TlsIndex; 
	LIST_ENTRY HashTableEntry; 
	ULONG TimeDateStamp;
} LDR_MODULE;


void getKern32AndNtdllAddr(DWORD *outKernel32Addr, DWORD *outNtdllAddr)
{	
	LDR_MODULE *headLdr;

	__asm
	{
		mov		eax, fs:[30h];			// get pointer to PEB from offset 30h into TEB
		mov		eax, [eax+0ch];			// retrive value from offset 0ch into PEB
		
		mov		esi, [eax+1ch];			// get the head pointer to InInitializationOrderModuleList		

		mov		headLdr, esi;						
	}

	*outNtdllAddr = (DWORD)(headLdr->BaseAddress);

	headLdr = (LDR_MODULE *)headLdr->InInitOrderList.Flink;
	*outKernel32Addr = (DWORD)(headLdr->BaseAddress);
}


// implement our own in case it's hooked
BOOL isDifferent(unsigned char *ptr1,  unsigned char *ptr2, DWORD len)
{
	for(DWORD i = 0; i < len; i++)
	{	
		if(*ptr1++ != *ptr2++)
			return TRUE;
	}
	return FALSE;
}


#define x86_OP_RETN_Iw		0xC2
#define x86_OP_RETN			0xC3
#define x86_OP_RETF_Iw		0xCA
#define x86_OP_RETF			0xCB
#define x86_OP_IRET			0xCF


DWORD getFuncLen(DWORD funcStart)
{
	DWORD len = 0;
	unsigned char *ptr = (unsigned char *)funcStart;

	while(*ptr != x86_OP_RETN_Iw &&
		  *ptr != x86_OP_RETN &&
		  *ptr != x86_OP_RETF_Iw &&
		  *ptr != x86_OP_RETF &&
		  *ptr != x86_OP_IRET)
	{
		DWORD curLen = getInstLength(ptr);
		len += curLen;
		ptr += curLen;
	}

	return len;
}



DWORD restoreAPICode(DWORD fileDLLAddr, DWORD liveDLLAddr)
{	
	if(!fileDLLAddr || !liveDLLAddr)
		return 0;

	char *ptr = (char *)fileDLLAddr;
	ptr += 0x3c;		// offset 0x3c contains offset to PE header
	
	ptr = (char *)(*(DWORD *)ptr) + fileDLLAddr + 0x78;		// offset 78h into PE header contains addr of export table

	ptr = (char *)(*(DWORD *)ptr) + fileDLLAddr;			// ptr now points to export directory table

	// offset 24 into the export directory table == number of entries in the Name Pointer Table
	// table
	DWORD numEntries = *(DWORD *)(ptr + 24);
	//printf("NumEntries = %d\n", numEntries);
	
	DWORD *ExportNamePointerTable = (DWORD *)(*(DWORD *)(ptr + 32) + fileDLLAddr);  // offset 32 into export directory contains offset to Export Name Pointer Table	

	DWORD ordinalBase = *((DWORD *)(ptr + 16));

	WORD *ExportOrdinalTable = (WORD *)((*(DWORD *)(ptr + 36)) + fileDLLAddr);	// offset 36 into export directory contains offset to Ordinal Table
	DWORD *ExportAddrTable = (DWORD *)((*(DWORD *)(ptr + 28)) + fileDLLAddr); // offset 28 into export directory contains offset to Export Addr Table


	MZHeader mzH;
	PE_Header peH;
	PE_ExtHeader peXH;
	SectionHeader *secHdr;

	readPEInfo((char *)fileDLLAddr, &mzH, &peH, &peXH, &secHdr);
	//printf("OrdinalTable At = %X\n", (WORD *)((*(DWORD *)(ptr + 36)) + liveDLLAddr));

	for(DWORD i = 0; i < numEntries; i++)
	{
		// first check whether this is a export lies in the code section
		char *exportName = (char *)(ExportNamePointerTable[i] + fileDLLAddr);
		WORD ordinal = ExportOrdinalTable[i];

		BOOL isExecExport = FALSE;
		DWORD thisExportAddr = ExportAddrTable[ordinal];
		
		for(DWORD j = 0; j < peH.numSections; j++)
		{
			if((secHdr[j].characteristics & IMAGE_SCN_MEM_EXECUTE) &&
			   (secHdr[j].characteristics & IMAGE_SCN_CNT_CODE) )
			{
				if(thisExportAddr >= secHdr[j].virtualAddress && 
				   thisExportAddr < secHdr[j].virtualAddress + secHdr[j].virtualSize)
				{
					isExecExport = TRUE;
					break;
				}
			}
		}

		if(isExecExport)
		{
			unsigned char *filePtr = (unsigned char *)(fileDLLAddr + thisExportAddr);
			unsigned char *livePtr = (unsigned char *)(liveDLLAddr + thisExportAddr);
			DWORD funcLen = getFuncLen((DWORD)filePtr);

			//printf("thisExportAddr = %X, ordinal = %d, %d\n", thisExportAddr, ordinal, funcLen);

			if(isDifferent(filePtr, livePtr, funcLen))
			{
				printf("Restored %s (Ordinal %u) (at %X)\n", exportName, ordinal + ordinalBase, livePtr);

				DWORD k = funcLen;
				DWORD t;

				while(filePtr[k] == livePtr[k])
					k--;
		
				for(t = 0; t <= k; t++)
				{
					printf("%.2X ", livePtr[t]);
				}
				printf("\n");
				for(t = 0; t <= k; t++)
				{
					printf("%.2X ", filePtr[t]);
				}
				
				MEMORY_BASIC_INFORMATION memInfo;
				DWORD oldProtect;
				
				gVirtualQuery(livePtr, &memInfo, sizeof(memInfo));

				gVirtualProtect(memInfo.BaseAddress, memInfo.RegionSize, PAGE_EXECUTE_READWRITE,
								&oldProtect);
				
				for(t = 0; t <= k; t++)
				{
					livePtr[t] = filePtr[t];
				}
							
				gVirtualProtect(memInfo.BaseAddress, memInfo.RegionSize, memInfo.Protect,
								&oldProtect);

				printf("\n\n");
			}
		}
	}

	return 1;
}


//*******************************************************************************************************
// Returns the total size required to load a PE image into memory
//
//*******************************************************************************************************

int calcTotalImageSize(MZHeader *inMZ, PE_Header *inPE, PE_ExtHeader *inpeXH,
				       SectionHeader *inSecHdr)
{
	int result = 0;
	int alignment = inpeXH->sectionAlignment;

	if(inpeXH->sizeOfHeaders % alignment == 0)
		result += inpeXH->sizeOfHeaders;
	else
	{
		int val = inpeXH->sizeOfHeaders / alignment;
		val++;
		result += (val * alignment);
	}
	for(int i = 0; i < inPE->numSections; i++)
	{
		if(inSecHdr[i].virtualSize)
		{
			if(inSecHdr[i].virtualSize % alignment == 0)
				result += inSecHdr[i].virtualSize;
			else
			{
				int val = inSecHdr[i].virtualSize / alignment;
				val++;
				result += (val * alignment);
			}
		}
	}

	return result;
}


//*******************************************************************************************************
// Returns the aligned size of a section
//
//*******************************************************************************************************

unsigned long getAlignedSize(unsigned long curSize, unsigned long alignment)
{	
	if(curSize % alignment == 0)
		return curSize;
	else
	{
		int val = curSize / alignment;
		val++;
		return (val * alignment);
	}
}

//*******************************************************************************************************
// Copy a PE image from exePtr to ptrLoc with proper memory alignment of all sections
//
//*******************************************************************************************************

bool loadPE(char *exePtr, MZHeader *inMZ, PE_Header *inPE, PE_ExtHeader *inpeXH,
			SectionHeader *inSecHdr, LPVOID ptrLoc)
{
	char *outPtr = (char *)ptrLoc;
	
	memcpy(outPtr, exePtr, inpeXH->sizeOfHeaders);
	outPtr += getAlignedSize(inpeXH->sizeOfHeaders, inpeXH->sectionAlignment);

	for(int i = 0; i < inPE->numSections; i++)
	{
		if(inSecHdr[i].sizeOfRawData > 0)
		{
			unsigned long toRead = inSecHdr[i].sizeOfRawData;
			if(toRead > inSecHdr[i].virtualSize)
				toRead = inSecHdr[i].virtualSize;

			memcpy(outPtr, exePtr + inSecHdr[i].pointerToRawData, toRead);

			outPtr += getAlignedSize(inSecHdr[i].virtualSize, inpeXH->sectionAlignment);
		}
	}

	return true;
}


BOOL isStrDifferenti(char *str1, char *str2)
{
	while(*str1 && *str2)
	{
		if(*str1 == *str2)
		{
			str1++;
			str2++;
		}
		else
		{
			if(*str1 >= 'a' && *str1 <= 'z')
			{
				if(*str1 - 32 == *str2)
				{
					str1++; str2++; continue;
				}
			}
			else if(*str2 >= 'a' && *str2 <= 'z')
			{
				if(*str2 - 32 == *str1)
				{
					str1++; str2++; continue;
				}		
			}
			return TRUE;
		}
	}

	if(*str1 && !*str2)
	{
		return TRUE;
	}
	else if(*str2 && !*str1)
	{
		return TRUE;
	}

	return FALSE;
}


DWORD procAPIExportAddr(DWORD hModule, char *apiName)
{	
	if(!hModule || !apiName)
		return 0;

	char *ptr = (char *)hModule;
	ptr += 0x3c;		// offset 0x3c contains offset to PE header
	
	ptr = (char *)(*(DWORD *)ptr) + hModule + 0x78;		// offset 78h into PE header contains addr of export table

	ptr = (char *)(*(DWORD *)ptr) + hModule;			// ptr now points to export directory table

	// offset 24 into the export directory table == number of entries in the Export Name Pointer Table
	// table
	DWORD numEntries = *(DWORD *)(ptr + 24);
	//printf("NumEntries = %d\n", numEntries);

	DWORD *ExportNamePointerTable = (DWORD *)(*(DWORD *)(ptr + 32) + hModule);  // offset 32 into export directory contains offset to Export Name Pointer Table	
	
	DWORD ordinalBase = *((DWORD *)(ptr + 16));
	//printf("OrdinalBase is %d\n", ordinalBase);


	WORD *ExportOrdinalTable = (WORD *)((*(DWORD *)(ptr + 36)) + hModule);	// offset 36 into export directory contains offset to Ordinal Table
	DWORD *ExportAddrTable = (DWORD *)((*(DWORD *)(ptr + 28)) + hModule); // offset 28 into export directory contains offset to Export Addr Table

	for(DWORD i = 0; i < numEntries; i++)
	{		
		char *exportName = (char *)(ExportNamePointerTable[i] + hModule);

		if(myStrcmpA(exportName, apiName) == TRUE)
		{			
			WORD ordinal = ExportOrdinalTable[i];
			//printf("%s (i = %d) Ordinal = %d at %X\n", exportName, i, ordinal, ExportAddrTable[ordinal]);

			return (DWORD)(&ExportAddrTable[ordinal]);
		}
	}

	return 0;
}


DWORD myGetProcAddress(DWORD fileDLLAddr, DWORD liveDLLAddr, char *apiName)
{
	DWORD ptr = procAPIExportAddr(fileDLLAddr, apiName);
	if(ptr)
	{		
		return *((DWORD *)ptr) + liveDLLAddr;		
	}
	return 0;
}

//*******************************************************************************************************
// Restores the import table of kernel32.dll
//
//*******************************************************************************************************

BOOL restoreKenerl32Imports(DWORD fileDLLPtr, DWORD liveDLLPtr, DWORD fileNtdllPtr, DWORD liveNtdllPtr)
{	
	MZHeader mzHdr;
	PE_Header peHdr;
	PE_ExtHeader peXHdr;
	SectionHeader *secHdr;

	MZHeader mzH2;
	PE_Header peH2;
	PE_ExtHeader peXH2;
	SectionHeader *secHdr2;

	BOOL result = FALSE;
	ImportDirEntry *ide;
	ImportDirEntry *ide2;

	// read PE entry of this EXE
	if(!readPEInfo((char *)fileDLLPtr, &mzHdr, &peHdr, &peXHdr, &secHdr))
	{
		goto done;
	}
	if(!readPEInfo((char *)liveDLLPtr, &mzH2, &peH2, &peXH2, &secHdr2))
	{
		goto done;
	}

	ide = (ImportDirEntry *)((char *)peXHdr.importTableAddress + fileDLLPtr);
	ide2 = (ImportDirEntry *)((char *)peXH2.importTableAddress + liveDLLPtr);

	while(ide && ide->importAddressTable)
	{		
		char *impDllName = ((char *)ide->nameRVA + (DWORD)fileDLLPtr);
		
		if(!isStrDifferenti((char *)impDllName, (char *)"ntdll.dll"))		// ntdll.dll
		{
			result = TRUE;
			unsigned long *importEntry = (unsigned long *)((DWORD)fileDLLPtr + ide->importAddressTable);
			unsigned long *importEntry2 = (unsigned long *)((DWORD)liveDLLPtr + ide2->importAddressTable);

			unsigned long *importLookupEntry = (unsigned long *)((DWORD)fileDLLPtr + ide->importLookupTable);
		
			DWORD i = 0;
			while(importLookupEntry[i])
			{
				if(!(importLookupEntry[i] & 0x80000000))
				{
					char *apiName = (char *)((DWORD)fileDLLPtr + importLookupEntry[i] + 2); 
					//printf("%s\n", apiName);
					
					// calc export addresses of ntdll APIs from file image
					DWORD *apiExportAddrLoc = (DWORD *)procAPIExportAddr(fileNtdllPtr, apiName);
					DWORD apiExportAddr = *apiExportAddrLoc + liveNtdllPtr;
					
					//printf("%X\n", *apiExportAddrLoc);
					//printf("%X, %X, %X\n", apiExportAddr, importEntry2[i], GetProcAddress(GetModuleHandle("ntdll.dll"), apiName));

					if(apiExportAddr != importEntry2[i])
					{
						printf("%s (Entry at %X) restored to %X\n", apiName, importEntry2[i], apiExportAddr);
						
						MEMORY_BASIC_INFORMATION memInfo;
						DWORD oldProtect;

						gVirtualQuery(&importEntry2[i], &memInfo, sizeof(memInfo));
				
						gVirtualProtect(memInfo.BaseAddress, memInfo.RegionSize, PAGE_EXECUTE_READWRITE,
										&oldProtect);							

						importEntry2[i] = apiExportAddr;

						gVirtualProtect(memInfo.BaseAddress, memInfo.RegionSize, memInfo.Protect,
										&oldProtect);
					}
				}
				i++;
			}
		}
		ide++;
		ide2++;

	}

done:	
	return result;
}


//*******************************************************************************************************
// Loads the DLL into memory and align it
//
//*******************************************************************************************************

LPVOID loadDLL(char *dllName)
{
	char moduleFilename[MAX_PATH + 1];
	LPVOID ptrLoc = NULL;
	MZHeader mzH2;
	PE_Header peH2;
	PE_ExtHeader peXH2;
	SectionHeader *secHdr2;

	GetSystemDirectory(moduleFilename, MAX_PATH);
	if((myStrlenA(moduleFilename) + myStrlenA(dllName)) >= MAX_PATH)
		return NULL;

	strcat(moduleFilename, dllName);

	// load this EXE into memory because we need its original Import Hint Table

	HANDLE fp;
	fp = CreateFile(moduleFilename, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL);
	
	if(fp != INVALID_HANDLE_VALUE)
	{
		BY_HANDLE_FILE_INFORMATION fileInfo;
		GetFileInformationByHandle(fp, &fileInfo);

		DWORD fileSize = fileInfo.nFileSizeLow;
		//printf("Size = %d\n", fileSize);
		if(fileSize)
		{
			LPVOID exePtr = HeapAlloc(GetProcessHeap(), 0, fileSize);
			if(exePtr)
			{
				DWORD read;

				if(ReadFile(fp, exePtr, fileSize, &read, NULL) && read == fileSize)
				{					
					if(readPEInfo((char *)exePtr, &mzH2, &peH2, &peXH2, &secHdr2))
					{
						int imageSize = calcTotalImageSize(&mzH2, &peH2, &peXH2, secHdr2);
						//printf("Image Size = %X\n", imageSize);

						//ptrLoc = VirtualAlloc(NULL, imageSize, MEM_COMMIT, PAGE_EXECUTE_READWRITE);
						ptrLoc = HeapAlloc(GetProcessHeap(), 0, imageSize);
						if(ptrLoc)
						{
							//printf("Memory allocated at %X\n", ptrLoc);
							loadPE((char *)exePtr, &mzH2, &peH2, &peXH2, secHdr2, ptrLoc);
						}
						else
						{
							//printf("Local Memory allocation error.\n");
						}				
					}

				}
				HeapFree(GetProcessHeap(), 0, exePtr);
			}
		}
		CloseHandle(fp);
	}

	return ptrLoc;
}


typedef BOOL (WINAPI *ORIGCreateProcess)(
  LPCTSTR lpApplicationName,
  LPTSTR lpCommandLine,
  LPSECURITY_ATTRIBUTES lpProcessAttributes,
  LPSECURITY_ATTRIBUTES lpThreadAttributes,
  BOOL bInheritHandles,
  DWORD dwCreationFlags,
  LPVOID lpEnvironment,
  LPCTSTR lpCurrentDirectory,
  LPSTARTUPINFO lpStartupInfo,
  LPPROCESS_INFORMATION lpProcessInformation);


int main(int argc, char* argv[])
{
	DWORD kern32Addr, ntdllAddr;
	getKern32AndNtdllAddr(&kern32Addr, &ntdllAddr);

	if(argc != 2)
	{
		printf("\nUsage: %s <cmd.exe>\n", argv[0]);
		return 1;
	}

	printf("Ntdll.DLL at %X\n", ntdllAddr);
	printf("Kernel32.DLL at %X\n\n", kern32Addr);
	
	
	LPVOID fileNtdll = loadDLL(NTDLL);
	LPVOID fileKernel32 = loadDLL(KERNEL32);

	if(fileNtdll && fileKernel32)
	{
		gVirtualQuery = 
			(ORIGVirtualQuery)myGetProcAddress((DWORD)fileKernel32, kern32Addr, "VirtualQuery");

		gVirtualProtect = 
			(ORIGVirtualProtect)myGetProcAddress((DWORD)fileKernel32, kern32Addr, "VirtualProtect");
				
		if(!restoreKenerl32Imports((DWORD)fileKernel32, kern32Addr, (DWORD)fileNtdll, ntdllAddr))
		{
			printf("Checking of kernel32.dll's import from ntdll.dll failed.\n");
			goto done;
		}
		
		restoreAPICode((DWORD)fileNtdll, ntdllAddr);
		restoreAPICode((DWORD)fileKernel32, kern32Addr);

		STARTUPINFO sinfo;
		PROCESS_INFORMATION pinfo;

		memset(&sinfo, 0, sizeof(sinfo));
		memset(&pinfo, 0, sizeof(pinfo));

		sinfo.cb = sizeof(sinfo);
		
		ORIGCreateProcess ourCreateProcess = 
			(ORIGCreateProcess)myGetProcAddress((DWORD)fileKernel32, kern32Addr, "CreateProcessA");
		
		if(ourCreateProcess)
		{
			int result = ourCreateProcess(NULL, argv[1], NULL, NULL, TRUE, CREATE_NEW_CONSOLE, NULL, NULL, &sinfo, &pinfo); 
			if(!result)
				printf("Cannot CreateProcess (%s).\n", argv[1]);
		}
		else
			printf("CreateProcess Failed.\n");
	}
	else
	{
		printf("Loading of original DLLs failed\n");
	}

done:
	if(fileNtdll)
		//VirtualFree(fileNtdll, 0, MEM_RELEASE);
		HeapFree(GetProcessHeap(), 0, fileNtdll);
	if(fileKernel32)
		//VirtualFree(fileKernel32, 0, MEM_RELEASE);
		HeapFree(GetProcessHeap(), 0, fileKernel32);

	return 0;
}

