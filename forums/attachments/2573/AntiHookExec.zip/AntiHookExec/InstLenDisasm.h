

DWORD getInstLength(unsigned char *opcodeStart);
BOOL genReturnInst(unsigned char *buffer, int size, DWORD retAddr);
BOOL hasAntiDisasmJMP(unsigned char *codeStart, DWORD numBytes);