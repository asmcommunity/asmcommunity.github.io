Im not responsible on any damage.
You are allowed to do anything you wish with this code.