
PlayCD
------

Using information gleaned using TestMCI and the SDK I have now produced a functional
CD player. It is again in the form of a dialog and when loaded you are presented with
 Track, Minute and Second displays at the top. Underneath this
is the standard layout for a CD player, with Play, Pause, Stop, Next, Previous.

Then in a group box there is a cluster of radio buttons which allow the selection
of any valid track up to 30. This should be more than adequate for all CD's but with
the posible release of audio DVD's I allow some latitude. Track buttons exceeding the
actual number of tracks present are dimmed out.

On the right hand side you will find a drive selection box which permits you to select from
any of the detected CD drives. 
 
A check box allows the sound to be turned on/off


Note: 
It is advisable to turn off Autoplay for audio CD's, otherwise your CD
will start playing from Track 1 and this may not be what you want. Also make sure
that the CD volume is at a suitable setting.   

*** For more information on MCI command usage refer to the Microsoft /Platform SDK/Graphics
and Multimedia Services/Multimedia Reference/Multimedia Commmand Strings ***
   
Files include:-

PlayCD.exe	The CD utilty
PlayCD.asm	Source
PlayCD.hlp	Help
PlayCD.rtf	Rich text font help data
PlayCD.hpj	Help project file
PlayCD.rc	Resource file
Atodw.obj	ASCII to DWORD		; From MASM32 - (source is MASM32/Lib) 
DwtoA.obj	Dword to ASCII
macros.txt
Makefile

Ron Thomas.

Ron_Thom@Compuserve.com

www.rbthomas.freeserve.co.uk

24/7/00

 
             

