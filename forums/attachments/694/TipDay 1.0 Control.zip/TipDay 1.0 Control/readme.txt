TipDay 1.0
----------
This DLL exports a function named 'ShowTipDay', that lets you display a 'Tip Of The Day'-window. Useful
for developerz and fun-coderz alike. Enjoy!!! Inspired by 'mottos' by budyn. All source and a demo is 
included.

For comments and suggestions mail me at profdracula@f-m.fm

-Prof. DrAcULA
