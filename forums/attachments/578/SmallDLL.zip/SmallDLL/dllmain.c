#define WIN32_LEAN_AND_MEAN  
#include <windows.h>

BOOL APIENTRY DllMain(HINSTANCE hInstDLL, DWORD fdwReason, LPVOID lpvReserved)
{
       return TRUE;
}

void WINAPI Autotype(char* message)
{

    HWND hWnd=FindWindowEx(FindWindow("Notepad",0),0,"Edit",0);
	while (*message)
			{
				SendMessage(hWnd,WM_CHAR,(WPARAM)*message,0);
				Sleep(200);
				++message;
			}
}
