Yodel benchmark test suite stuffy thingamajig, see src\yodel.cpp for
version. I'm f0dder, <f0dder@druk.nu>, irc:efnet.

yodel 0.5:
  - finally flags are tweakable, thanks a lot jibz.
  - DLL timing code now has same overhead almost as other routines
    (no more "first call" penalty, has an extra indirection though).
    Will be fixed thoroughly later.
  - stuff?

---------------------

yodel 0.4:
  - start modularizing, main module compiles (doesn't link) under
    linux now. Yay :).
  - hooks are there for changing a lot of the runtime parameters,
    just no way to let the user input them yet.
  - most timing functions are commented out in the binary, only
    C version (conformance), MMX (to see good speed) and DLL (to
    do your own tests) are compiled in.
  - asm routines have been bugfixed. Array indices were wrong.
    timings will be slightly different, but it should be a constant
    (not scaling) addition to all routines, so not very important.
  - DLL support. timedll.dll, export "func". stdcall, takes array
    as argument. This will be improved with time, but allows you
    to plug in your own test routines.

The reason for releasing in this form is to allow people to tinker,
and for myself to download and tinker with this when I get to work :).

The zip password? Yeah, I passworded it because people didn't read
this text. You ought to read through everything below this point,
even if some of it may be outdated. If you just go to the bottom
and grab the password, it's at your own risk.

There might be more, but I need my beauty sleep.

--- text below this point was for yodel 0.3, quite some stuff has
--- changed, and for this silly release, I'll let you be the one
--- to figure out what :-)


This is test stuff. Very testy test stuff. Might not be a decent
way to do benchmarks, I don't claim to be a guru. Gives me numbers
that look nice and shiny, though. The tests done by this build is
to multiply an array of 2048 u16's (unsigned shorts, WORDs, call
it what you want) by the constant value of 92.

Stuff you ought to know (PLEASE do read this, otherwise you're not
entitled to bitch in any way :-)). You will probably also want to
read results.txt from the doc folder.

Three binaries are include:
yodel_sse2      - the preferred version, if you have SSE2 access.
yodel_plain     - if you don't have SSE2 (requires PMMX/better)
yodel_plain_ntc - recommended when you're testing DLLs for the
                  first time. Not timecritical, so you can break
		  if the DLL is buggy. Final DLL timings should of
		  course be done with timecritical sse2 or plain.

Oh, you should run this from a command prompt, so you have a chance
to capture output. Yes, the window will close when the app is done.

You will need at least a pentium with MMX to run this. RDTSC is
100% necessary if running on 9x. Furthermore, tests are flagged
as "plain" or "not plain" - however, the definition of plain is
"anything above pmmx". This is to make it easy to build a non-sse2
version of AMD owners. I doubt you'd want to run this thing on
anything less than a Pentium2 anyway, it would take quite a while.

CPU MHz is taken from the registry on NT systems, and calculated
on 9x systems. If you feel the value is calculated incorrectly,
you can do a hacky workaround on 9x: create this registry DWORD value:
"HARDWARE\DESCRIPTION\System\CentralProcessor\0\~Mhz", and set it
to your processor frequency in MHz. For athlon XP/whatever systems,
be sure to set this to your ACTUAL frequency, not the PR value.
Setting it to the PR value will make the clk/op seem worse than
it is, so it would actually make intel machines seem better if you
use the PR value. If you post timings anywhere, you ought to quote
your CPU type, the value yodel reports, and perhaps also ram size+type+speed.
Rumor has it that chipset also can have something to say for otherwise
identially specced machines (like P4 2.4ghz w/512meg DDR333 ram,
where the only difference would be an intel vs. a SiS chipset).
So report motherboard/chipset too, if you're nazi. Windows version
and service pack can also differ. Harddrive size and stuff like that
shouldn't matter, so leave it out to avoid flooding with info. When
using TIMECRITICAL timing, number of running processes shouldn't matter
too much, but you might want to include a general idea of your system
("clean/stripped" or "normal stuff" or "doing fractal compression" ;-)).

Two versions are included: one that only uses "plain" instruction
set (plain == pentium+mmx), one that runs "whatever" (in particular,
SSE2). Both use TIMECRITICAL thread priority, so beware, especially
on slower boxes. Yes, TIMECRITICAL will make your box seem just about
frozen until the timings are done, and you can't interrupt it. Don't
say you weren't warned.

If you want to test a piece of your own code, the easiest is probably
to make a "timedll.dll", with a single "func" export. This must be a
STDCALL function taken a point to an array of 2048 unsigned short ints,
returning 0 if something bad happens, 1 otherwise. In other words,
bool __stdcall func(unsigned short *parm); // use .def to export w/o name mangling
All included test routines are defined like that.
For MMX code, EMMS has to be issued before you return.

Future improvements to this test suite might be ability to specify a
whole bunch of things on the commandline, like iterations, whether to
use timecritical code, whether to do conformance tests or not, and
perhaps only running a single test, or a subset of the tests. The code
already has facility to handle a lot of this, just no user way of
setting the flags.

Conformance tests are currently nonexistant - this WILL be fixed.
Current included routines might or might not do the job they're intended
to, I honestly haven't tested them. But at least it seems like they
don't under/overflow the memory buffer, though. (Might be that some
of them only works on a range of it - again, not tested).

The DLL proc currently has a little overhead compared to the "normal"
tests. The function is called indirectly, and the first time it's
called it will LoadLibrary+GetProcAddres (but ONLY the first time,
subsequent calls will go directly (albeit via a function pointer)
to the DLL code). I'm considering extending the benchmark suite to
allow init/deinit/run (where init/deinit can be NULL of not needed)
functions, that will of course be run before the tests takes place.
This would also allow ie SSE2 code to check for SSE2 presence, and
flag themselves as unavailable as needed.

Memory allocation for the array is done with VirtualAlloc. Why?
Well, you get "quite decent alignment" (64k) that way - means I
don't have to fiddle with extra allocation and manual alignment
to be able to use SSE2 aligned instructions (which are quite
faster than unaligned). Also, there's good chances the memory
regions before and after the allocated memory block will not
be committed, making it _very_ easy to track over/underruns
(this could even be forced by reserving three pages, and only
committing the middle). I don't recommend VirtualAlloc for generic
allocs, but that's a whole other discussion. The memory is memset()
to zero before calling the routine loopings, so it should be cached.

The C++ code is compiled with the intel C++ compiler, version 7.0
(not 7.1 as I had previously stated in this document - sorry. Dunno
if 7.1 would make much of a difference, should only affect time1
anyway). The instruction set is limited to PMMX, but the compiler is
set to optimize for Pentium3 timings. Pentium3 instead of Pentium4,
as this actually produced better values for time1() on my P4 2.53ghz :-).

I'm not 100% sure the clk/op calculations are correct, but the
results seem sort of reasonable. I like the SSE2 results :-).
Look at "results.txt" for some yadda yadda about it, or of course
yodel.cpp.

If this benchmark is to be used for anything, imho it should be
finding optimal code for Pentium4 and Athlon (ie, two versions),
and a generic routine that runs well on anything >= pmmx, without
having unreasonable slowdowns on any models - this also means
sacrificing something that runs "pretty well" on p3,athlon if it
runs poorly on P4.

Note that "sub reg32, 1" is generally used instead of "dec reg32".
This is somewhat better on P4's. Also, prefer "movzx" to
"xor reg32,reg32 + mov reg16, [mem]" - for all modern processors.

Seems like it's possible to get better clk/op on the P4 than on athlon
systems, but of course the current tests are rather limited... no athlon-specific
timed code has been written, most routines haven't been unrolled, etc.
Seem like the MMX version is quite the best generic, performs rather well
on all platforms. This is not to be seen as a "P4 is better than athlon"
statement, more routines have to be written, and while it might be possible
to get better performance out of a P4 than an athlon, atlons _do_ seem
to run generic code (athlon/pentium-lessthan4 optimized code) better than P4.
Obviously theres a LOT of room for improvements, most of the assembly
routines are very naive. The SSE2 version is just a hacked MMX version,
and the MMX version is incredibly naive.

Why the name yodel? Dunno. Often when I write small test pieces I
use weird names - this evolved from a small test piece to somewhat
slightly larger, and I think the name is cute so I kept it.

zip pass: ganskesjovt
