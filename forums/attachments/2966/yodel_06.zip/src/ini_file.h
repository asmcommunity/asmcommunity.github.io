//
// Class giving access to .ini files
//
// Copyright (c) 2000-2001 by Joergen Ibsen
// All Rights Reserved
//

#ifndef __INI_FILE_H_INCLUDED
#define __INI_FILE_H_INCLUDED

class ini_file {

public:
   // constructors
   ini_file(char *fname);

   // destructor
   ~ini_file();

   // members
   bool get_bool(char *id, bool default_val);
   bool get_bool(char *section, char *id, bool default_val);

   int get_int(char *id, int default_val);
   int get_int(char *section, char *id, int default_val);

   double get_double(char *id, double default_val);
   double get_double(char *section, char *id, double default_val);

   char *get_string(char *id, char *default_val);
   char *get_string(char *section, char *id, char *default_val);

   int get_token_lineno(char *id);
   int get_token_lineno(char *section, char *id);
   int get_section_lineno(char *section);

   int get_num_sections() const { return(num_sections); }
   int get_num_tokens() const { return(num_tokens); }

private:
   struct ini_token {
      ini_token() : next(0) { /* nothing */ }
      ~ini_token()
      {
         if (next) delete next;
      }

      char *id;
      char *val;
      int lineno;
      ini_token *next;
   };

   struct ini_section {
      ini_section() : tokens(0), next(0) { /* nothing */ }
      ~ini_section()
      {
         if (tokens) delete tokens;
         if (next) delete next;
      }

      char *id;
      ini_token *tokens;
      int lineno;
      ini_section *next;
   };

   ini_section *lookup_section(char *section);

   ini_token *lookup_token(char *id);
   ini_token *lookup_token(char *section, char *id);

   // data
   ini_section *sections;

   int num_sections;
   int num_tokens;
};

#endif // __INI_FILE_H_INCLUDED
