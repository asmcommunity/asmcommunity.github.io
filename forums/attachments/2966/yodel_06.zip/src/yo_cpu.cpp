#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "mytypes.h"

/*
Get CPU speed. On NT, read the registry. On 9x, calculate it - requiring RDTSC.
Humm, there might be a registry entry one can read on 9x, just located somewhere
else than on NT? What do I know :)
*/
static const uint delay = 1000;

uint yo_cpuspeed(void)
{
	HKEY	key;
	LRESULT	result;
	DWORD	freq;
	DWORD	sz = 4;

	// first, try the NT way
	result = RegCreateKeyEx(HKEY_LOCAL_MACHINE,
		"HARDWARE\\DESCRIPTION\\System\\CentralProcessor\\0",
		0, NULL, 0, KEY_QUERY_VALUE, NULL, &key, NULL);

	if(result == ERROR_SUCCESS)
	{
		result = RegQueryValueEx(key, "~Mhz", NULL, NULL, (LPBYTE) &freq, &sz);
		RegCloseKey(key);

		if(result == ERROR_SUCCESS)
		{
			// success, we must be on a NT machine. Return frequency.
			return freq;
		}
	}
	
	// oops, failure. Must be 9x. Calculate manually.
	DWORD	oldpc = GetPriorityClass(GetCurrentProcess());
	DWORD	oldtp = GetThreadPriority(GetCurrentThread());

	unsigned __int64	time;

	SetPriorityClass(GetCurrentProcess(), REALTIME_PRIORITY_CLASS);
	SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL);

	Sleep(0); // give up remainder of timeslice - this ought to make timings slightly more accurate
	__asm {
		rdtsc
		mov		dword ptr [time + 0], eax
		mov		dword ptr [time + 4], edx

		push	[delay]
		call	Sleep

		rdtsc
		sub		eax, dword ptr [time + 0]
		sbb		edx, dword ptr [time + 4]
		mov		dword ptr [time + 0], eax
		mov		dword ptr [time + 4], edx
	}

	SetPriorityClass(GetCurrentProcess(), oldpc);
	SetThreadPriority(GetCurrentThread(), oldtp);

	time = time / (1000*delay);

	return time;
}
