extern "C" unsigned int __stdcall time7(unsigned int num)
{
	unsigned int result = num & 0x7F7F7F7F;
	unsigned int tmp    = num & 0x7F7F7F;
	
	result += tmp;
	tmp += tmp;
	tmp &= (0x7F7F << 1);
	result += tmp;
	tmp += tmp;
	tmp &= (0x7F << 2);
	result += tmp;
	
	return result >> 3;
}