//
// Class giving access to .ini files
//
// Copyright (c) 2000-2001 by Joergen Ibsen
// All Rights Reserved
//

#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <ctype.h>

#include "ini_file.h"

// --- constructors -------------------------------------------------

ini_file::ini_file(char *fname)
   : sections(0),
     num_sections(0),
     num_tokens(0)
{
   FILE *fp = fopen(fname, "rb");

   if (fp == 0) return;

   char line[1025];
   line[1024] = '\0';

   int lineno = 0;

   bool done = false;

   while (!done)
   {
      lineno++;

      if (fgets(line, 1024, fp) == 0)
      {
         done = true;

      } else {

         char *lp = line;

         // skip whitespaces
         while ((*lp == ' ') || (*lp == '\t')) lp++;

         // if not empty and not a comment line
         if ((*lp > ' ') && (*lp != '#'))
         {
            // if section identifier
            if (*lp == '[')
            {
               lp++;
               char *id = lp;

               // scan until end or square bracket (upcasing)
               while ((*lp >= ' ') && (*lp != ']'))
               {
                  *lp = toupper(*lp);
                  lp++;
               }

               // accept if it ends with a square bracket
               if (*lp == ']')
               {
                  // zero terminate identifier
                  *lp = 0;

                  ini_section *s = new ini_section;

                  s->id = strdup(id);
                  s->tokens = 0;
                  s->lineno = lineno;

                  // link into list
                  s->next = sections;
                  sections = s;

                  num_sections++;
               }

            } else { // if (*lp == '[')

               char *id = lp;

               // scan until end of identifier (upcasing it)
               while ((*lp > ' ') && (*lp != '='))
               {
                  *lp = toupper(*lp);
                  lp++;
               }

               if (*lp == '=')
               {
                  // zero terminate identifier
                  *lp = 0;
                  lp++;

                  // skip whitespaces up to value
                  while ((*lp == ' ') || (*lp == '\t')) lp++;

               } else {

                  // zero terminate identifier
                  *lp = 0;
                  lp++;

                  // skip whitespaces up to equal sign
                  while ((*lp == ' ') || (*lp == '\t')) lp++;

                  if (*lp == '=')
                  {
                     lp++;

                     // skip whitespaces up to value
                     while ((*lp == ' ') || (*lp == '\t')) lp++;
                  }
               }

               char *val = lp;

               // scan until end of value
               if (*lp == '"')
               {
                  lp++;
                  val++;

                  // scan to EOL
                  while ((*lp >= ' ') || (*lp == '\t')) lp++;

                  // scan back to last double quote
                  while (*lp != '"') lp--;

                  // fix one double quote problem
                  if (lp <= val) lp = val;

               } else {

                  while ((*lp > ' ') && (*lp != '#')) lp++;
               }

               // zero terminate value
               *lp = 0;

               // accept if identifier is non-empty
               if (*id != '\0')
               {
                  ini_token *t = new ini_token;

                  t->id = strdup(id);
                  t->val = strdup(val);
                  t->lineno = lineno;

                  // if no section, make default
                  if (sections == 0)
                  {
                     ini_section *s = new ini_section;

                     s->id = "__INI_MAIN__";
                     s->tokens = 0;
                     s->lineno = lineno;

                     // link into list
                     s->next = sections;
                     sections = s;

                     num_sections++;
                  }

                  // link into list
                  t->next = sections->tokens;
                  sections->tokens = t;

                  num_tokens++;
               }
            }
         }
      }
   }

   fclose(fp);
}

// --- destructor ---------------------------------------------------

ini_file::~ini_file()
{
   delete sections;
}

// --- private ------------------------------------------------------

ini_file::ini_section *ini_file::lookup_section(char *section)
{
   ini_section *current = sections;

   while (current)
   {
      if (strcmp(section, current->id) == 0) return(current);

      current = current->next;
   }

   return(0);
}


ini_file::ini_token *ini_file::lookup_token(char *id)
{
   ini_section *s = sections;

   while (s)
   {
      ini_token *current = s->tokens;

      while (current)
      {
         if (strcmp(id, current->id) == 0) return(current);

         current = current->next;
      }

      s = s->next;
   }

   return(0);
}

ini_file::ini_token *ini_file::lookup_token(char *section, char *id)
{
   ini_section *s = lookup_section(section);

   if (s == 0) return(0);

   ini_token *current = s->tokens;

   while (current)
   {
      if (strcmp(id, current->id) == 0) return(current);

      current = current->next;
   }

   return(0);
}

// --- public -------------------------------------------------------

bool ini_file::get_bool(char *id, bool default_val)
{
   return(get_bool(0, id, default_val));
}

bool ini_file::get_bool(char *section, char *id, bool default_val)
{
   ini_token *current;

   if (section == 0) current = lookup_token(id);
      else current = lookup_token(section, id);

   if (current != 0)
   {
      char *line = current->val;

      if ((line[0] == 'T') || (line[0] == 't') ||
          (line[0] == 'Y') || (line[0] == 'y') ||
          (line[0] == '1') || (line[0] == '+')) return(true);

      if ((line[0] == 'F') || (line[0] == 'f') ||
          (line[0] == 'N') || (line[0] == 'n') ||
          (line[0] == '0') || (line[0] == '-')) return(false);
   }

   return(default_val);
}

int ini_file::get_int(char *id, int default_val)
{
   return(get_int(0, id, default_val));
}

int ini_file::get_int(char *section, char *id, int default_val)
{
   ini_token *current;

   if (section == 0) current = lookup_token(id);
      else current = lookup_token(section, id);

   if (current != 0)
   {
      int i;

      if (sscanf(current->val, "%d", &i) == 1) return(i);
   }

   return(default_val);
}

double ini_file::get_double(char *id, double default_val)
{
   return(get_double(0, id, default_val));
}

double ini_file::get_double(char *section, char *id, double default_val)
{
   ini_token *current;

   if (section == 0) current = lookup_token(id);
      else current = lookup_token(section, id);

   if (current != 0)
   {
      double d;

      if (sscanf(current->val, "%lf", &d) == 1) return(d);
   }

   return(default_val);
}

char *ini_file::get_string(char *id, char *default_val)
{
   return(get_string(0, id, default_val));
}

char *ini_file::get_string(char *section, char *id, char *default_val)
{
   ini_token *current;

   if (section == 0) current = lookup_token(id);
      else current = lookup_token(section, id);

   if (current != 0)
   {
      return(current->val);
   }

   return(default_val);
}

int ini_file::get_token_lineno(char *id)
{
   return(get_token_lineno(0, id));
}

int ini_file::get_token_lineno(char *section, char *id)
{
   ini_token *current;

   if (section == 0) current = lookup_token(id);
      else current = lookup_token(section, id);

   if (current != 0)
   {
      return(current->lineno);
   }

   return(0);
}

int ini_file::get_section_lineno(char *section)
{
   ini_section *current = lookup_section(section);

   if (current != 0)
   {
      return(current->lineno);
   }

   return(0);
}
