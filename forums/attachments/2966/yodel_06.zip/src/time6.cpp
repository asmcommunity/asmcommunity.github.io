extern "C" unsigned int __stdcall time6(unsigned int num)
{
	return (num & 0x7F) | ((num & 0x7F00) >> 1) | ((num & 0x7F0000) >> 2) | ((num & 0x7F000000) >> 3);
}