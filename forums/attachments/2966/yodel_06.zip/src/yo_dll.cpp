#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "mytypes.h"
#include "yodel.h"

/*
This code needs to be fixed up - shouldn't need to call through a dummy, but I couldn't
get "func_t *yo_dllfunc" working, it would call the dummy func even after load.
*/

static unsigned int __stdcall dummy(unsigned int num)
{
	return 0;
}

static func_t	*BLAH = dummy;

bool __stdcall yo_dllfunc(unsigned int parm)
{
	return BLAH(parm);
}

void yo_dllload(void)
{
	HMODULE	hdll;
	func_t	*func;

	hdll = LoadLibrary("timedll.dll");
	if(hdll == NULL) return;
	func = (func_t *) GetProcAddress(hdll, "_func");
	if(func == NULL) return;

	BLAH = func;
}
