#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "yodel.h"

void *yo_memalloc(uint size)
{
	void *mem;
	mem = VirtualAlloc(NULL, size, MEM_COMMIT, PAGE_READWRITE);
	memset(mem , 0, size);
	return mem;
}

void yo_memfree(void *mem)
{
	VirtualFree(mem, 0, MEM_RELEASE);
}

void yo_memzero(void *buf, const uint size)
{
	memset(buf, 0, size);
}


void yo_memcopy(void *dst, const void *src, const uint size)
{
	memcpy(dst, src, size);
}


int yo_memcomp(const void *buf1, const void *buf2, size_t count)
{
	return memcmp(buf1, buf2, count);
}
