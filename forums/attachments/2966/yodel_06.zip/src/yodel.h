#ifndef __YODEL_H__
#define __YODEL_H__

#include "mytypes.h"

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// typedefs etc
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
typedef unsigned int __stdcall func_t(unsigned int num);

struct funcnfo_t
{
	bool	conform;	// true == passed conformance checks
	bool	plain;		// true == plain instructionset only flag
	func_t	*func;		// func pointer
	char	*name;		// func name
};

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// global function prototypes
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// yo_cpu.cpp
extern uint yo_cpuspeed(void);

// yo_memory.cpp
extern void *yo_memalloc(uint size);
extern void yo_memfree(void *mem);
extern void yo_memzero(void *buf, const uint size_t);
extern void yo_memcopy(void *dst, const void *src, const size_t size);
extern int  yo_memcomp(const void *buf1, const void *buf2, size_t count);

// yo_process.cpp
extern void yo_priorityboost(void);
extern void yo_prioritynormal(void);
extern void yo_sleep(uint msec);

// yo_util.cpp
extern u32  yo_gettick(void);
extern void yo_srand(uint val);
extern u16  yo_rand(void);
extern void yo_fillrand_u8(void *buf, uint size);
extern void yo_fillrand_u16(void *buf, uint size);
extern void yo_fillrand_u32(void *buf, uint size);

// yo_io.cpp
extern void yo_printf(const char *szFormat, ...);

// yo_dll.cpp
extern void yo_dllload(void);
extern bool __stdcall yo_dllfunc(u16 *parm);
//extern func_t *yo_dllfunc;


//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// global data
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
extern char *szVersion;			// yodel version string

#endif // header
