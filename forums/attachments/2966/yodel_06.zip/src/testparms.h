#ifndef __TESTPARMS_H__
#define __TESTPARMS_H__

// test specific parameters. Tjulahop.

#include "mytypes.h"
const uint ARRAYSIZE = 2048;
const uint BYTESIZE = ARRAYSIZE*sizeof(u16);
const uint CONSTANT = 92;

#endif // __TESTPARMS_H__
