#include <stdio.h>
#include <stdarg.h>

// to be implemented...
extern void yo_printf(const char *szFormat, ...)
{
	char buf[1024];

	va_list ap;

	va_start(ap, szFormat);
	vsprintf(buf, szFormat, ap);
	printf("%s", buf);
	fflush(stdout);
}
