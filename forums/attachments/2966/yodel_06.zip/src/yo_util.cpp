#define WIN32_LEAN_AND_MEAN
#include <windows.h>	// GetTickCount
#include <stdlib.h>		// rand()
#include "yodel.h"

u32 yo_gettick(void)
{
	return GetTickCount();
}

void yo_srand(uint val)
{
	srand(val);
}

u16 yo_rand(void)
{
	return (u16) rand();
}



template <class T> void fillrand(T *buf, uint size, const uint cap)
{
	size /= sizeof(*buf);
	while(size--) {
		*buf++ = yo_rand() % cap;
	}
}


void yo_fillrand_u8(void *buf, uint size)
{
	fillrand((u8 *) buf, size, 0xFF);
}


void yo_fillrand_u16(void *buf, uint size)
{
	fillrand((u16 *) buf, size, 0xFFFF);
}


void yo_fillrand_u32(void *buf, uint size)
{
	fillrand((u32 *) buf, size, 0xFFFF);
}
