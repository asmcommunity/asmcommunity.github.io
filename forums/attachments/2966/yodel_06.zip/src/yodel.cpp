#include "yodel.h"
#include "testparms.h"
#include "mytypes.h"
#include "ini_file.h"

#include <excpt.h>

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// GLOBAL data
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
char *g_szVersion		= "Yodel version 0.6, 2009/11/24, 11:00";

// variables used to control program behaviour - one day these will be runtime tweakable.
bool g_bConform			= true;					// only time conforming routines?
bool g_bPlain			= false;				// only allow plain instructionset?
bool g_bBoostPriority	= true;					// raise process priority?
bool g_bDoConform		= true;					// do conformance checks?
bool g_bDoPerform		= true;					// do performance checks?
uint g_uCpuSpeed		= 0;					// CPU speed (init to zero to do autodetect)
uint g_uPerformIterations = 100000000;			// number of iterations done in performance check
uint g_uConformIterations = 1000;				// number of iterations done in conformance check

uint NUMOPS = (ARRAYSIZE*g_uPerformIterations);


//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// external test function prototypes
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
extern "C" unsigned int __stdcall time1(unsigned int num); // Scali1
extern "C" unsigned int __stdcall time2(unsigned int num); // Scali2
extern "C" unsigned int __stdcall time3(unsigned int num); // Scali3
extern "C" unsigned int __stdcall time4(unsigned int num); // sysfce2-1
extern "C" unsigned int __stdcall time5(unsigned int num); // Ultrano
extern "C" unsigned int __stdcall time6(unsigned int num); // ANSI C 1
extern "C" unsigned int __stdcall time7(unsigned int num); // ANSI C 2
extern "C" unsigned int __stdcall time8(unsigned int num); // ANSI C 2 handoptimized
extern "C" unsigned int __stdcall time9(unsigned int num); // r22
extern "C" unsigned int __stdcall time10(unsigned int num); // drizz
extern "C" unsigned int __stdcall time11(unsigned int num); // sysfce2-2
extern "C" unsigned int __stdcall time12(unsigned int num); // sysfce2-3
extern "C" unsigned int __stdcall time13(unsigned int num); // ti_mo_n
extern "C" unsigned int __stdcall time14(unsigned int num); // Scali MMX
extern "C" unsigned int __stdcall time15(unsigned int num); // Scali SSE2
extern "C" unsigned int __stdcall time16(unsigned int num); // Scali MMX+SSSE3
extern "C" unsigned int __stdcall time17(unsigned int num); // Scali SSSE3
extern "C" unsigned int __stdcall time18(unsigned int num); // r22 mega-LUT
extern "C" unsigned int __stdcall time19(unsigned int num); // lingo12
extern "C" unsigned int __stdcall time20(unsigned int num); // lingo12 SSSE3

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// static global data
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// array of functions to test.
static funcnfo_t funcs[] =
{
	{	true, true,	time1,	"test01-Scali1"	},
	{	true, true,	time2,	"test02-Scali2"		},
	{	true, true,	time3,	"test03-Scali3"		},
	{	true, true,	time4,	"test04-sysfce2-1"		},
	{	true, true,	time5,	"test05-Ultrano"	},
	{	true, true,	time6,	"test06-ANSI C 1"		},
	{	true, true, time7,	"test07-ANSI C 2"		},
	{	true, true, time8,	"test08-ANSI C 2 handoptimized"		},
	{	true, true, time9,	"test09-r22 LUT" },
	{	true, true, time10,	"test10-drizz"	},
	{	true, true,	time11,	"test11-sysfce2-2"		},
	{	true, true,	time12,	"test12-sysfce2-3"		},
	{	true, true,	time13,	"test13-ti_mo_n"		},
	{	true, true,	time14,	"test14-Scali MMX"		},
	{	true, true,	time15,	"test15-Scali SSE2"		},
	{	true, true,	time16,	"test16-Scali MMX+SSSE3"		},
	{	true, true,	time17,	"test17-Scali SSSE3"		},
	{	true, true,	time18,	"test18-r22 mega-LUT"		},
	{	true, true,	time19,	"test19-lingo12"		},
	{	true, true,	time20,	"test20-lingo12 SSSE3"		},
};


//static u16	*mem1;			// memory block used for tests
static unsigned int num; // input used for tests


// conformance tests
static void t_conform(void)
{
	// conformance test... the idea of this is simple: for each iteration,
	// fill mem2 with random values. copy mem2 to mem1. Feed mem2 to time1(),
	// our "known to conform" function. Now mem2 has the expected values, and
	// mem1 the input values. Run the function, and memcmp(mem1,mem2). If they
	// don't match, func doesn't conform.
	// Loop should of course be aborted as soon as a func doesn't conform.
	// If the func returns false, it means it has failed - perhaps the func detected
	// conformance error itself, perhaps something else happened. End result is the
	// same, func doesn't conform. It's reported to the user as a failure rather than
	// unconform though. 
	//u16	*mem2;
	
	num = (yo_rand() << 16) | yo_rand();

	yo_srand(yo_gettick());
	//mem2 = (u16 *) yo_memalloc(BYTESIZE);

	yo_printf("/] running conformance tests\n");
	for(uint i=0; i<lengthof(funcs); i++)
	{
		funcnfo_t *func = &funcs[i];

		yo_printf("%-30s...", func->name);
		if(g_bPlain && !func->plain)
		{
			yo_printf("skipping, not plain\n");
			continue;
		}

		__try
		{
			for(uint loopy=0; loopy<g_uConformIterations; loopy++)
			{
				//yo_fillrand_u8(mem2, BYTESIZE);
				//yo_memcopy(mem1, mem2, BYTESIZE);
				//funcs[0].func(mem2);			// calculate "good values" with conforming function
				unsigned int result = funcs[0].func(num);			// calculate "good values" with conforming function

				if(result != func->func(num))
				{
					func->conform = false;
					yo_printf("func failed at iteration %d\n", loopy);
					goto _fail;
				}

				/*if(yo_memcomp(mem1, mem2, BYTESIZE) != 0)
				{
					func->conform = false;
					yo_printf("nonconforming at iteration %d\n", loopy);
					goto _fail;
				}*/
			}
			yo_printf("conforms\n");
		}
		__except( (GetExceptionCode() == 0xC000001D) )
		{
			func->conform = false;
			yo_printf("func uses unsupported instructions\n");
		}
_fail: ;	// the ';' has to be there, otherwise some compilers will bitch about expecting a statement.
	}

	//yo_memfree(mem2);
}



// performance tests
static void t_perform(void)
{
	yo_printf("/] running performance tests\n");
	for(uint i=0; i<lengthof(funcs); i++)
	{
		funcnfo_t *func = &funcs[i];

		yo_printf("%-30s...", func->name);
		if(!func->conform) {
			yo_printf("doesn't conform(!)...");
			if(g_bConform) {
				yo_printf("skipping\n");
				continue;
			}
		}
		if(g_bPlain && !func->plain)
		{
			yo_printf("skipping, not plain\n");
			continue;
		}

		// time it
		if(g_bBoostPriority) yo_priorityboost();

		//yo_memzero(mem1, BYTESIZE);
		yo_sleep(0);
		u32 time = yo_gettick();
		for(uint loopy=g_uPerformIterations; loopy>0; loopy--)
		{
//			__asm { int 3 }
			/*if(!func->func(num)) {
				yo_printf("fail\n");
				goto _fail;
			}*/
			func->func(num);
		}
		time = yo_gettick() - time;
		if(g_bBoostPriority) yo_prioritynormal();
		yo_sleep(10); // give other threads a little time, hopefully allowing internet stuff not to time out.

		// calculate clks/mul. Put in a block so clk only has local scope, and compilers won't
		// warn/error because of the _fail label.
		{
			float clk = (g_uCpuSpeed * 1000.0f * time) / ((float) NUMOPS);
			yo_printf("%06d ticks (effective %.3f clk/iteration)\n", time, clk);
		}
_fail: ;	// the ';' has to be there, otherwise some compilers will bitch about expecting a statement.
	}

}



int main(void)
{
	yo_printf("######## %s\n", g_szVersion);

	// read parameters from .ini file - thanks Jibz!
	{
	   ini_file inif("yodel.ini");
	   
	   if (inif.get_num_tokens() > 0)
	      yo_printf("## reading yodel.ini\n");
	   else
	      yo_printf("## WARNING: unable to read coulomb.ini, using defaults\n");

	   g_bConform = inif.get_bool("CONFORM", g_bConform);
	   g_bPlain = inif.get_bool("PLAIN", g_bPlain);
	   g_bBoostPriority = inif.get_bool("BOOST", g_bBoostPriority);
	   g_bDoConform = inif.get_bool("DOCONFORM", g_bDoConform);
	   g_bDoPerform = inif.get_bool("DOPERFORM", g_bDoPerform);
	   g_uCpuSpeed = inif.get_int("CPUSPEED", g_uCpuSpeed);
	   g_uPerformIterations = inif.get_int("PERFORMITERATIONS", g_uPerformIterations);
	   g_uConformIterations = inif.get_int("CONFORMITERATIONS", g_uConformIterations);

	   NUMOPS = /*ARRAYSIZE */ g_uPerformIterations;
	}


	yo_printf("## Test parameters: %d iterations of %d muls, total %d muls\n", g_uPerformIterations, ARRAYSIZE, NUMOPS);
	if(g_bBoostPriority)yo_printf("## Boosting priority: your computer might appear frozen - don't panic.\n");
	if(g_bPlain)		yo_printf("## Plain: Skipping non-pmmx routines\n");

	// detect CPU speed unless user is overriding
	if(g_uCpuSpeed == 0) {
		yo_printf("## Retrieving (NT) or calculating (9x) clockspeed...");
		g_uCpuSpeed = yo_cpuspeed();
	} else {
		yo_printf("## User overriden CPU speed: ");
	}
	yo_printf("%d MHz\n", g_uCpuSpeed);

	//mem1 = (u16 *) yo_memalloc(BYTESIZE);

	yo_dllload();

	if(g_bDoConform) t_conform();
	if(g_bDoPerform) t_perform();

	return 0;
}
