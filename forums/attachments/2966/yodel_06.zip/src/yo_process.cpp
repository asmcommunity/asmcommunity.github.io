#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "yodel.h"

static bool		boosted = false;	// are we currently priority boosted?
static DWORD	opc;				// old priority class
static DWORD	otp;				// old thread priority




void yo_priorityboost(void)
{
	if(boosted) return;
	opc = GetPriorityClass(GetCurrentProcess());
	otp = GetThreadPriority(GetCurrentThread());

	SetPriorityClass(GetCurrentProcess(), REALTIME_PRIORITY_CLASS);
	SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL);
	boosted = true;
}

void yo_prioritynormal(void)
{
	if(!boosted) return;
	boosted = false;
}

void yo_sleep(uint msec)
{
	Sleep(msec);
}
