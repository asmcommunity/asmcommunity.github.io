simple FlatButton custom control for Radasm, written by drizz.
v1.0

Installation:
~~~~~~~~~~~~

- copy FlatButton.lib to your \lib folder.
- copy FlatButton.dll to folder where Radasm.exe is.
- edit Radasm.ini, and add:

[CustCtrl]
...
x=FlatButton.dll,1
...

- where x is next free number


in your projects
~~~~~~~~~~~~~~~~

- add theese two lines at beggining of your project

...
includelib flatbutton.lib
InitFlatButton proto stdcall :DWORD; only 1 function
...

- call the function that registers the class
  before dialog that uses FlatButton is created.

....
start:
	invoke GetModuleHandle,0
	mov hInstance,eax
	invoke InitFlatButton,hInstance
...


 