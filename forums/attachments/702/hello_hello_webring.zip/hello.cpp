#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#pragma data_seg(".text")
#pragma const_seg(".text")
static char *szHelloWorld = "Hello, World!";

void entry32(void)
{
	MessageBox(0, szHelloWorld, szHelloWorld, MB_OK);
	// implicit return, which ends up terminating the program
}
