finds COM classes, defined within  "input.h", and converts them to simple ATC COM classes.
