The dummy procedure __security_check_cookie and variable ___security_cookie are introduced
to the tiny C run-time startup library VCExpr2005crt0