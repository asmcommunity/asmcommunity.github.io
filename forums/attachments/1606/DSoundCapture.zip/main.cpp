// DSoundCapture with no UGLY notifications and such. 
// Can be used in parallel with EasySound!!

#include <windows.h>
#include <dsound.h>
#include <stdio.h>

LPDIRECTSOUNDCAPTURE		lpDSC;
LPDIRECTSOUNDCAPTUREBUFFER	lpDCB;

WAVEFORMATEX wfx = {1,1,44100,88200,2,16,0};
DSCBUFFERDESC desc1 = {20,0,32768,0,&wfx};

short* AudioCardData;
short InputAudioData[16384];

void msgbox(char* str1){
	MessageBox(0,str1,0,0);
}

DWORD LastReadPos=0;

DWORD TotalSamplesRecorded=0;

FILE* f1;


// THIS callback is what we'll be using ;)
void OnInputAudio(short *pInBuf,long NumSamples){
	fwrite(pInBuf,NumSamples,2,f1);
}




INT APIENTRY WinMain( HINSTANCE hInst, HINSTANCE hPrevInst, LPSTR pCmdLine, 
                      INT nCmdShow )
{
	DWORD baka;
	DWORD EndTime;
	char str1[100];
	f1 = fopen("dump.bin","wb");
	if(!f1){
		msgbox("cannot open dump.bin");
		return 0;
	}
	if(DirectSoundCaptureCreate(0,&lpDSC,0)){
		msgbox("No sound input...");
		return 0;
	}
	if(lpDSC->CreateCaptureBuffer(&desc1,&lpDCB,0)){
		msgbox("No capture buffer...");
		return 0;
	}
	lpDCB->Lock(0,32768,(void**)&AudioCardData,&baka,0,0,0);
	lpDCB->Unlock(AudioCardData,baka,0,0);

	msgbox("starting");

	EndTime = GetTickCount() + 10000;
	
	lpDCB->Start(DSCBSTART_LOOPING);
	for(;;){
		DWORD CurSndPos,NumSamples,i;
		if((EndTime-GetTickCount())>>31)break;
		lpDCB->GetCurrentPosition(0,&CurSndPos);
		CurSndPos>>=1; // convert numBytes to samples
		NumSamples = (CurSndPos-LastReadPos)&16383;
		TotalSamplesRecorded += NumSamples;
		if(NumSamples){
			for(i=0;i<NumSamples;i++){
				InputAudioData[i]=AudioCardData[LastReadPos];
				LastReadPos++;
				LastReadPos&=16383;
			}
			OnInputAudio(InputAudioData,NumSamples);
		}
		Sleep(5);
	}
	lpDCB->Stop();
	itoa(TotalSamplesRecorded,str1,10);
	msgbox("done recording");
	msgbox(str1);
	lpDCB->Release();
	lpDSC->Release();
	fclose(f1);
	return 0;
}
