#include <stdio.h>
#include <math.h>

#define TABSIZE 4096
#define TABMASK (TABSIZE-1)

float tab[TABSIZE];

#define PI2 6.283185307179586476925286766559

void InitTab(){
	for(int i=0;i<TABSIZE;i++){
		double x = PI2/((double)TABSIZE);
		x*=i;
		tab[i] = (float) sin(x);
	}
}


double sin1(double x){ // no interpo
	x *= ((double)TABSIZE)/PI2;
	int i = floor(x);
	return tab[i&TABMASK];
}
double sin2(double x){ // linear interpo
	//--------[ get a,b,...]---------------[
	int i;
	float a,b; //samples from the table
	double delta,temp; // 0..0.999999999999
	x *= ((double)TABSIZE)/PI2;
	temp = floor(x); delta = x-temp;
	i = (int)temp;
	a = tab[i&TABMASK]; i++;
	b = tab[i&TABMASK]; i++;
	//-------------------------------------/

	return a*(1.0-delta)+b*delta;
}
double sin3(double angle){ // 6-point spline
	float p0,p1,p2,p3,p4,p5; //samples from the table
	angle *= ((double)TABSIZE)/PI2;
	
	int i = (int)angle; // notice we are not doing a floor()!
	double x = angle - (double)i;
	i-=2;
	p0 = tab[i&TABMASK]; i++;
	p1 = tab[i&TABMASK]; i++;
	p2 = tab[i&TABMASK]; i++;
	p3 = tab[i&TABMASK]; i++;
	p4 = tab[i&TABMASK]; i++;
	p5 = tab[i&TABMASK]; i++;

	return p2 + 0.04166666666*x*((p3-p1)*16.0+(p0-p4)*2.0
    + x *((p3+p1)*16.0-p0-p2*30.0- p4
    + x *(p3*66.0-p2*70.0-p4*33.0+p1*39.0+ p5*7.0- p0*9.0
    + x *( p2*126.0-p3*124.0+p4*61.0-p1*64.0- p5*12.0+p0*13.0
    + x *((p3-p2)*50.0+(p1-p4)*25.0+(p5-p0)*5.0)))));
}



void main(){
	double maxerr1=0.0;
	double maxerr2=0.0;
	double maxerr3=0.0;
	double curerr;
	
	double angle;
	InitTab();

	for(angle=0.0;angle<=10.0;angle+=0.001){
		curerr = fabs(sin(angle) - sin1(angle));
		if(maxerr1<curerr)maxerr1=curerr;
	}

	for(angle=0.0;angle<=10.0;angle+=0.001){
		curerr = fabs(sin(angle) - sin2(angle));
		if(maxerr2<curerr)maxerr2=curerr;
	}
	for(angle=0.0;angle<=10.0;angle+=0.001){
		curerr = fabs(sin(angle) - sin3(angle));
		if(maxerr3<curerr)maxerr3=curerr;
	}

	maxerr1*=100.0;	maxerr2*=100.0;	maxerr3*=100.0;
	printf("errors are %f%% , %f%% , %f%%\n",maxerr1,maxerr2,maxerr3);
	// above, the printed text is  errors are 0.153332% , 0.000032% , 0.000004%
	
}
