// NOTE: INCLUDE Environment variable must be set to headers path
// Kludge for goasm bug
#DEFINE IDISPATCH_DEFINED
#DEFINE IUNKNOWN_DEFINED

#DEFINE LINKFILES
#DEFINE LINKVCRT
#DEFINE ODBC_STD
#DEFINE NOMCX
#DEFINE NOIME
#DEFINE NOTV
#DEFINE NONETWORK
#DEFINE NOSERVICE
#DEFINE NOCON
#DEFINE NOCARD
#DEFINE NORADASM
#DEFINE NOZLIB
#DEFINE NODONKEY
#DEFINE CCUSEORDINALS

#include "WINDOWS.H"
#include "Commctrl.h"
#include "macros.a"
#include "exdisp.h"
#include "atlbase.h"
#include "ExDispid.h"
