#include <stdio.h>
#include "mpg123.h"

int main(int argc, _TCHAR* argv[])
{
    mpg123_init();

    mpg123_handle *m;

    m = mpg123_new(NULL, NULL);
    mpg123_param(m, MPG123_RESYNC_LIMIT, -1, 0); /* New in library version 0.0.1 . */

    int nRet = mpg123_open(m, "C:\\1.mp3");
    
    printf("%s\n", mpg123_plain_strerror(nRet));

    mpg123_exit();

    return 0;
}

