OLE Drag-Drop menu

example.asm - main file.
Call InstallDragDrop(hwnd, hMenu, bDialog, bInstall) to install/uninstall
yepp, it is yet not fully universal function (global variables instead window property)
 - hwnd     window handle that owns menu hMenu
 - hMenu    handle to menu to install drag-drop
 - bDialog  set to FALSE if hwnd is a WINDOW, set to TRUE if hwnd is a DIALOG
 - bInstall set to TRUE(install) or FALSE(uninstall)

InstallDragDrop() adds a MNS_DRAGDROP flag to menu styles and subclass the window to receive messages
and creates three interface implementations (classes): IDataObject, IDropSource and IDropTarget
 - WM_DESTROY  : removes subclass

 - WM_MENUDRAG : wParam=menuitem, lParam=hMenu.
   We call DropTarget->setSource(hwnd, hMenu, nPos) to set source window, menu and item
   we call DoDragDrop() to run the drag-drop. OLE calls the classes until you drop menu item
   we're returning MND_CONTINUE (Menu should remain active. If the mouse is released, it should be ignored)

 - WM_MENUGETOBJECT : (lParam=MENUGETOBJECTINFO), OLE queries our window for IDropTarget class
   We call DropTarget->setDestination(MENUGETOBJECTINFO.hMenu, MENUGETOBJECTINFO.uPos) to set destination menu and item
   we set MENUGETOBJECTINFO.pvObj to class DropTarget if MENUGETOBJECTINFO.*riid = IID_IDropTarget, and
   we're returning MNGO_NOERROR

class CDataObject - all methods are "not implemented" or standard coded from templates

class CDropTarget - added two custom methods: setSource() and setDestination()
   method Drop() is called from class CDropSource::QueryContinueDrag(), and is responsible
   for accept/deny the drop. If mouse is not over menu or item X is dropped on same X - deny.
   Othervise MoveMenuItem() function moves the menu item
   other methods are only for cursor shape (accept/copy/move or deny)

class CDropSource - method QueryContinueDrag() checks for ESC key and left mouse button
   if mouse is released, it calls CDropTarget::Drop and returns DRAGDROP_S_CANCEL
   I've tried with returning DRAGDROP_S_DROP, but something in OLE always crashes


If you install drag-drop for menu in a window - after drop the menu will not close
