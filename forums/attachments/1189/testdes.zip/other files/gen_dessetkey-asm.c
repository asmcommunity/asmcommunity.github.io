rotLeft(byte *p,DWORD rolCnt,DWORD base)
{
	byte *pp;
	pp=malloc(base);
	memcpy(pp,p,base);
	memcpy(p,(byte *)((DWORD)pp+rolCnt),base-rolCnt);
	memcpy((byte *)((DWORD)p+(base-rolCnt)),pp,rolCnt);
	free(pp);
}

output()
{
    #define RNDS 16
    byte LR0[64],LR1[64];// input 64bit key
    byte FPC[16][48];
    byte FPC2[16][48];
    DWORD i,j,k,l;
    byte PC2[] = { // perm. choice
	   14, 17, 11, 24,  1,  5,
		3, 28, 15,  6, 21, 10,
	   23, 19, 12,  4, 26,  8,
	   16,  7, 27, 20, 13,  2,
	   41, 52, 31, 37, 47, 55,
	   30, 40, 51, 45, 33, 48,
	   44, 49, 39, 56, 34, 53,
	   46, 42, 50, 36, 29, 32
	   };
	byte ROT[] = { 1,1,2,2,2,2,2,2,1,2,2,2,2,2,2,1 }; // left rotations
	
	for ( i=0; i<48; i++ ) PC2[i]-=1;
	for ( i=24; i<48; i++ ) PC2[i]+=4;
	for ( i=0; i<64; i++ ) LR0[i]=i;
	k=0;
	for ( i=7; i>=5; i-- )
	{
		for ( j=0; j<=3; j++ )
		{
			LR1[k]=LR0[i+j*8];
			k++;
		}
		for ( j=0; j<=3; j++ )
		{
			LR1[k]=LR0[i+j*8+32];
			k++;
		}
	}
	for ( j=0; j<=3; j++ )
	{
		LR1[k]=LR0[4+j*8];
		k++;
	}
	for ( j=0; j<=3; j++ )
	{
		LR1[k]=0;
		k++;
	}
	for ( i=1; i<4; i++ )
	{
		for ( j=0; j<=3; j++ )
		{
			LR1[k]=LR0[i+j*8];
			k++;
		}
		for ( j=0; j<=3; j++ )
		{
			LR1[k]=LR0[i+j*8+32];
			k++;
		}
	}
	for ( j=0; j<=3; j++ )
	{
		LR1[k]=LR0[4+j*8+32];
		k++;
	}
	for ( j=0; j<=3; j++ )
	{
		LR1[k]=0;
		k++;
	}

	for ( i=0; i<RNDS; i++ )
	{
		rotLeft((byte *)LR1,ROT[i],28);// left part
		rotLeft((byte *)((DWORD)LR1+32),ROT[i],28);// right part
		//printf("ELSEIF rnd EQ %u\nR EQU <",i);
		for ( k=0; k<=47;k++)
		{
			FPC[i][k]=LR1[PC2[k]];
	//		printf("%u,",LR1[PC2[k]]);
		}
//		printf("%u>\n",LR1[PC2[47]]);
	}


	// interleave
	byte tmp[12];
	for (j=0;j<RNDS;j++)
	{
		rotLeft(&FPC[j][6],6,12);
		rotLeft(&FPC[j][6+24],6,12);
		memcpy(&tmp,&FPC[j][12],6);
		memcpy(&FPC[j][12],&FPC[j][24],6);
		memcpy(&FPC[j][24],&tmp,6);
		memcpy(&tmp,&FPC[j][18],6);
		memcpy(&FPC[j][18],&FPC[j][30],6);
		memcpy(&FPC[j][30],&tmp,6);
	}

	typedef struct _TRVal {
		DWORD numOR;
		DWORD loc;
		DWORD rnd;
	} TRVals,*PRVals;
	
	TRVals vals[RNDS];
	DWORD box;
	FILE *f;

	f=fopen("deskeygen.inc","wt+");
	fprintf(f,"\talign 16\n");
	fprintf(f,"OPTION PROLOGUE:NONE\n");
	fprintf(f,"OPTION EPILOGUE:NONE\n");
	fprintf(f,"DESSetKey proc pKey:PTR BYTE\n");
	fprintf(f,"\tmov eax,[esp][1*4]\n");
	fprintf(f,"\tmov ecx,[eax][0]\n");
	fprintf(f,"\tmov edx,[eax][4]\n");
	fprintf(f,"\tbswap ecx\n");
	fprintf(f,"\tbswap edx\n");
	fprintf(f,"\tpush ebp\n\tpush esi\n\tpush edi\n\tpush ebx\n");
	fprintf(f,"\tlea edi,KeyTab\n");
	register w;
	for (i=0;i<64;i++)
	{
		if ((i%8)!=0)
		{

		if (i<32)
		{
		fprintf(f,"\ttest edx,0%.8Xh\n\tjz @F\n",1<<i);
		}
		else
		{
		fprintf(f,"\ttest ecx,0%.8Xh\n\tjz @F\n",1<<(i-32));
		}
		memset(&vals,0,sizeof(vals));
		box=0;
		for (j=0;j<RNDS;j++)
		{
			for (k=0;k<48;k++)
			{
				if (FPC[j][k]==i)
				{
						l=k;
						if (l<24)
						{
							l=23-l;
							vals[box].numOR=1<<(l+(l/6)*2);
							vals[box].loc=0;
							vals[box].rnd=j;
							box++;
						}
						else
						{
							l=47-l;
							vals[box].numOR=1<<(l+(l/6)*2);
							vals[box].loc=4;
							vals[box].rnd=j;
							box++;
						}
				}
			}
		}
		const unsigned char *freeregs[]={"eax","ebx","esi","ebp"};
		for (j=0;j<(box/4);j++)
		{
			fprintf(f,"\tmov %s,0%.8Xh\n",freeregs[0],vals[j*4+0].numOR);
			fprintf(f,"\tmov %s,0%.8Xh\n",freeregs[1],vals[j*4+1].numOR);
			fprintf(f,"\tmov %s,0%.8Xh\n",freeregs[2],vals[j*4+2].numOR);
			fprintf(f,"\tmov %s,0%.8Xh\n",freeregs[3],vals[j*4+3].numOR);
			fprintf(f,"\tor [edi][%u*8][%u],%s\n",vals[j*4+0].rnd,vals[j*4+0].loc,freeregs[0]);
			fprintf(f,"\tor [edi][%u*8][%u],%s\n",vals[j*4+1].rnd,vals[j*4+1].loc,freeregs[1]);
			fprintf(f,"\tor [edi][%u*8][%u],%s\n",vals[j*4+2].rnd,vals[j*4+2].loc,freeregs[2]);
			fprintf(f,"\tor [edi][%u*8][%u],%s\n",vals[j*4+3].rnd,vals[j*4+3].loc,freeregs[3]);
		}
		if (box%4)
		{
			for (j=(box-(box%4)),k=0;j<box;j++,k++)
				fprintf(f,"\tmov %s,0%.8Xh\n",freeregs[k],vals[j].numOR);
			for (j=(box-(box%4)),k=0;j<box;j++,k++)
				fprintf(f,"\tor [edi][%u*8][%u],%s\n",vals[j].rnd,vals[j].loc,freeregs[k]);
		}
		fprintf(f,"@@:\n");
		}
	}
	fprintf(f,"\tpop ebx\n\tpop edi\n\tpop esi\n\tpop ebp\n");
	fprintf(f,"\tret 1*4\n");
	fprintf(f,"DESSetKey endp\n");
	fprintf(f,"OPTION PROLOGUE:PROLOGUEDEF\n");
	fprintf(f,"OPTION EPILOGUE:EPILOGUEDEF\n");
	fclose(f);
}
