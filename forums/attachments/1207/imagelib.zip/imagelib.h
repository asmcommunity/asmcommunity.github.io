/*
** Ernest Murphy's Image Library
*/

HBITMAP BitmapFromFile(char *pszFileName);
HBITMAP BitmapFromMemory(void *pMemory, DWORD dwFileSize);
HBITMAP BitmapFromPicture(IPicture *pPicture);
HBITMAP BitmapFromResource(HINSTANCE hModule, DWORD ResNumber);
