Many thanks to Chetnik, member of Masm forum for his original work pemem
Also many thanks to Hutch for his file data assembler Fda.exe
The library PEmem is based on Chetnik's code

PEmem.exe	:	Running "PE from memory" demo ( Dialog.exe )
DLLmem.exe	:	Calling a function from "DLL from memory" demo ( Consfunc.dll )

LoadEXEfromMem PROC pEXE:DWORD

This functions loads a  PE / DLL from memory and does all the initializing procedures

	pEXE	:	pointer to the PE or DLL in memory

Return values :
	
	eax	:	entry point of the "virtual" PE / DLL

	edx	:	pointer to the PE / DLL loaded to the allocated memory
			eax holds a handle to the "virtual" PE / DLL

GetProcAddr PROC hModule:DWORD,func:DWORD

This function gets the adress of a function from a "virtual" DLL

	hModule	:	handle to the "virtual" DLL
			edx holds this value after a call to LoadEXEfromMem

Return values :

	eax	:	address of the "virtual" DLL's exported function "func"