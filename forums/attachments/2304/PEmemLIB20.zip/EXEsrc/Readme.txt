- PE with binary resource template :
  PE with resource section cannot be loaded with LoadEXEfromMem
- Rsrc.bin extracted with res2bin
- The object file need to be linked with /FIXED:NO option to have a relocation section
- The PE should return to the main application with a RET instruction, not with ExitProcess