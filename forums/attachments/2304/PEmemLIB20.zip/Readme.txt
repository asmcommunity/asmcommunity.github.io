PEmem.lib to load and run EXEs and DLLs in memory V2.0
======================================================

Many thanks to Chetnik, member of Masm forum for his original pemem project

The library PEmem is based on Chetnik's methode :

PEmem.exe	:	Running "PE in memory" demo ( Dialog.exe )
DLLmem.exe	:	Calling a function from "DLL in memory" demo ( ConsoleOut.dll )

LoadEXEfromMem PROC pEXE:DWORD,pEntry:DWORD

This functions loads a virtual PE / DLL in memory

	pEXE	:	pointer to the PE or DLL in memory
	pEntry	:	pointer receiving the entry point

Return values :
	
	eax	:	handle to the virtual module

FreeEXEfromMem PROC hModule:DWORD

	hModule	:	pointer to the virtual PE / DLL in memory

GetProcAddr PROC hModule:DWORD,func:DWORD

This function gets the adress of a function from a "virtual" DLL

	hModule	:	handle to the "virtual" DLL

Return values :

	eax	:	address of the "virtual" DLL's exported function "func"