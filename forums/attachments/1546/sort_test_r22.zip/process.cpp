#define WIN32_LEAN_AND_MEAN
#include <windows.h>

static bool		boosted = false;	// are we currently priority boosted?
static DWORD	opc;				// old priority class
static DWORD	otp;				// old thread priority


void priorityboost()
{
	if(boosted) return;
	opc = GetPriorityClass(GetCurrentProcess());
	otp = GetThreadPriority(GetCurrentThread());

	SetPriorityClass(GetCurrentProcess(), REALTIME_PRIORITY_CLASS);
	SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL);
	boosted = true;
}


void prioritynormal()
{
	if(!boosted) return;
	boosted = false;

	SetPriorityClass(GetCurrentProcess(), opc);
	SetThreadPriority(GetCurrentThread(), otp);
}


void processyield()
{
	Sleep(0);
//	SwitchToThread();
}
