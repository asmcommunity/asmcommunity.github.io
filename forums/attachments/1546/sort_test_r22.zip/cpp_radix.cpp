/* Copyright (C) David Garcia 2006
 * THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND.
 * You may copy, distribute and create derivative works of it as you want.
 */
#include <assert.h>

/* Counting sort for 4-byte unsigned integers.
 * This implementation tries to be as easy to understand as possible even
 * when that means some performance penalties.
 *
 * Preconditions:
 *     * the unsigned data type must be 4 bytes long
 *     * 'input' must be an array of size 'length'
 *     * 'output' must be an array of size 'length'
 *     * 'SHIFT' must be one of [0,8,16,24]
 * Postconditions:
 *     * 'output' contains all the elements in 'input'
 *     * the elements in 'output' are sorted in increasing order according
 *       to the SHIFT/8 byte
 *     * this sort is stable
 */
template <unsigned SHIFT>
inline static void radix_sort_helper(const unsigned input[/*length*/], const unsigned length,
        unsigned output[/*length*/], unsigned count[/*256*/])
{
        register unsigned i, bucket;
        register const unsigned MASK= 0xFF;

        // Initialise count (could have used memset instead)
        for(i=0; i < 256; ++i) {
                count[i]= 0;
        }

        // Count how many elements lie in each bucket
        for(i=0; i < length; ++i) {
                bucket= (input[i]>>SHIFT)&MASK;
                assert( bucket < 256 );
                count[bucket]++;
                assert( count[bucket] <= length );
        }

        // Count how many elements lie in each bucket or the buckets before it
        for(i=1; i < 256; ++i) {
                count[i]+= count[i-1];
                assert( count[i] <= length );
        }

        // Store each element in sorted order
        for(i=length-1; i < length; --i) {
                bucket= (input[i]>>SHIFT)&MASK;
                assert( bucket < 256 );
                assert( count[bucket] > 0 );
                // ...updating the counter for the next element that lies in this bucket
                count[bucket]--;
                assert( count[bucket] < length );
                output[count[bucket]]= input[i];
        }
}

/* Radix sort for 4-byte unsigned integers.
 * This implementation tries to be as easy to understand as possible even
 * when that means some performance penalties.
 *
 * Preconditions:
 *     * the unsigned data type must be 4 bytes long
 *     * 'array' must be an array of size 'length'
 * Postconditions:
 *     * the elements in 'array' are sorted in increasing order
 */
extern "C" void __stdcall cpp_radix(unsigned array[/*length*/], const unsigned length)
{
        // Note that we must allocate a temporal array as long as the input,
        // whereas quicksort and others sort in place.
        unsigned* temporal= new unsigned[length];
        unsigned count[256];
        // Call the helper four times, one for each byte.
        // Note that the input and output are swapped in each call
        radix_sort_helper<0>(array, length, temporal, count);
        radix_sort_helper<8>(temporal, length, array, count);
        radix_sort_helper<16>(array, length, temporal, count);
        radix_sort_helper<24>(temporal, length, array, count);
        delete[] temporal;
}
