typedef unsigned int TheType;

static void swap(TheType* a, unsigned l, unsigned r)
{
	TheType tmp = a[l];
	a[l] = a[r];
	a[r] = tmp;
}

static void qSort(TheType* a, unsigned l, unsigned r)
{
	const int M = 50;
	unsigned i, j;
	TheType v;

	if ((int)(r-l)>M)
	{
		i = (r+l)/2;
		if (a[l] > a[i]) swap(a, l, i);
		if (a[l] > a[r]) swap(a, l, r);
		if (a[i] > a[r]) swap(a, i, r);

		//if ((r-l)==1) return;// uncomment

		j = r - 1;
		swap(a, i, j);
		i = l;
		v = a[j];
		for(;;)
		{
			while(a[++i] < v);
			while(a[--j] > v);

			if (j < i) break;
			swap (a, i, j);
		}

		swap(a, i, r-1);
		qSort(a, l, j);
		qSort(a, i+1, r);
	}
}


static void iSort(TheType* a, unsigned l, unsigned r)
{
	unsigned i, j;
	TheType v;

	for (i=l+1; i<=r; i++)
	{
		v = a[i];
		j = i;
		while ((j>l) && (a[j-1]>v))
		{
			a[j] = a[j-1];
			j--;
		}
		a[j] = v;
	}
}

extern "C" void __stdcall trimedian_qSort(TheType* array, unsigned size)
{
	qSort(array,0,size);
	iSort(array,0,size);// comment
}
