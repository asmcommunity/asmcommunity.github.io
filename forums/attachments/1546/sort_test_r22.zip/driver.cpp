#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <algorithm>

const unsigned NUM_VALUES = 1024*1024*10;
const unsigned SEED = 0xBEEFF00D;

typedef unsigned int TheType;

#define lengthof(x) (sizeof(x)/sizeof(x[0]))

// from asm_qsort.asm
extern "C" __stdcall asm_qsort(TheType *values, unsigned left, unsigned right);

// from c_qsort.cpp
extern "C" void __stdcall trimedian_qSort(TheType* array, unsigned size);

// from asm_radix.asm
extern "C" void __stdcall RadixSortUint32(TheType *values, unsigned num);

// from cpp_radix.cpp
extern "C" void __stdcall	cpp_radix(unsigned array[/*length*/], const unsigned length);


// from "process.cpp"
void priorityboost(void);
void prioritynormal(void);

// local prototypes
void __stdcall	func_asm(TheType *values, unsigned num);
void __stdcall	func_libc(TheType *values, unsigned num);
void __stdcall	func_trimedian(TheType *values, unsigned num);
void __stdcall	func_stl(TheType *values, unsigned num);
void __stdcall	func_asm_radix(TheType *values, unsigned num);
void __stdcall	func_cpp_radix(TheType *values, unsigned num);

typedef void (__stdcall *Func)(TheType*,unsigned);

struct Routine
{
	const char	*name;
	Func		func;	
};

Routine	routineList[] =
{
	{ "libc qsort()",				&func_libc },
	{ "hutch asm qsort()",			&func_asm },
	{ "C trimedian qsort()",		&func_trimedian },
	{ "STL std::sort()",			&func_stl },
	{ "r22 FASM RADIX sort()",		&func_asm_radix },
	{ "David Garcia C++ radix()",	&func_cpp_radix }
};

void test_speed(TheType *sorted, TheType *unsorted)
{
	for(unsigned i=0; i<lengthof(routineList); i++)
	{
		DWORD	tick;

		memcpy(sorted, unsorted, NUM_VALUES * sizeof(*sorted));
		priorityboost();
		tick = GetTickCount();
		routineList[i].func(sorted, NUM_VALUES);
		tick = GetTickCount() - tick;
		prioritynormal();

		printf("%s took %d ticks\n", routineList[i].name, tick);
	}
}

void test_correct(TheType *sorted, TheType *unsorted)
{
	for(unsigned i=0; i<lengthof(routineList); i++)
	{
		printf("testing routine %s\t\t", routineList[i].name);
		fflush(stdout);

		memcpy(sorted, unsorted, NUM_VALUES * sizeof(*sorted));
		routineList[i].func(sorted, NUM_VALUES);

		for(unsigned j=1; j<NUM_VALUES; j++)
		{
			if(sorted[j-1] > sorted[j])
			{
				printf("failed at index %d (%d > %d)", j, sorted[j-1], sorted[j]);
				break;
			}
		}
		printf("\n");
	}
}


int main()
{
	TheType	*unsorted, *sorted;

	unsorted = new TheType[NUM_VALUES];
	sorted = new TheType[NUM_VALUES];

	srand(SEED);
	for(unsigned i=0; i<NUM_VALUES; i++)
	{
		unsorted[i] = rand();
	}

	printf("sorting test - sorting %d signed numbers, using seed 0x%08X\n\n", NUM_VALUES, SEED);
	
	printf("*** testing for correctness\n");
	test_correct(sorted, unsorted);
	printf("\n*** testing for SPEED\n");
	test_speed(sorted, unsorted);

	delete[] sorted;
	delete[] unsorted;
}


static void __stdcall	func_asm(TheType *values, unsigned num)
{
	asm_qsort(values, 0, num-1);
}

static int libc_compare(const void *arg1, const void *arg2)
{
	const TheType *n1 = static_cast<const TheType*>(arg1);
	const TheType *n2 = static_cast<const TheType*>(arg2);

	return(*n1 - *n2);
}

static void __stdcall	func_libc(TheType *values, unsigned num)
{
	qsort(values, num, sizeof(*values), libc_compare);
}

static void __stdcall	func_trimedian(TheType *values, unsigned num)
{
	trimedian_qSort(values, num);
//	c_qsort(values, 0, num-1);
}

static void __stdcall	func_stl(TheType *values, unsigned num)
{
	std::sort(&values[0], &values[num]);
}

static void __stdcall	func_asm_radix(TheType *values, unsigned num)
{
	RadixSortUint32(values, num);
}

static void __stdcall	func_cpp_radix(TheType *values, unsigned num)
{
	cpp_radix(values, num);
}
