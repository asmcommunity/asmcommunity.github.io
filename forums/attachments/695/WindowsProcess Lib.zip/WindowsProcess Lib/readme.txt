WindowsProcess Library 1.0
--------------------------
This library contains useful functions that let you play around with Windows Processes. All you need is
a listbox on your Window that'll be used to display the processes. You can display and kill processes. 
Enjoy!!! View Include-file and source for details!

For comments and suggestions mail me at profdracula@f-m.fm

-Prof. DrAcULA
