#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <pdh.h>

#include <stdio.h>

typedef unsigned __int64 u64;

/*
Ugly code coming up :)

GetPerformanceValue tries to retrieve a system performance counter as a 64bit integer.
Returns true on success, as well as counter value in output paremeter "value".
Returns false on error, and leaves value as-is.

Requires NT4 or better, for 9x... well, whatever.
*/
bool GetPerformanceValue(const char* szCounterName, u64& value)
{
    PDH_STATUS status;
    HQUERY hQuery;
    HCOUNTER hCounter;
    PDH_FMT_COUNTERVALUE cv;

    status = PdhOpenQuery(0, 0, &hQuery);
    if (ERROR_SUCCESS != status)
		return false;

    status = PdhAddCounter(hQuery, szCounterName, 0, &hCounter);
    if (ERROR_SUCCESS != status)
	{
		PdhCloseQuery(hQuery);
		return false;
	}

	status = PdhCollectQueryData(hQuery);
    if (ERROR_SUCCESS != status)
	{
		PdhCloseQuery(hQuery);
		return false;
	}

	status = PdhGetFormattedCounterValue(hCounter, PDH_FMT_LARGE | PDH_FMT_NOSCALE, 0, &cv);
    if (ERROR_SUCCESS != status)
	{
		PdhCloseQuery(hQuery);
		return false;
	}

	PdhCloseQuery(hQuery);

	value = cv.largeValue;
	return true;
}



void PrintTime64(unsigned time)
{
	unsigned secs  = time % 60;	time /= 60;
	unsigned mins  = time % 60;	time /= 60;
	unsigned hours = time % 24;	time /= 24;
	unsigned days  = time;

	char	buf[128];
	wsprintf(buf, "%d days, %d hours, %d minutes, %d seconds\n", days, hours, mins, secs);
	MessageBox(0, buf, "System Uptime", MB_OK);
/*
	printf();
*/
}


int main()
{
	u64 uptime;

	if(!GetPerformanceValue("\\System\\System Up Time", uptime))
	{
		MessageBox(0, "Couldn't get system uptime\n", "Error", MB_OK);
		return -1;
	}

	PrintTime64(uptime);
	return 0;
}

void entry()
{
	ExitProcess(main());
}
