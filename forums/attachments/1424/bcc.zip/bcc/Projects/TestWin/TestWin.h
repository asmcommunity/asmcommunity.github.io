#define IDI_MAINICO	            100
