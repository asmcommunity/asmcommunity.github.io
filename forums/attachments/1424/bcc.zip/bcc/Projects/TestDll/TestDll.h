
extern "C" __declspec(dllexport) BOOL _stdcall DllFun();
