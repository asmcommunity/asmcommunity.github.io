import java.applet.*;
import java.awt.Graphics;
import java.awt.Image;

public class test extends Applet  {
  private Image img1, img2;

  public test() {
  }

  public void start() {

  }

  public void stop() {

  }

  public void paint(Graphics g) {

    // paint the images
    g.drawImage(img1, 0, 0, 266, 200, null);
    g.drawImage(img2, 266, 200, 266, 200, null);
  }

  public void init() {
    Image tmp1, tmp2;
    Graphics tg1, tg2;

    // load the images
    tmp1 = getImage(getDocumentBase(), "b.png");
    tmp2 = getImage(getDocumentBase(), "c.jpg");

    // create new images
    img1 = createImage(533, 400);
    img2 = createImage(533, 400);

    // copy the loaded images onto the created ones
    tg1 = img1.getGraphics();
    tg2 = img2.getGraphics();
    tg1.drawImage(tmp1, 0, 0, this);
    tg2.drawImage(tmp2, 0, 0, this);
  }
}
