#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>

#define VERSION		"1.0"

typedef unsigned char u8;
typedef unsigned int u32;
typedef void (*dumpproc_t)(u8 *buf, u32 len);


void dump_c(u8 *buf, u32 len);
void dump_c2(u8 *buf, u32 len);
void dump_asm(u8 *buf, u32 len);


int main(int argc, char* argv[])
{
	HANDLE	hFile;
	HANDLE	hMap;
	void	*ptr;
	u32		fsize;
	dumpproc_t	dumper;

	if(argc<3)
	{
		printf( "bin2h version " VERSION " by f0dder - http://f0dder.reteam.org\n"
				"  Usage: bin2h file <mode>\n  where <mode> can be one of a,c,s (asm, c, c-string).\n");
		return 1;
	}

	switch(toupper(*argv[2]))
	{
	case 'A': dumper = dump_asm;	break;
	case 'C': dumper = dump_c;		break;
	case 'S': dumper = dump_c2;		break;

	default:
		printf("Unknown mode '%s'\n", argv[2]);
		return 1;
	}

	hFile = CreateFile(argv[1], GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL|FILE_FLAG_SEQUENTIAL_SCAN, NULL);
	if(hFile == INVALID_HANDLE_VALUE)
	{
		printf("error opening `%s'\n", argv[1]);
		return 1;
	}

	fsize = GetFileSize(hFile, NULL);
	if(fsize == 0)
	{
		printf("Sorry, but this utility will not work on 0-byte files :)\n");
		return 1;
	}

	hMap = CreateFileMapping(hFile, NULL, PAGE_READONLY, 0, 0, NULL);
	if(hMap == NULL)
	{
		printf("error creating file mapping\n");
		return 1;
	}

	ptr = MapViewOfFile(hMap, FILE_MAP_READ, 0, 0, 0);
	if(ptr == NULL) {
		printf("error mapping view\n");
		return 1;
	}

	// time to dump the file
	dumper(static_cast<u8*>( ptr ), fsize);

	UnmapViewOfFile(ptr);
	CloseHandle(hMap);
	CloseHandle(hFile);

	return 0;
}


void dump_asm(u8 *buf, u32 len)
{
	printf("; converted %d (0%08Xh) bytes\n", len, len);

	printf("db\t");
	for(u32 i=0; i<len; i++)
	{
		printf("0%02Xh", buf[i]);
		if(i+1 < len)
		{
			if(i % 8 == 7)
				printf("\ndb\t");
			else
				printf(", ");
		}
	}
}


void dump_c(u8 *buf, u32 len)
{
	u32		i;

	printf("// converted %d (%08X) bytes\n", len, len);
	printf("unsigned char data[%d] = {\n\t", len);
	for(i=0; i<len; i++) {
		printf("0x%02X", buf[i]);
		if(i+1<len) printf(", ");
		if(i % 10 == 9) printf("\n\t");
	}

	printf("};\n");
}


void dump_c2(u8 *buf, u32 len)
{
	u32		i;

	printf("// converted %d (%08X) bytes\n", len, len);
	printf("unsigned char data[%d] = \n\t\"", len);
	for(i=0; i<len; i++) {
		printf("\\x%02X", buf[i]);
		if(i % 16 == 15) printf("\"\n\t\"");
	}

	printf("\";\n");
}
