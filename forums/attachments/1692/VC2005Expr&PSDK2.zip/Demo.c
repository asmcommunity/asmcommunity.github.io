#include <windows.h>

LRESULT CALLBACK WindowProcedure(HWND, UINT, WPARAM, LPARAM);

char String[]="VC++ 2005 Express";
char String2[]="Hello from Visual C++ 2005 Express Edition";
char szClassName[] = "VCExpressClass";
int WINAPI WinMain(HINSTANCE hThisInstance, HINSTANCE hPrevInstance, LPSTR lpszArgument,
int nFunsterStil)
{
    HWND hwnd;
    MSG uMsg;
    WNDCLASSEX wc;

    wc.hInstance = hThisInstance;
    wc.lpszClassName = szClassName;
    wc.lpfnWndProc = WindowProcedure;
    wc.style = CS_DBLCLKS;
    wc.cbSize = sizeof(WNDCLASSEX);

    wc.hIcon = LoadIcon(NULL, IDI_APPLICATION);
    wc.hIconSm = LoadIcon(NULL, IDI_APPLICATION);
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.lpszMenuName = NULL; /* No menu */
    wc.cbClsExtra = 0;
    wc.cbWndExtra = 0;

    wc.hbrBackground = (HBRUSH) GetStockObject(BLACK_BRUSH);

    if(!RegisterClassEx(&wc)) return 0;

    hwnd = CreateWindowEx(
        0,
        szClassName,
        "Visual C++ 2005 Express & Platform SDK",
        WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT,
        CW_USEDEFAULT,
        600,
        450,
        HWND_DESKTOP,
        NULL,
        hThisInstance,
        NULL
                        );

        ShowWindow(hwnd, SW_SHOWNORMAL);

        while(GetMessage(&uMsg, NULL, 0, 0))
        {

                DispatchMessage(&uMsg);
        }

        return uMsg.wParam;
        }

        LRESULT CALLBACK WindowProcedure(HWND hwnd, UINT message, WPARAM wParam,
        LPARAM lParam)
        {
            PAINTSTRUCT ps;
			HDC hdc;
			SYSTEMTIME st;
			WORD temp;
			COLORREF c;
			int i;
			HFONT h;
			HGDIOBJ hfont;
			switch (message) {
            case WM_DESTROY:
            PostQuitMessage(0);
            break;
			case WM_PAINT:
			hdc=BeginPaint(hwnd,&ps);
			GetSystemTime(&st);
			for (temp=0;temp<st.wMilliseconds;temp++)
				rand();
			for (i=0;i<500;i++)
				{
				c=RGB(rand() % 255 , rand() % 255 , rand() % 255) ;
				SetTextColor(hdc,c);
				c=RGB(0,0,0);
				SetBkColor(hdc,c);
				TextOut(hdc,rand() % 600,rand() % 450,String,-1+sizeof(String));
				}
				h=CreateFont(30,10,0,0,400,0,0,0,OEM_CHARSET,
                            OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,
                            DEFAULT_QUALITY,DEFAULT_PITCH | FF_SCRIPT,
							"arial");
                hfont=SelectObject(hdc,h);
				c=RGB(0,0,0);
				SetTextColor(hdc,c);
				c=RGB(255,255,255);
				SetBkColor(hdc,c);
				TextOut(hdc,90,175,String2,-1+sizeof(String2));
				SelectObject(hdc,hfont);

				EndPaint(hwnd,&ps);

			break;
            default:
            return DefWindowProc(hwnd, message, wParam, lParam);
            }
            return 0;
            }


