#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#include <stdlib.h>
#include <stdio.h>


// Dummy function - causes {p1,p2} to be pushed to stack, and makes insertion point
// easy to locate. Actual call to this routine will be removed when hand-recoding, though.
//
extern "C" void __stdcall push_to_stack(unsigned,unsigned);


// The following are declared extern to make sure they're not optimized away by the
// compiler. 
//
extern "C" char*	g_cmdline_block;	// tokenized version of GetCommandLine()
extern "C" char**	g_cmdline_args;		// pointers into g_cmdline_block
extern "C" unsigned	g_cmdline_argcount;	// number of commandline args


extern "C" void __stdcall parse(char *input)
{
	unsigned totalbytes = 0;
	unsigned p1 = 0, p2;

	while(input[p1])
	{
		// skip whitespace
		while(input[p1] == ' ') p1++;
		if(!input[p1]) break;
		
		if(input[p1] == '\"')
		{
			// in quotes, consume until endquote
			p2 = ++p1;
			while( input[p2] && (input[p2] != '\"')) p2++;
		} else 
		{
			// not in quotes, consume until quote or whitespace
			p2 = p1+1;
			while( input[p2] && (input[p2] != '\"') && (input[p2] != ' ') ) p2++;
		}

		if(p2>p1)
		{
			push_to_stack(p1, p2);
			totalbytes += (p2-p1+1); // +1 because of NUL terminator
			g_cmdline_argcount++;
		}
		p1 = p2+1;
	}

	g_cmdline_args =  static_cast<char**>( malloc(g_cmdline_argcount * 4) );
	g_cmdline_block = static_cast<char*> ( malloc(totalbytes) );

	// now is the time to fill g_cmdline_block and g_cmdlineargs from the values previously
	// stored on stack (the dummy push_to_stack() call). This has to be handcoded in asm.	
}


int main()
{
	parse(GetCommandLine());
//	MessageBox(0, GetCommandLine(), "lala", MB_OK);
}
