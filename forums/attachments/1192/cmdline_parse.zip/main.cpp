#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#include <stdio.h>

extern "C" void __stdcall cmdline_init(const char *input);
extern "C" unsigned g_cmdline_argcount;
extern "C" char*	g_cmdline_block;
extern "C" char**	g_cmdline_args;

int main()
{
	cmdline_init(GetCommandLine());

	for(unsigned i=0; i<g_cmdline_argcount; i++)
	{
		printf("Arg %d == <%s>\n", i, g_cmdline_args[i]);
	}
}
