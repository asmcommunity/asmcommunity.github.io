PackBitmap.exe - compresses a 24-bit .bmp  or 32-bit uncompressed .tga into an ILB symbol in a separate .lib file. Requires the MASM32 package. 

PackToILB.exe - like above, but doesn't require MASM32, and generates an .ilb file. 

FontMaker.exe - creates an sDraw font, prints its data into VKDebug (from MASM32) in asm format. Put that text in an .inc file. 