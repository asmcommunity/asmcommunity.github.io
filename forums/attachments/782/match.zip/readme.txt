==========================================================
Match                                        July 13, 2002
Version 1.0                                       0:00 EST
Coded by comrade
==========================================================
This is an example of a case-sensitive match routine.
==========================================================
This program  comes  with  absolutely  no  warranty of any
kind. Use this program solely  at your risk. The author of
this  program  will  not  be   held  responsible  for  any
damages caused by this program.
==========================================================
  E-mail: comrade2k@hotmail.com
Homepage: http://euro.comrade64.com/
          http://comrade64.cjb.net/
          http://comrade.ownz.com/
          http://comrade.win32asm.com/
          http://comrade.hpacv.dk/
          http://www.comrade64.com/
     IRC: #asm, #coders, #win32asm on EFnet
==========================================================