#include <windows.h>

int custom_startup(void)
{
	return MessageBox(
		NULL, 
		"1024 bytes\n"
		"The smallest possible executable", 
		"Small enough?", MB_OK);
}


