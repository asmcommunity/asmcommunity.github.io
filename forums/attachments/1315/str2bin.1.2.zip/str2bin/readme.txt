str2bin
in:
pstr - pointer to $-terminated string with number
pwr -  base to encode
out:
ax - value (if ok)
cf - 0 if ok, 1 if fail

bin2str
in:
pstr - pointer to "$" char, ending text buffer
pwr -  base to decode
ax -   number to decode
out:
ax -   pointer to the start of decoded number

you can use 2 for binary, 10 for decimal and 16 for hex
if you wish, you may use other digits. tested only with 
10 (i'm harry)