import java.applet.*;
import java.awt.Graphics;
import java.awt.Image;
import javax.swing.ImageIcon;

public class test extends Applet  {
  private boolean AreImagesLoaded = false;
  private Image img1, img2;
  private Image tmp1, tmp2;
  private Graphics tg1, tg2;


  public test() {
    //super();
  }

  public void start() {

  }

  public void stop() {

  }

  public void paint(Graphics g) {

    if(!AreImagesLoaded){
      // create new images
      img1 = createImage(533, 400);
      img2 = createImage(533, 400);

      // copy the loaded images onto the created ones
      tg1 = img1.getGraphics();
      tg2 = img2.getGraphics();
      tg1.drawImage(tmp1, 0, 0, null);
      tg2.drawImage(tmp2, 0, 0, null);
      AreImagesLoaded=true;
    }

    // paint the images
    g.drawImage(img1, 0, 0, 266, 200, null);
    g.drawImage(img2, 266, 200, 266, 200, null);
    g.fillRect(10,10,10,10);
  }

  public void init() {
    // load the images
    tmp1 = getImage(getCodeBase(), "/b.png");
    tmp2 = getImage(getCodeBase(), "/c.jpg");

  }
}
