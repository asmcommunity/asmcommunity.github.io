#pragma comment(lib,"RWLock.lib")

#ifdef __cplusplus
extern "C" {
#endif


typedef long RWLOCK; // 4 bytes
/*typedef struct{
	char locker1;
	char numWriters;
	unsigned short numReaders;
}RWLOCK;
the C/C++ could make this struct 8 bytes, at least on default settings..
*/



#ifndef bool
	#define bool int
#endif


void __stdcall RWLock_Init(RWLOCK* pRWL);
void __stdcall RWLock_Free(RWLOCK* pRWL);

void __stdcall RWLock_StartRead(RWLOCK* pRWL);
void __stdcall RWLock_EndRead(RWLOCK* pRWL);

void __stdcall RWLock_StartWrite(RWLOCK* pRWL);
void __stdcall RWLock_EndWrite(RWLOCK* pRWL);
void __stdcall RWLock_EndAccess(RWLOCK* pRWL);

bool __stdcall RWLock_TryStartRead(RWLOCK* pRWL);
bool __stdcall RWLock_TryStartWrite(RWLOCK* pRWL);


void __stdcall RWLock_UpgradeToWriter(RWLOCK* pRWL);
void __stdcall RWLock_DowngradeToReader(RWLOCK* pRWL);

void RWLock_MultiStartWrite(int NumObjects,...);
void RWLock_MultiEndWrite(int NumObjects,...);


#ifdef __cplusplus




//============[ HELPER-CLASS ]=============================[
#ifndef RWLock
class RWLock{
private:
	RWLOCK m_Lock;
public:
	RWLock(){	RWLock_Init(&m_Lock);}
	~RWLock(){	RWLock_Free(&m_Lock);}
	void StartRead(){	RWLock_StartRead(&m_Lock);}
	void StartWrite(){	RWLock_StartWrite(&m_Lock);}
	void EndRead(){		RWLock_EndRead(&m_Lock);}
	void EndWrite(){	RWLock_EndWrite(&m_Lock);}
	void EndAccess(){	RWLock_EndAccess(&m_Lock);}
	bool TryStartRead(){	return RWLock_TryStartRead(&m_Lock);}
	bool TryStartWrite(){	return RWLock_TryStartWrite(&m_Lock);}
	void UpgradeToWriter(){		RWLock_UpgradeToWriter(&m_Lock);}
	void DowngradeToReader(){	RWLock_DowngradeToReader(&m_Lock);}
};
#endif
//=========================================================/








}
#endif
