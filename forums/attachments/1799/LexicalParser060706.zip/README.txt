
How XASM works:
Essentially, XASM is a two-pass assembler.
However, the second pass may require more than one iteration,
depending on the complexity of the sourcecode.

Pass One:
During the first pass, the entire sourcecode is parsed,
and all Terms [1] are 'Tokenized'.
XASM performs some basic grammar checks at this time,
and may inject some special Tokens which identify
the Types of identifiable Terms.
The token streams produced by this process are
stored in one or more Virtual Segments [2].
The result is an object-based representation of the sourcecode.
Note that no effort is made to resolve [3] references
either forwards OR backwards, XASM simply collects
as much information as possible.. for example,
any Macro declarations are collected, but not interpreted.
Any Terms which cannot be identified immediately
are flagged as 'unknown Type', and collected into
a global list of 'unresolved Term Types' .. however,
if any of these Terms are able to be subsequently Typed,
then the matching entry in the 'Unknowns Collection'
is modified (rather than collecting all References to
each Unknown term and then correcting them all).
If at the end of this process any Terms remain Unknown,
a series of Errors are output and processing is halted.
 
Pass Two:
During the second pass, XASM begins constructing
a Binary representation of each Virtual Segment.
The first thing XASM does is interpret any instances
of declared Macros, and replaces them with a Tokenized
stream of operators in situ [4].
All references have been Typed, but not yet Resolved.
The process for construction of the Binary representation
begins with the resolution of Data elements, since these
are the simplest to resolve.
As for the Code elements, XASM attempts to identify
linear blocks of code which require NO resolution,
and delimits them with code elements that DO require
resolution, and notes the size (in Bytes) of each
linear block. Furthermore, the code elements requiring
resolution are tagged as either requiring an Offset 
or an Address, and any references to global Data variables
are immediately resolved.
The sizes of linear codeblocks allows the resolution of
the code elements which need Offsets.
The resolution of all Offset-related code elements
allows the resolution of fixed Addresses.

Once the resolution of all references is complete,
XASM can write the binary Segments to an OBJ file,
or alternatively, it can write them directly to an EXE
(no external Linker required).
In the former case, an EntryPoint is not required.
In the latter case, an EntryPoint MUST be specified
using the standard END [Label] syntax.

Footnotes:
[1] - a Term is a substring of a sourcecode statement.
[2] - a Virtual Segment is analogous to a Physical Segment,
	and amounts to a means of Partitioning the code and data.
[3] - Resolving a reference means determining its Offset or Address.
[4] - in situ means "in place".
