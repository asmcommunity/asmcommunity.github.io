This file is only for test the speed between Invoke a process or Thread this process.

My results are that Create thread are 3 times more slow than invoke..... or I am in the Wrong way.

Thanks to all -> http://board.win32asmcommunity.net/