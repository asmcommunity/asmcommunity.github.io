/*-------------------------------------------------------------------------
     
  MP3_to_WAV_to_Play.C  (poor code)-- Multimedia Windows
			       --------By G-Spider @2011
--------------------------------------------------------------------------*/
        
#include <windows.h>
#include <mmsystem.h>

#include "mpg123.h"

#pragma  comment(lib,"winmm.lib")
#pragma  comment(lib,"libmpg123-0.lib")

#define IDC_SCROLL          1000
#define IDC_TEXT            1001     
#define IDC_ONOFF           1002

static mpg123_handle  *mh;
       

BOOL CALLBACK DlgProc (HWND, UINT, WPARAM, LPARAM) ;
      
BOOL CALLBACK DlgProc (HWND, UINT, WPARAM, LPARAM) ;
      
TCHAR szAppName [] = TEXT ("Mp3Play") ;
        
int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance,PSTR szCmdLine, int iCmdShow)      
{
    if (-1 == DialogBox (hInstance, szAppName, NULL, DlgProc))   
    {        
       MessageBox (  NULL, TEXT ("This program requires Windows NT!"),szAppName, MB_ICONERROR) ;        
    }       
      return 0 ;      
}
void cleanup(mpg123_handle *mh)
{
	/* It's really to late for error checks here;-) */
	mpg123_close(mh);
	mpg123_delete(mh);
	mpg123_exit();
}

int MP3_Init(int  *channels,long *rate,DWORD *buffer_size)
{
	int  err  = MPG123_OK;
	int encoding = 0;
	
	err = mpg123_init();
	if( err != MPG123_OK || (mh = mpg123_new(NULL, &err)) == NULL  
	|| mpg123_open(mh, "test.mp3") != MPG123_OK   //*******NOTE!*******test file:  test.mp3  
	|| mpg123_getformat(mh, rate, channels, &encoding) != MPG123_OK )
	   
	{
		MessageBeep (MB_ICONEXCLAMATION) ;
                MessageBox (0, TEXT ("OpenFile Error : test.mp3  No Found!"), 0, MB_ICONEXCLAMATION | MB_OK) ;
		cleanup(mh);
		return -1;
	}

	if(encoding != MPG123_ENC_SIGNED_16)
	{ /* Signed 16 is the default output format anyways; it would actually by only different if we forced it.
	     So this check is here just for this explanation. */
		cleanup(mh);
		MessageBox (0, TEXT ("Error encoding!"), 0, MB_ICONEXCLAMATION | MB_OK) ;
		return -2;
	}
	/* Ensure that this output format will not change (it could, when we allow it). */
	mpg123_format_none(mh);
	mpg123_format(mh, *rate, *channels, encoding);
	*buffer_size = mpg123_outblock( mh );
	return 0;
}

        
int FillBuffer (unsigned char * pBuffer, DWORD buffer_size, DWORD *dwBufferLength)      
{       

	int  err  = MPG123_OK;
	int  done=0,sum=0;
	*dwBufferLength=0;
        
        while(sum<114)   //Wave_Buffer=buffer_size*114;
        {
            err = mpg123_read( mh, pBuffer+(*dwBufferLength), buffer_size, &done );
            
            if(err==MPG123_OK)
            {
                *dwBufferLength+=done;
                 sum++;
            }
            else
                break;
            
        }       
        return err;  //MPG123_OK or MPG123_DONE

}     

BOOL CALLBACK DlgProc (HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)       
{
        
           static BOOL           bShutOff, bClosing, bPlaying=FALSE ;       
           static HWAVEOUT       hWaveOut ;         
           static unsigned char *pBuffer1, *pBuffer2 ;//,*pBufferTmp,*pTmp=NULL;       
           static PWAVEHDR       pWaveHdr1, pWaveHdr2 ;        
           static WAVEFORMATEX   waveformat ;       
           //=========================================
          // static mpg123_handle  *mh;
           static int            channels;
           static long           rate;
           static DWORD         buffer_size;
           static DWORD         Wave_Buffer;
           DWORD                 TmpLen=0;
           //int i;
	   //=========================================

           switch (message)       
           {
        
           case   WM_INITDIALOG:
                  return TRUE ;               
           case   WM_COMMAND:     
                  switch (LOWORD (wParam))
                  {
                    case   IDC_ONOFF:
            // If turning on waveform, hWaveOut is NULL
          if (hWaveOut == NULL)
          {
                 if(bPlaying==FALSE)
                {
                    if(MP3_Init(&channels,&rate,&buffer_size))
                    {
                        EndDialog (hwnd, 0) ;
                        return TRUE ; 
                    }
			        Wave_Buffer=buffer_size*114;//******
                  
          
                    // Allocate memory for 2 headers and 2 buffers
                    pWaveHdr1     = malloc (sizeof (WAVEHDR)) ;
                    pWaveHdr2     = malloc (sizeof (WAVEHDR)) ;
                    pBuffer1 = (unsigned char *)malloc (Wave_Buffer) ;
                    pBuffer2 = (unsigned char *)malloc (Wave_Buffer) ;
                    //pBufferTmp = (unsigned char *)malloc (Wave_Buffer) ;
                 if (!pWaveHdr1 || !pWaveHdr2 || !pBuffer1 || !pBuffer2 )
                  {
                
                         if (!pWaveHdr1) free (pWaveHdr1) ;           
                         if (!pWaveHdr2) free (pWaveHdr2) ;   
                         if (!pBuffer1)  free (pBuffer1) ;
                         if (!pBuffer2)  free (pBuffer2) ;           
                         MessageBeep (MB_ICONEXCLAMATION) ;
                         MessageBox (hwnd, TEXT ("Error allocating memory!"), szAppName, MB_ICONEXCLAMATION | MB_OK) ;
                         return TRUE ;  
                }
       }    

    // Open waveform audio for output 
    ZeroMemory(&waveformat, sizeof(waveformat));            
    waveformat.wFormatTag      = WAVE_FORMAT_PCM ;    
    waveformat.nChannels       = channels ;    
    waveformat.nSamplesPerSec  = rate ;
    waveformat.wBitsPerSample  = 16 ;  
    waveformat.nBlockAlign     = waveformat.nChannels * waveformat.wBitsPerSample / 8;    
    waveformat.nAvgBytesPerSec = waveformat.nSamplesPerSec * waveformat.nBlockAlign;
    waveformat.cbSize          = 0 ;

    if (waveOutOpen(&hWaveOut, WAVE_MAPPER, &waveformat,(DWORD)hwnd, 0, CALLBACK_WINDOW)!= MMSYSERR_NOERROR)      
    {     
         free (pWaveHdr1) ;  
         free (pWaveHdr2) ;
         free (pBuffer1) ;  
         free (pBuffer2) ;
         hWaveOut = NULL ;  
         MessageBeep (MB_ICONEXCLAMATION) ;  
         MessageBox (hwnd, TEXT ("Error opening waveform audio device!"), szAppName, MB_ICONEXCLAMATION | MB_OK) ;     
        return TRUE ;      
    }

        // Set up headers and prepare them
        pWaveHdr1->lpData             = pBuffer1 ;      
        //pWaveHdr1->dwBufferLength     = buffer_size ;       
        pWaveHdr1->dwBytesRecorded    = 0 ;       
        pWaveHdr1->dwUser             = 0 ;       
        pWaveHdr1->dwFlags            = 0 ;       
        pWaveHdr1->dwLoops            = 1 ;        
        pWaveHdr1->lpNext             = NULL ;        
        pWaveHdr1->reserved           = 0 ;
            
        
        pWaveHdr2->lpData             = pBuffer2 ;        
        //pWaveHdr2->dwBufferLength     = buffer_size ;        
        pWaveHdr2->dwBytesRecorded    = 0 ;        
        pWaveHdr2->dwUser             = 0 ;        
        pWaveHdr2->dwFlags            = 0 ;        
        pWaveHdr2->dwLoops            = 1 ;        
        pWaveHdr2->lpNext             = NULL ;       
        pWaveHdr2->reserved           = 0 ;  
        
        
             // Variable to indicate Off button pressed
      bShutOff = FALSE;
      bPlaying = TRUE;      
                         
     }  
       // If turning off waveform, reset waveform audio
     else  
     {
       bShutOff = TRUE ;
       waveOutReset (hWaveOut) ; 
     } 
     return TRUE ; 
     } 
     break ;
      // Message generated from waveOutOpen call
     case   MM_WOM_OPEN:
                          SetDlgItemText (hwnd, IDC_ONOFF, TEXT ("Turn Off")) ;
                         // Send two buffers to waveform output device
                         
                          FillBuffer (pBuffer1,buffer_size,&(pWaveHdr1->dwBufferLength)) ;
                          waveOutPrepareHeader (hWaveOut, pWaveHdr1, sizeof (WAVEHDR)) ;//***************
                          
                          waveOutWrite (hWaveOut, pWaveHdr1, sizeof (WAVEHDR)) ;
                          FillBuffer (pBuffer2,buffer_size,&(pWaveHdr2->dwBufferLength)) ;
                          waveOutPrepareHeader (hWaveOut, pWaveHdr2, sizeof (WAVEHDR)) ;//************
                          waveOutWrite (hWaveOut, pWaveHdr2, sizeof (WAVEHDR)) ;
                          return TRUE ;
      // Message generated when a buffer is finished
      case   MM_WOM_DONE:
                          if (bShutOff)
                          {
                               waveOutReset (hWaveOut) ;
                               waveOutClose (hWaveOut) ;
                               return TRUE ;
                          }
                          
                          //for(i=0;i<(((PWAVEHDR) lParam)->dwBufferLength);i++) pBufferTmp[i]=((PWAVEHDR) lParam)->lpData[i];
                          
                          
                          // Fill and send out a new buffer
                          if((FillBuffer (((PWAVEHDR) lParam)->lpData,buffer_size,&(((PWAVEHDR) lParam)->dwBufferLength)))== MPG123_DONE 
                          && ( ((PWAVEHDR) lParam)->dwBufferLength==0 ))
                          {
                            bShutOff=TRUE;
                            bPlaying =FALSE ; //*******************
                            return TRUE ;
                          }
                          else
                          {
                            if( ((PWAVEHDR) lParam)->dwBufferLength!=Wave_Buffer  )//***********************
                             {   
                                waveOutPrepareHeader (hWaveOut, (PWAVEHDR) lParam, sizeof (WAVEHDR)) ;//***************
                             }
                            waveOutWrite (hWaveOut, (PWAVEHDR) lParam, sizeof (WAVEHDR)) ;
                            return TRUE ;
                          }
     case   MM_WOM_CLOSE:
                    if(bPlaying==FALSE)
                     {     waveOutUnprepareHeader (hWaveOut, pWaveHdr1, sizeof (WAVEHDR)) ;
                          waveOutUnprepareHeader (hWaveOut, pWaveHdr2, sizeof (WAVEHDR)) ;
        
                          free (pWaveHdr1) ;       
                          free (pWaveHdr2) ;   
                          free (pBuffer1) ;
                          free (pBuffer2) ;
                     }    
                          hWaveOut = NULL ;
                          SetDlgItemText (hwnd, IDC_ONOFF, TEXT ("Turn On")) ;
                          if (bClosing)
                          {
                             cleanup(mh);
                             EndDialog (hwnd, 0) ;
                          }
                    
                          return TRUE ;
     case   WM_SYSCOMMAND:
                          switch (wParam)
                          {
                                case SC_CLOSE:
                                        if (hWaveOut != NULL)
                                        {
                                           bShutOff = TRUE ;
                                           bClosing = TRUE ;
                                           waveOutReset (hWaveOut) ;
                                        }
                                        else
                                        {
                                            cleanup(mh);
                                            EndDialog (hwnd, 0) ;
                                        }
                                        return TRUE ;
                          }
                          break ;
           }
          return FALSE ;       
}//end DlgProc 