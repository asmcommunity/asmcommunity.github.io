
mp3 decoder->PCM->waveOut***->play (you need 3 files:libmpg123-0.dll ,MP3_Play.exe ,test.mp3)

---------------------------------
You can make it (static file) .
MinGW:

---------------------------------
gcc -c  mp3_play.c -Iinclude -Llib -lmpg123 -lwinmm

windres mp3_resource.rc resource.o

gcc mp3_play.o resource.o -Llib -lmpg123 -lwinmm -Wl,-subsystem,windows -o mp3_play.exe

./mp3.play.exe
----------------------------------