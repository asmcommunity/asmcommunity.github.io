Thanks to El_Choni for the corrections:

http://board.win32asmcommunity.net/viewtopic.php?t=10650