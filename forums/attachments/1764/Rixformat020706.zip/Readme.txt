Rix Format ASM 0.1 beta
-------------------------
MASM HLS textequ <"Masm High level Syntax"> ;)

What is it ?
	A dll for use in your asm editing prog.
	i believe it to be the only one of it kind!

Whats it do?
	It attempts to auto format MASM HLS source
	code to my asm standard writing style
	so i can read and use other people's sources
	easier

That's been done before!
-------------------------
TRUE,but never with any large amount of success(AFAIK).
I saw one old example that attempted to do it 'on the fly'
and as a result mashed up pretty bad 90% of the time!
I believe 'two-pass' formatting is defiantly the way
to go.....
The main problem is with attempting to format 'raw' asm
is that it's impossible to know what the programmer's
thinking with all those jne's and cmps!
however one can use a generic approach on MASM HLS
ie.
.if	= indent
.elseif = current pos-1 tab
.endif	= outdent

.etc

Whats it tested on?
-------------------
ALL ICZ TUTES -	norm
ALL ICZ TUTES -	pe file format
And load of other ive got from various
V.cool authors that released their
source code

few needed facts:
-----------------
1.	"FormatASM proc lptext:DWORD"
	eg. invoke FormatASM,addr buffer

2.	buffer is overwritten
3.	buffer should be big enough to accommidate changes
	(x2 should be good enuff!)

few un-needed facts:
1.	the truth of the matter is this was never intended
	for release due to the fact i intended to build a
	snippet browser incorperating this code and release
	that,however this seem to be the better idea since more peep's
	can make use of it!
2.	Since this is beta i've not opt'ed the string routines,yet!
	(Most run through lazy string macro's currently!)
	making it a little slow!
3.	I'd love to see someone write a wrapper around this for
	radasm,winasm.etc if people use it i'll release more often
	programmers love to be appreciated!!!
4.	Source will be released the second ive had enough of it,
	i hate wasted coding time!
5.	Feel free to reverse my code. RixFormat is a learning dll!
	Just credit me if ya use or improve it!!

known issues:
-------------
The first 2-3 lines may be formated incorrectly due to an intergral flaw 
in the engine core(which is due an overhaul soon promise !btw)
unmatched 'close block' instructions(endif/Endsw) can
cause the following text to be incorrectly
formated(but not corrupted!)

strange mixed case words aren't recognized
eg.
mycoolproc pRoC var:DWORD ; This will not format!

mycoolproc PROC var:DWORD ; This will format
mycoolproc proc var:DWORD ; This will format


other than that,in general if it assembles ok it'll format ok
-------------------------------------------
--	credits follow...
--------------------------------------------



THANX TO	THE IMMORTAL FRAVIA - orc+ planted the seed,you made it grow!
				   ( I never knew you, but good god i miss you! )
		ICZILLION 	- Same reason as everyone else who can code asm! ;-D
		KetilO		- You shame M$ every day i use rad!thx!

		and everybody else 'i LeArn'ED GOOD form!'
		hehe.
 rixsta.....
