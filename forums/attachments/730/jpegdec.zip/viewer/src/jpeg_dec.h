// Public include

// the structure returned by JPG_Decode()
typedef struct
{
    // width
    unsigned width;
    // height
    unsigned height;
    // scan length
    unsigned scanlength;
    // pointer to RGB data
    void* pRGB;
    // bits per pixel
    unsigned bitsPixel;
    // number of components
    unsigned Nf;
} JPEGIMAGE;

// prototypes
int __stdcall JPEG_Decode(char* bufIn, int size, JPEGIMAGE** pImg, int options);
void __stdcall JPEG_Free(JPEGIMAGE* pImg);

// error codes
enum
{
    // unexpected end of file
    JPEG_EOF = 0,
    // out of memory
    JPEG_OUTOFMEM,
    // no error
    JPEG_SUCCESS,
    // cpu not supported
    JPEG_CPUNOTSUPPORTED,
    // bad file
    JPEG_BADFILE,
    // format not supported
    JPEG_FORMATNOTSUPPORTED
};