#include <windows.h>
#include <winuser.h>
#include <commdlg.h>
#include <commctrl.h>

#include "resource.h"

#include "jpeg_dec.h"

// Constants
#define FIRST_MENU_ID ID_FILE_OPEN40001
#define MENU_OPEN (1 << 0)
#define MENU_CLOSE (1 << 1)
#define MENU_QUIT (1 << 2)

const char WINDOW_TITLE[] = "JPEG Viewer by Dr. Manhattan";
const char STATUS_INIT[] = "Ready";

// Global variable
struct
{
    HINSTANCE hinst;
    HWND hwnd, status;
    int statusHeight;
} wnd;

struct
{
    HDC dc;
    HBITMAP oldbm;
    int width, height;
    int dstX, dstY, dstWidth, dstHeight, srcX, srcY;
    int scrollX, scrollY;
} img;


// Function prototypes.
int WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int);
InitApplication(HINSTANCE);
InitInstance(HINSTANCE, int);
LRESULT CALLBACK MainWndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT OnCreate(HWND hwnd);
LRESULT OnPaint(HWND hwnd, WPARAM wParam, LPARAM lParam);
LRESULT OnSize(HWND hwnd, WPARAM wParam, LPARAM lParam);
LRESULT OnDestroy(void);
LRESULT OnScroll(HWND hwnd, WPARAM wParam, LPARAM lParam, int fnBar);
LRESULT OnCommand(HWND hwnd, WORD menuId, LPARAM lParam);
void OnFileOpen(void);
BOOL OnFileClose(void);
void OnFileQuit(void);
BOOL getFileName(void);
BOOL readFile(char* filename);
void* allocMem(int size);
void freeMem(void* mem);
BOOL newFileOpened(char* buffer, int size);
void freeBitmap(void);
void menuChange(unsigned set, unsigned reset);
HWND createStatusBar(HWND hwnd, HINSTANCE hinst);
void setStatusInfo(unsigned time, JPEGIMAGE* img);
void displayError(int code);
void setImagePos(int width, int height);

// Application entry point.
int WINAPI WinMain(HINSTANCE hinstance, HINSTANCE hPrevInstance,
                    LPSTR lpCmdLine, int nCmdShow)
{
    MSG msg;
    BOOL bRet = FALSE;
#ifdef _DEBUG
    /* dummy floating point operation to use sprintf */
    float f = 0.0;
#endif    

    if (InitApplication(hinstance))
    {
        if (InitInstance(hinstance, nCmdShow))
        {
            while ((bRet = GetMessage(&msg, (HWND) NULL, 0, 0)))
            {
                if (bRet != -1)
                {
                    DispatchMessage(&msg);
                }
            }
            bRet = TRUE;
        }
    }

    UNREFERENCED_PARAMETER(lpCmdLine);

    return bRet;
}

BOOL InitApplication(HINSTANCE hinstance)
{
    WNDCLASSEX wcx;

    // Fill in the window class structure with parameters
    // that describe the main window.
    
    // size of structure
    wcx.cbSize = sizeof(wcx);
    // redraw if size changes
    wcx.style = CS_HREDRAW | CS_VREDRAW;
    // points to window procedure
    wcx.lpfnWndProc = MainWndProc;
    // no extra class memory
    wcx.cbClsExtra = 0;
    // no extra window memory
    wcx.cbWndExtra = 0;
    // handle to instance
    wcx.hInstance = hinstance;
    // predefined app. icon
    wcx.hIcon = LoadIcon(NULL, IDI_APPLICATION);
    // predefined arrow
    wcx.hCursor = LoadCursor(NULL, IDC_ARROW);
    // white background brush
    wcx.hbrBackground = (HBRUSH) GetStockObject(WHITE_BRUSH);
    // name of menu resource
    wcx.lpszMenuName =  MAKEINTRESOURCE(IDR_MENU1);
    // name of window class
    wcx.lpszClassName = "MainWClass";  
    wcx.hIconSm = (HICON) LoadImage(hinstance,
                                    MAKEINTRESOURCE(5),
                                    IMAGE_ICON,
                                    GetSystemMetrics(SM_CXSMICON), 
                                    GetSystemMetrics(SM_CYSMICON), 
                                    LR_DEFAULTCOLOR); 

    // Register the window class. 
    return RegisterClassEx(&wcx); 
} 

BOOL InitInstance(HINSTANCE hinstance, int nCmdShow)
{
    HWND hwnd;
    BOOL ret = FALSE;
    RECT rect;

    // Save the application-instance handle.
    wnd.hinst = hinstance;

    // Create the main window.
    hwnd = CreateWindow("MainWClass",        // name of window class
                        WINDOW_TITLE,        // title-bar string
                        WS_OVERLAPPEDWINDOW | WS_VSCROLL | WS_HSCROLL, // top-level window
                        CW_USEDEFAULT,       // default horizontal position
                        CW_USEDEFAULT,       // default vertical position
                        CW_USEDEFAULT,       // default width
                        CW_USEDEFAULT,       // default height
                        (HWND) NULL,         // no owner window
                        (HMENU) NULL,        // use class menu
                        hinstance,           // handle to application instance
                        (LPVOID) NULL);      // no window-creation data
    if (hwnd)
    {
        // create status bar
        wnd.status = createStatusBar(hwnd, wnd.hinst);

        if (wnd.status)
        {
            if (GetClientRect(wnd.status, &rect))
            {
                wnd.statusHeight = rect.bottom;
            }
        }

        // hide scroll bar
        ShowScrollBar(wnd.hwnd, SB_BOTH, FALSE);

        // Show the window and send a WM_PAINT message to the window 
        // procedure. 
        ShowWindow(hwnd, nCmdShow);
        UpdateWindow(hwnd); 

        ret = TRUE;
    }

    return ret;
} 

HWND createStatusBar(HWND hwnd, HINSTANCE hinst)
{
    HWND statusWnd = NULL;
    INITCOMMONCONTROLSEX icc;
    icc.dwSize = sizeof(icc);
    icc.dwICC = ICC_BAR_CLASSES;
    if (InitCommonControlsEx(&icc))
    {
        statusWnd = CreateWindow(STATUSCLASSNAME,
                                 STATUS_INIT,
                                 WS_CHILD | WS_VISIBLE,
                                 0,
                                 0,
                                 0,
                                 0,
                                 hwnd,
                                 NULL,
                                 hinst,
                                 NULL);
    }
    return statusWnd;
}
    

// WndProc
LRESULT CALLBACK MainWndProc(HWND hwnd,        // handle to window
                            UINT uMsg,        // message identifier
                            WPARAM wParam,    // first message parameter
                            LPARAM lParam)    // second message parameter
{
    LRESULT ret = 0;
    switch (uMsg)
    {
        // Initialize the window.
        case WM_COMMAND:
            if (HIWORD(wParam) == 0)
            {
                ret = OnCommand(hwnd, LOWORD(wParam), lParam);
            }
        break;

        // Initialize the window.
        case WM_CREATE:
            ret = OnCreate(hwnd);
        break;

        // Paint the window's client area.
        case WM_PAINT:
            ret = OnPaint(hwnd, wParam, lParam);
        break;

        // Set the size and position of the window.
        case WM_SIZE:
            ret = OnSize(hwnd, wParam, lParam);
        break;

        // Clean up window-specific data objects.
        case WM_DESTROY:
            ret = OnDestroy();
        break;

        // horizontal scrolling
        case WM_HSCROLL:
            ret = OnScroll(hwnd, wParam, lParam, SB_HORZ);
        break;

        // vertical scrolling
        case WM_VSCROLL:
            ret = OnScroll(hwnd, wParam, lParam, SB_VERT);
        break;

        // Process other messages.
        default:
            ret = DefWindowProc(hwnd, uMsg, wParam, lParam);
    }
    return ret;
}

// OnCreate
LRESULT OnCreate(HWND hwnd)
{
    wnd.hwnd = hwnd;
    return 0;
}

// OnDestroy
LRESULT OnDestroy(void)
{
    PostQuitMessage(0);
    return 0;
}

// OnPaint
LRESULT OnPaint(HWND hwnd, WPARAM wParam, LPARAM lParam)
{
    HDC dc;
    PAINTSTRUCT ps;

    dc = BeginPaint(hwnd, &ps);
    if (dc)
    {
        if (img.dc)
        {            
            BitBlt(dc, img.dstX, img.dstY, img.dstWidth, img.dstHeight, img.dc, img.srcX, img.srcY, SRCCOPY);
        }
    }
    EndPaint(hwnd, &ps);
    SendMessage(wnd.status, WM_PAINT, wParam, lParam);
    return 0;
}

// OnSize
LRESULT OnSize(HWND hwnd, WPARAM wParam, LPARAM lParam)
{
    int newWidth, newHeight;
    
    if (wParam != SIZE_MINIMIZED)
    {
        if (img.dc)
        {
            newWidth = LOWORD(lParam);
            newHeight = HIWORD(lParam) - wnd.statusHeight;
            setImagePos(newWidth, newHeight);
        }
    }
    
    SendMessage(wnd.status, WM_SIZE, wParam, lParam);    
    return 0;
}

// vertical scrolling
LRESULT OnScroll(HWND hwnd, WPARAM wParam, LPARAM lParam, int fnBar)
{
    SCROLLINFO si;
    int pos;
    int deltaX, deltaY;
    RECT rect;
   
    // Get all the scroll bar information
    si.cbSize = sizeof (si);
    si.fMask  = SIF_ALL;
    GetScrollInfo(hwnd, fnBar, &si);
    
    // Save the position for comparison later on
    pos = si.nPos;
    switch (LOWORD(wParam))
    {
        // user clicked the top arrow
        case SB_LINEUP:
            si.nPos -= 1;
        break;

        // user clicked the bottom arrow
        case SB_LINEDOWN:
            si.nPos += 1;
        break;

        // user clicked the shaft above the scroll box
        case SB_PAGEUP:
            si.nPos -= si.nPage;
        break;

        // user clicked the shaft below the scroll box
        case SB_PAGEDOWN:
            si.nPos += si.nPage;
        break;

        // user dragged the scroll box
        case SB_THUMBTRACK:
            si.nPos = si.nTrackPos;
        break;

        default:
        break; 
    }

    // Set the position and then retrieve it.  Due to adjustments
    //   by Windows it may not be the same as the value set.
    si.fMask = SIF_POS;
    SetScrollInfo(hwnd, fnBar, &si, TRUE);
    GetScrollInfo(hwnd, fnBar, &si);
   
    // If the position has changed, scroll window and update it
    pos -= si.nPos;
    if (pos)
    {
        deltaX = deltaY = 0;
        if (fnBar == SB_VERT)
        {
            deltaY = pos;
            img.scrollY = si.nPos;
        }
        else
        {
            deltaX = pos;
            img.scrollX = si.nPos;
        }
        GetClientRect(wnd.hwnd, &rect);
        rect.bottom -= wnd.statusHeight;
        img.srcX = img.scrollX;
        img.srcY = img.scrollY;
        ScrollWindowEx(hwnd, deltaX, deltaY, &rect, &rect, NULL, NULL, SW_INVALIDATE);
        UpdateWindow(hwnd);
    }
    
    return 0;
}

// set image position
void setImagePos(int screenWidth, int screenHeight)
{    
    SCROLLINFO scroll;
    UINT wArrows;

    img.dstX = max((screenWidth - img.width) / 2, 0);
    img.dstY = max((screenHeight - img.height) / 2, 0);
    img.dstWidth = min(screenWidth, img.width);
    img.dstHeight = min(screenHeight, img.height);
    if (img.scrollX + img.dstWidth >= img.width)
        img.scrollX = img.width - img.dstWidth;
    if (img.scrollY + img.dstHeight >= img.height)
        img.scrollY = img.height - img.dstHeight;
    img.srcX = img.scrollX;
    img.srcY = img.scrollY;

    if (img.width <= screenWidth && img.height <= screenHeight)
    {
        ShowScrollBar(wnd.hwnd, SB_BOTH, FALSE);
    }
    else
    {
        scroll.cbSize = sizeof(scroll);
        scroll.fMask = SIF_RANGE | SIF_PAGE | SIF_POS;
        scroll.nMin = 0;
        wArrows = ESB_DISABLE_BOTH;
        if (img.width > screenWidth)
        {
            scroll.nMax = img.width;
            scroll.nPage = screenWidth;
            scroll.nPos = img.scrollX;
            SetScrollInfo(wnd.hwnd, SB_HORZ, &scroll, TRUE);
            wArrows = ESB_ENABLE_BOTH;
        }
        EnableScrollBar(wnd.hwnd, SB_HORZ, wArrows);
        wArrows = ESB_DISABLE_BOTH;
        if (img.height > screenHeight)
        {
            scroll.nMax = img.height;
            scroll.nPage = screenHeight;
            scroll.nPos = img.scrollY;
            SetScrollInfo(wnd.hwnd, SB_VERT, &scroll, TRUE);
            wArrows = ESB_ENABLE_BOTH;
        }
        EnableScrollBar(wnd.hwnd, SB_VERT, wArrows);
    }
}

// OnCommand
LRESULT OnCommand(HWND hwnd, WORD menuId, LPARAM lParam)
{
    switch (menuId)
    {
        case ID_FILE_OPEN40001:
            OnFileOpen();
        break;

        case ID_FILE_CLOSE40002:
            OnFileClose();
        break;

        case ID_FILE_QUIT:
            OnFileQuit();
        break;
    }

    return 0;
}

// File->Open
void OnFileOpen(void)
{
#define MAX_FILE_NAME 256
    char filename[MAX_FILE_NAME];
    OPENFILENAME ofn;
    
    ZeroMemory(&ofn, sizeof(ofn));

    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner = wnd.hwnd;
    ofn.lpstrFilter = "JPEG files\0*.jpg\0All files\0*.*\0\0\0";
    ofn.lpstrFile = & filename[0];
    filename[0] = 0;
    ofn.nMaxFile = sizeof(filename);
    ofn.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST;
    if (GetOpenFileName(&ofn))
    {
        if (readFile(filename))
        {
            SetWindowText(wnd.hwnd, &filename[ofn.nFileOffset]);
        }
    }
    else
    {
        if (CommDlgExtendedError())
        {
            MessageBox(wnd.hwnd, "Cannot create window to open file", "Error", MB_OK);
        }
    }
}

// File->Close
BOOL OnFileClose(void)
{
    freeBitmap();
    menuChange(0, MENU_CLOSE);
    SetWindowText(wnd.hwnd, WINDOW_TITLE);
    SetWindowText(wnd.status, STATUS_INIT);
    ShowScrollBar(wnd.hwnd, SB_BOTH, FALSE);
    ZeroMemory(&img, sizeof(img));
    InvalidateRect(wnd.hwnd, NULL, TRUE);

    return TRUE;
}

// File->Quit
void OnFileQuit(void)
{
    OnDestroy();
}

// read file in a buffer
BOOL readFile(char* filename)
{
    BOOL ret = FALSE;
    HANDLE hfile;
    BY_HANDLE_FILE_INFORMATION fileinfo;
    char* buffer = NULL;
    unsigned nbread;

    hfile = CreateFile(filename, GENERIC_READ, 
                        FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hfile != INVALID_HANDLE_VALUE)
    {
        if (GetFileInformationByHandle(hfile, &fileinfo))
        {
            if (fileinfo.nFileSizeHigh == 0)
            {
                buffer = (char*) allocMem(fileinfo.nFileSizeLow);
                if (buffer)
                {
                    if (ReadFile(hfile, buffer, fileinfo.nFileSizeLow, &nbread, NULL))
                    {
                        if (nbread == fileinfo.nFileSizeLow)
                        {
                            ret = newFileOpened(buffer, nbread);
                        }
                    }
                    freeMem(buffer);
                }
            }
        }

        CloseHandle(hfile);
    }

    return ret;
}

// allocate memory
void* allocMem(int size)
{
    return HeapAlloc(GetProcessHeap(), 0, size);
}

// free memory
void freeMem(void* mem)
{
    HeapFree(GetProcessHeap(), 0, mem);
}

// new file opened
BOOL newFileOpened(char* buffer, int size)
{
    BOOL ret = FALSE;
    int code = JPEG_FORMATNOTSUPPORTED;
    JPEGIMAGE* jimg;
    HDC cdc, wdc;
    BITMAPINFO bmi;
    BITMAPINFOHEADER* bmhdr;
    HBITMAP cbm, oldbm;
    unsigned time;
    RECT rect;

    // decode the buffer
    time = GetTickCount();
    code = JPEG_Decode(buffer, size, &jimg, 0);
    time = GetTickCount() - time;
    
    if (code == JPEG_SUCCESS)
    {        
        // copy the image in a dc
        wdc = GetDC(wnd.hwnd);
        if (wdc)
        {
            cdc = CreateCompatibleDC(wdc);
            if (cdc)
            {
                cbm = CreateCompatibleBitmap(wdc, jimg->width, jimg->height);
                if (cbm)
                {
                    bmhdr = & bmi.bmiHeader;
                    bmhdr->biSize = sizeof(*bmhdr);
                    bmhdr->biWidth = jimg->scanlength;
                    bmhdr->biHeight = - (int)jimg->height;
                    bmhdr->biPlanes = 1;
                    bmhdr->biBitCount = jimg->bitsPixel;
                    bmhdr->biCompression = BI_RGB;
                    if (SetDIBits(cdc, cbm, 0,
                                    jimg->height, jimg->pRGB, &bmi,
                                    DIB_RGB_COLORS) == jimg->height)
                    {
                        oldbm = (HBITMAP) SelectObject(cdc, cbm);
                        if (oldbm)
                        {
                            // free previous resource
                            OnFileClose();
                            img.oldbm = oldbm;
                            img.dc = cdc;
                            img.width = jimg->width;
                            img.height = jimg->height;
                            menuChange(MENU_CLOSE, 0);
                            setStatusInfo(time, jimg);
                            GetClientRect(wnd.hwnd, &rect);
                            setImagePos(rect.right, rect.bottom - wnd.statusHeight);
                            InvalidateRect(wnd.hwnd, NULL, TRUE);
                            ret = TRUE;
                        }
                    }
                }
            }
            ReleaseDC(wnd.hwnd, wdc);
        }
        // free the image
        JPEG_Free(jimg);
    }

    if (ret == FALSE)
    {
        if (code != JPEG_SUCCESS)
        {
            displayError(code);
        }
        else
        {
            MessageBox(wnd.hwnd, "Error", "can't allocate graphics object", MB_OK);
        }
    }

    return ret;
}

// free bitmap
void freeBitmap(void)
{
    HBITMAP hbm;
    if (img.dc)
    {
        hbm = (HBITMAP) SelectObject(img.dc, img.oldbm);
        if (hbm)
        {
            DeleteObject(hbm);
        }
        DeleteDC(img.dc);
        img.width = img.height = 0;
        img.dc = NULL;
    }    
}

// change menu
void menuChange(unsigned set, unsigned reset)
{
    UINT id;
    unsigned val[2];
    unsigned flags;
    unsigned i;
    UINT state;
    HMENU hmenu = GetMenu(wnd.hwnd);

    val[0] = set;
    val[1] = reset;
       
    if (hmenu)
    {
        state = MF_ENABLED;
        for (i = 0; i < 2; i++)
        {
            id = FIRST_MENU_ID;
            flags = val[i];
            while (flags)
            {
                if (flags & 1)
                {
                    EnableMenuItem(hmenu, id, state);
                }
                id++;
                flags >>= 1;
            }
            state = MF_GRAYED;
        }
    }
}

// set status info
void setStatusInfo(unsigned time, JPEGIMAGE* img)
{
    char buffer[256];
    int nb;
    char* str;
    if (time)
        str = "%dx%d - %s - %d bpp - %d ms";
    else
        str = "%dx%d - %s - %d bpp - < 1 ms";
    nb = wsprintf(buffer, str, img->width, img->width,
                  img->Nf == 1 ? "Grayscale" : "Color", img->bitsPixel, time);
    buffer[nb] = 0;
    SetWindowText(wnd.status, buffer);
}

// display error message
void displayError(int code)
{
    char* msg;
    
    switch (code)
    {
        case JPEG_EOF:
            msg = "unexpected end of file";
        break;
        case JPEG_OUTOFMEM:
            msg = "out of memory";
        break;
        case JPEG_CPUNOTSUPPORTED:
            msg = "cpu not supported";
        break;
        case JPEG_BADFILE:
            msg = "bad file";
        break;        
        case JPEG_FORMATNOTSUPPORTED:
            msg = "format not supported";
        break;
        default:
            msg = "unknown error code";
        break;
    }

    MessageBox(wnd.hwnd, msg, "Error", MB_OK);
}
