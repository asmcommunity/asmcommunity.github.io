lib2def V2.0
============

lib2def converts MS COFF import libraries to module definition files.

A typical output of lib2def :

lib2def kernel32.lib

LIBRARY kernel32
EXPORTS
"_ActivateActCtx@8"
"_AddAtomA@4"
"_AddAtomW@4"
.
.
etc.

A module definition file extracted by lib2def can be reconverted to the corresponding
MS COFF import libray with the usage of Pelle's librarian Polib.

For any comments, bug reports etc., you can contact me at :

vortex_1@hotmail.com

Vortex, August 2006