Gunners File Type Editor Version 3.1.4.6 - 6/19/10

This has come a long way from my first idea I had for an extension editor.  

What's new:
- Added edit DDE info
- Added extension count - Total/custom/user defined
- Added Admin Mode - Do everything normal mode does, but to system wide extesnions
    - When you delete an extension in this mode and a user customized extension, it not be deleted for user,
        instead it will be moved to user defined.
	- Edit system wide "Open With" list

*** To access Admin Mode, use the supplied shortcut "GFTE System Edit"
*** Or Be logged in as as Admin and start GFTE with 1 on the command line.

GFTE allows you to you to create/modify various properties for file extensions
- Create new extension
- Delete extension
- Change icon for extension
- Change description
- Change perceived type
- Change MIME content type
- Change default program used to open extension
- Edit command line args to pass to program to open extension
- Compares extensions - Shows what extensions were added or deleted (good to see what an install adds or deletes)
- Shows user modified and user created extensions now - ONLY GFTE does this!
- Search for an extension
- Modify Open With program list that explorer uses
- Edit DDE info for extension

The following are items I will implement to fullfill my idea :-) Suggestions are more than welcome!
Todo:
- Add abiltiy to choose ico files for extensions
- Modify explorer right click menu verbs for extension
- View/Edit recently used programs for extension
- Implement accelerators (CTRL+N etc...)
- add ability to modify flags for extension

User Customized will show any extensions that the currently logged on user modified.

User Defined will show any extensions the currently logged on user created
I always wanted to easily see what extensions I created or the system ones I modifed....

Right click an item for menu or double click to edit.

~Rob
(Gunner)