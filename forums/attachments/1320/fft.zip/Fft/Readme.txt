Fast Fourier Transform (FFT) - ASM 3dNow! Code
---------------------------------------------	
	by Pradeepan (arulpragasam@yahoo.com)
	-------------------------------------

This code is a translation of Basic Language FFT code found in the online book 'The Scientist and Engineer's Guide to Digital Signal Processing'(www.DSPguide.com).

This code uses 3dNow! Instructions. It can do FTT, Inverse FFT, and Rectangular to Polar conversion.

Usage:
------
	First use must include FFT.asm and Math.asm to your project.
There are four functions.
	1. InitFFT
	2. FFT
	3. IFFT
	4. RectToPol

1. InitFFT
----------
	Call this function first to initialize FFT variables.
	'Invoke InitFFT,FFTsize,pointer to hold REX[],pointer to hold IMX[] ,
	pointer to hold MAG[]', pointer to hold PHASE[].
	FFTsize have to be power of 2(256,512,1024...), for other four parameters 
	you have to give pointers to hold the newly created arrays.

ex.	Invoke InitFFT,1024,Offset pREX,Offset pIMX,Offset pMAG,Offset pPHS

2. FFT
-------
	usage- Invoke FFT, pointer to sample, pointer REX[], pointer IMX[].
	Samples have to be in 16bit integer stereo. If you want to directly
	access FFT with 32bit Float you have to modify one or two lines in the
	code. Other two parameters are pointers to previously created REX[] and
	IMX[].

ex.	invoke FFT, pSample, pREX, pIMX

3.IFFT
------
	Inverse FFT is similar to FFT.
	Usage- Invoke IFFT, pointer to sample, pointer REX[], pointer IMX[].
	In IFFT pointer to sample is the destination. After this call output
	will contain 16bit integer stereo samples.

ex.	invoke IFFT, pSample, pREX, pIMX

2. RectToPol
------------
	This function transfers data in rectangular form to polar form.It is useful 	for viewing frequency spectrum of the sound.
	usage- Invoke RectToPol,pointer REX[], pointer IMX[],pointer MAG[], pointer PHASE[]
	input:  REX[], IMX[]
	output: MAG[], PHASE[]
	

ex.	invoke RectToPol, pREX, pIMX, pMAG, pPHS


This code is not guaranteed to be 100% correct. It seems to work correctly. If you
find any error's please inform me (email- arulpragasam@yahoo.com).     
