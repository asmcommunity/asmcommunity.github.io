/*
DotXMM1Acc
Task:		Compute the dot product with SSE instructions.
Input:		[esp+4]  = pointer to X
		[esp+8]  = pointer to Y
		[esp+12] = n (# of array elements)
Output:		Dot product
*/
float DotXMM1Acc4E(float X[],float Y[],unsigned int m)
{
  __asm__ __volatile__(
    "pxor	%%xmm7,%%xmm7 			\n\t"		//xmm7 = accumulator for the 4-component vector
    "movl	12(%%esp),%%ecx 		\n\t"		//ecx = n
    "movl	4(%%esp),%%eax 			\n\t"		//eax -> X
    "movl	8(%%esp),%%edx 			\n\t"		//edx -> Y
    "subl	$4,%%esp			\n\t"		//stack space for function result
    "shl	$2,%%ecx 			\n\t"		//ecx = 4*n (float)
    ".align	16 				\n\t"
    "1:						\n\t"
    "movaps	(%%eax),%%xmm0 			\n\t"		//xmm0 = X[i+3] X[i+2] X[i+1] X[i]
    "mulps	(%%edx),%%xmm0 			\n\t"		//xmm0 = X[i+3]*Y[i+3] X[i+2]*Y[i+2] X[i+1]*Y[i+1] X[i]*Y[i]
    "leal	16(%%eax),%%eax 		\n\t"		//update X pointer
    "addps	%%xmm0,%%xmm7 			\n\t"		//sum up
    "leal	16(%%edx),%%edx 		\n\t"		//update Y pointer
    "subl	$16,%%ecx 			\n\t"		//count down
    "jnz	1b 				\n\t"
    "movhlps	%%xmm7,%%xmm0 			\n\t"		//get bits 64 - 127 from xmm7
    "addps	%%xmm0,%%xmm7 			\n\t"		//sums in 2 dwords
    "pshufd	$1,%%xmm7,%%xmm0 		\n\t"		//get bits 32 - 63 from xmm7
    "addss	%%xmm0,%%xmm7 			\n\t"		//sum in 1 dword
    "movss	%%xmm7,(%%esp) 			\n\t"		//store sum
    "flds	(%%esp) 			\n\t"		//load function result
    "addl	$4,%%esp 			\n\t"		//adjust stack
    "ret 					\n\t"
    :
    :"g"(m)
    :"%ecx","%eax","%edx"
    );
}

/*
DotXMM2Acc
Task:		Compute the dot product with SSE instructions.
Input:		[esp+4]  = pointer to X
		[esp+8]  = pointer to Y
		[esp+12] = n (# of array elements)
Output:		Dot product
*/
float DotXMM2Acc8E(float X[],float Y[],unsigned int m)
{
  __asm__ __volatile__(
    "pxor	%%xmm7,%%xmm7 			\n\t"		//xmm7 = 1. accumulator
    "movl	12(%%esp),%%ecx 		\n\t"		//ecx = n
    "movl	4(%%esp),%%eax 			\n\t"		//eax -> X
    "movl	8(%%esp),%%edx 			\n\t"		//edx -> Y
    "pxor	%%xmm6,%%xmm6 			\n\t"		//xmm6 = 2. accumulator
    "shl	$2,%%ecx 			\n\t"		//ecx = 4*n (float)
    "subl	$4,%%esp			\n\t"		//function result
    ".align	16 				\n\t"
    "1:						\n\t"
    "movaps	(%%eax),%%xmm0 			\n\t"		//xmm0 = X[i+3] X[i+2] X[i+1] X[i]
    "mulps	(%%edx),%%xmm0 			\n\t"		//xmm0 = X[i+3]*Y[i+3] X[i+2]*Y[i+2] X[i+1]*Y[i+1] X[i]*Y[i]
    "addps	%%xmm0,%%xmm7 			\n\t"		//sum up
    "movaps	16(%%eax),%%xmm1 		\n\t"		//xmm1 = X[i+7] X[i+6] X[i+5] X[i+4]
    "leal	32(%%eax),%%eax 		\n\t"		//update X pointer
    "mulps	16(%%edx),%%xmm1 		\n\t"		//xmm1 = X[i+7]*Y[i+7] X[i+6]*Y[i+6] X[i+5]*Y[i+5] X[i+4]*Y[i+4]
    "addps	%%xmm1,%%xmm6 			\n\t"		//sum up
    "leal	32(%%edx),%%edx 		\n\t"		//update Y pointer
    "subl	$32,%%ecx 			\n\t"		//count down
    "jnz	1b 				\n\t"
    "addps	%%xmm6,%%xmm7 			\n\t"		//add both partial vectors
    "movhlps	%%xmm7,%%xmm0 			\n\t"		//get bits 64 - 127 from xmm7
    "addps	%%xmm0,%%xmm7 			\n\t"		//sums in 2 dwords
    "pshufd	$1,%%xmm7,%%xmm0 		\n\t"		//get bits 32 - 63 from xmm7
    "addss	%%xmm0,%%xmm7 			\n\t"		//sum in 1 dword
    "movss	%%xmm7,(%%esp) 			\n\t"		//store sum
    "flds	(%%esp) 			\n\t"		//load function result
    "addl	$4,%%esp 			\n\t"		//adjust stack
    "ret 					\n\t"
    :
    :"g"(m)
    :"%ecx","%eax","%edx"
    );
}

/*
DotXMM2Acc16E
Task:		Compute the dot product with SSE instructions.
Input:		[esp+4]  = pointer to X
		[esp+8]  = pointer to Y
		[esp+12] = n (# of array elements)
Output:		Dot product
*/
float DotXMM2Acc16E(float X[],float Y[],unsigned int m)
{
  __asm__ __volatile__(
    "pxor	%%xmm4,%%xmm4 			\n\t"		//sums are in xmm4 and xmm5
    "movl	12(%%esp),%%ecx 		\n\t"		//ecx = n
    "movl	4(%%esp),%%eax 			\n\t"		//eax -> X
    "movl	8(%%esp),%%edx 			\n\t"		//edx -> Y
    "pxor	%%xmm5,%%xmm5 			\n\t"
    "shl	$2,%%ecx 			\n\t"		//ecx = 4*n (float)
    "subl	$4,%%esp			\n\t"		//function result

    //init pattern 1. iteration

    "movaps	(%%eax),%%xmm0 			\n\t"		//xmm0 = X[i+3] X[i+2] X[i+1] X[i+0]
    "movaps	16(%%eax),%%xmm1 		\n\t"		//xmm1 = X[i+7] X[i+6] X[i+5] X[i+4]
    "mulps	(%%edx),%%xmm0 			\n\t"		//xmm0 = X[i+3]*Y[i+3] X[i+2]*Y[i+2] X[i+1]*Y[i+1] X[i+0]*Y[i+0]
    "subl	$64,%%ecx 			\n\t"		//we need n-1 iterations
    "jz  	2f 				\n\t"		//jump: only 16 elements

    //main loop pattern

    ".align	16 				\n\t"
    "1:						\n\t"
    "movaps	32(%%eax),%%xmm2 		\n\t"		//xmm2 = X[i+11] X[i+10] X[i+9] X[i+8]
    "mulps	16(%%edx),%%xmm1 		\n\t"		//xmm1 = X[i+7]*Y[i+7] X[i+6]*Y[i+6] X[i+5]*Y[i+5] X[i+4]*Y[i+4]
    "addps	%%xmm0,%%xmm4 			\n\t"		//sum up
    "movaps	48(%%eax),%%xmm3 		\n\t"		//xmm3 = X[i+15] X[i+14] X[i+13] X[i+12]
    "leal	64(%%eax),%%eax 		\n\t"		//update X pointer
    "mulps	32(%%edx),%%xmm2 		\n\t"		//xmm2 = X[i+11]*Y[i+11] X[i+10]*Y[i+10] X[i+9]*Y[i+9] X[i+8]*Y[i+8]
    "addps	%%xmm1,%%xmm5 			\n\t"		//sum up
    "movaps	(%%eax),%%xmm0 			\n\t"		//xmm0 = X[i+3] X[i+2] X[i+1] X[i+0]
    "mulps	48(%%edx),%%xmm3 		\n\t"		//xmm3 = X[i+15]*Y[i+15] X[i+14]*Y[i+14] X[i+13]*Y[i+13] X[i+12]*Y[i+12]
    "leal	64(%%edx),%%edx 		\n\t"		//update Y pointer
    "addps	%%xmm2,%%xmm4 			\n\t"		//sum up
    "movaps	16(%%eax),%%xmm1 		\n\t"		//xmm1 = X[i+7] X[i+6] X[i+5] X[i+4]
    "mulps	(%%edx),%%xmm0 			\n\t"		//xmm0 = X[i+3]*Y[i+3] X[i+2]*Y[i+2] X[i+1]*Y[i+1] X[i+0]*Y[i+0]
    "addps	%%xmm3,%%xmm5 			\n\t"		//sum up
    "subl	$64,%%ecx 			\n\t"		//count down
    "jnz 	1b 				\n\t"

    //exit pattern last iteration

    "2:						\n\t"
    "movaps	32(%%eax),%%xmm2 		\n\t"		//xmm2 = X[i+11] X[i+10] X[i+9] X[i+8]
    "mulps	16(%%edx),%%xmm1 		\n\t"		//xmm1 = X[i+7]*Y[i+7] X[i+6]*Y[i+6] X[i+5]*Y[i+5] X[i+4]*Y[i+4]
    "addps	%%xmm0,%%xmm4 			\n\t"		//sum up
    "movaps	48(%%eax),%%xmm3 		\n\t"		//xmm3 = X[i+15] X[i+14] X[i+13] X[i+12]
    "mulps	32(%%edx),%%xmm2 		\n\t"		//xmm2 = X[i+11]*Y[i+11] X[i+10]*Y[i+10] X[i+9]*Y[i+9] X[i+8]*Y[i+8]
    "addps	%%xmm1,%%xmm5 			\n\t"		//sum up
    "mulps	48(%%edx),%%xmm3 		\n\t"		//xmm3 = X[i+15]*Y[i+15] X[i+14]*Y[i+14] X[i+13]*Y[i+13] X[i+12]*Y[i+12]
    "addps	%%xmm2,%%xmm4 			\n\t"		//sum up
    "addps	%%xmm3,%%xmm5 			\n\t"		//sum up

    //horizontal addition

    "addps	%%xmm5,%%xmm4 			\n\t"		//sum in xmm4
    "movhlps	%%xmm4,%%xmm0 			\n\t"		//get bits 64 - 127 from xmm4
    "addps	%%xmm0,%%xmm4 			\n\t"		//sums in 2 dwords
    "pshufd	$1,%%xmm4,%%xmm0 		\n\t"		//get bits 32 - 63 from xmm4
    "addss	%%xmm0,%%xmm4 			\n\t"		//sum in 1 dword
    "movss	%%xmm4,(%%esp) 			\n\t"		//store sum
    "flds	(%%esp) 			\n\t"		//load function result
    "addl	$4,%%esp 			\n\t"		//adjust stack
    "ret 					\n\t"
    :
    :"g"(m)
    :"%ecx","%eax","%edx"
    );
}

/*
DotXMM2Acc16E_v2
Task:		Compute the dot product with SSE instructions.
Input:		[esp+4]  = pointer to X
		[esp+8]  = pointer to Y
		[esp+12] = n (# of array elements)
Output:		Dot product
*/
float DotXMM2Acc16E_v2(float X[],float Y[],unsigned int m)
{
  __asm__ __volatile__(
    "pxor	%%xmm4,%%xmm4 			\n\t"		//sums are in xmm4 and xmm5
    "movl	12(%%esp),%%ecx 		\n\t"		//ecx = n
    "movl	4(%%esp),%%eax 			\n\t"		//eax -> X
    "movl	8(%%esp),%%edx 			\n\t"		//edx -> Y
    "pxor	%%xmm5,%%xmm5 			\n\t"
    "shl	$2,%%ecx 			\n\t"		//ecx = 4*n (float)
    "subl	$4,%%esp			\n\t"		//function result
    "subl	%%edx,%%eax 			\n\t"		//idea from drizz ==> 1 lea instruction saved inside the main loop

    //init pattern 1. iteration

    "movaps	(%%eax,%%edx,1),%%xmm0		\n\t"		//xmm0 = X[i+3] X[i+2] X[i+1] X[i+0]
    "movaps	16(%%eax,%%edx,1),%%xmm1	\n\t"		//xmm1 = X[i+7] X[i+6] X[i+5] X[i+4]
    "mulps	(%%edx),%%xmm0 			\n\t"		//xmm0 = X[i+3]*Y[i+3] X[i+2]*Y[i+2] X[i+1]*Y[i+1] X[i+0]*Y[i+0]
    "subl	$64,%%ecx 			\n\t"		//we need n-1 iterations
    "jz  	2f 				\n\t"		//jump: only 16 elements

    //main loop pattern

    ".align	16 				\n\t"
    "1:						\n\t"
    "movaps	32(%%eax,%%edx,1),%%xmm2	\n\t"		//xmm2 = X[i+11] X[i+10] X[i+9] X[i+8]
    "mulps	16(%%edx),%%xmm1 		\n\t"		//xmm1 = X[i+7]*Y[i+7] X[i+6]*Y[i+6] X[i+5]*Y[i+5] X[i+4]*Y[i+4]
    "addps	%%xmm0,%%xmm4 			\n\t"		//sum up
    "movaps	48(%%eax,%%edx,1),%%xmm3	\n\t"		//xmm3 = X[i+15] X[i+14] X[i+13] X[i+12]
    "mulps	32(%%edx),%%xmm2 		\n\t"		//xmm2 = X[i+11]*Y[i+11] X[i+10]*Y[i+10] X[i+9]*Y[i+9] X[i+8]*Y[i+8]
    "addps	%%xmm1,%%xmm5 			\n\t"		//sum up
    "movaps	64(%%eax,%%edx,1),%%xmm0	\n\t"		//xmm0 = X[i+3] X[i+2] X[i+1] X[i+0]
    "mulps	48(%%edx),%%xmm3 		\n\t"		//xmm3 = X[i+15]*Y[i+15] X[i+14]*Y[i+14] X[i+13]*Y[i+13] X[i+12]*Y[i+12]
    "leal	64(%%edx),%%edx 		\n\t"		//update Y pointer
    "addps	%%xmm2,%%xmm4 			\n\t"		//sum up
    "movaps	16(%%eax,%%edx,1),%%xmm1	\n\t"		//xmm1 = X[i+7] X[i+6] X[i+5] X[i+4]
    "mulps	(%%edx),%%xmm0 			\n\t"		//xmm0 = X[i+3]*Y[i+3] X[i+2]*Y[i+2] X[i+1]*Y[i+1] X[i+0]*Y[i+0]
    "addps	%%xmm3,%%xmm5 			\n\t"		//sum up
    "subl	$64,%%ecx 			\n\t"		//count down
    "jnz 	1b 				\n\t"

    //exit pattern last iteration

    "2:						\n\t"
    "movaps	32(%%eax,%%edx,1),%%xmm2	\n\t"		//xmm2 = X[i+11] X[i+10] X[i+9] X[i+8]
    "mulps	16(%%edx),%%xmm1 		\n\t"		//xmm1 = X[i+7]*Y[i+7] X[i+6]*Y[i+6] X[i+5]*Y[i+5] X[i+4]*Y[i+4]
    "addps	%%xmm0,%%xmm4 			\n\t"		//sum up
    "movaps	48(%%eax,%%edx,1),%%xmm3	\n\t"		//xmm3 = X[i+15] X[i+14] X[i+13] X[i+12]
    "mulps	32(%%edx),%%xmm2 		\n\t"		//xmm2 = X[i+11]*Y[i+11] X[i+10]*Y[i+10] X[i+9]*Y[i+9] X[i+8]*Y[i+8]
    "addps	%%xmm1,%%xmm5 			\n\t"		//sum up
    "mulps	48(%%edx),%%xmm3 		\n\t"		//xmm3 = X[i+15]*Y[i+15] X[i+14]*Y[i+14] X[i+13]*Y[i+13] X[i+12]*Y[i+12]
    "addps	%%xmm2,%%xmm4 			\n\t"		//sum up
    "addps	%%xmm3,%%xmm5 			\n\t"		//sum up

    //horizontal addition

    "addps	%%xmm5,%%xmm4 			\n\t"		//sum in xmm4
    "movhlps	%%xmm4,%%xmm0 			\n\t"		//get bits 64 - 127 from xmm4
    "addps	%%xmm0,%%xmm4 			\n\t"		//sums in 2 dwords
    "pshufd	$1,%%xmm4,%%xmm0 		\n\t"		//get bits 32 - 63 from xmm4
    "addss	%%xmm0,%%xmm4 			\n\t"		//sum in 1 dword
    "movss	%%xmm4,(%%esp) 			\n\t"		//store sum
    "flds	(%%esp) 			\n\t"		//load function result
    "addl	$4,%%esp 			\n\t"		//adjust stack
    "ret 					\n\t"
    :
    :"g"(m)
    :"%ecx","%eax","%edx"
    );
}

