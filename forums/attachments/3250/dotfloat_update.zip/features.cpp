#include <iostream>

using namespace std;

/*
ProcessorFeatures
Task:		Print processor features information for the user.
Input:		feature number
Output:		Features supported by processor and operating system.
*/
void ProcessorFeatures(unsigned int number)
{
  cout << endl
       << "Supported by Processor and installed Operating System:" << endl
       << "------------------------------------------------------" << endl << endl;
  switch(number){
    case 0:
      cout << "   Value of instruction set = " << number
           << "   ===> That indicates:" << endl << endl
           << "   There's something wrong!" << endl
           << "   Please call the function InstructionSet first!" << endl;
      break;
    case 1:
      cout << "   80386 Instruction Set." << endl;
      break;
    case 2:
      cout << "   80486 Instruction Set." << endl;
      break;
    case 3:
      cout << "   80486 Instruction Set," << endl
           << " + FPU (floating point unit) on chip." << endl;
      break;
    case 4:
      cout << "   Pentium Instruction Set," << endl
           << " + FPU (floating point unit) on chip," << endl
           << " + 57 MMX Instructions." << endl;
      break;
    case 5:
      cout << "   Pentium Instruction Set," << endl
           << " + FPU (floating point unit) on chip," << endl
           << " + support of FXSAVE and FXRSTOR," << endl
           << " + 57 MMX Instructions." << endl;
      break;
    case 6:
      cout << "   Pentium III Instruction Set," << endl
           << " + FPU (floating point unit) on chip," << endl
           << " + support of FXSAVE and FXRSTOR," << endl
           << " + 57 MMX Instructions," << endl
           << " + 70 SSE (Katmai) Instructions." << endl;
      break;
    case 7:
      cout << "   Pentium 4 Instruction Set," << endl
           << " + FPU (floating point unit) on chip," << endl
           << " + support of FXSAVE and FXRSTOR," << endl
           << " + 57 MMX Instructions," << endl
           << " + 70 SSE (Katmai) Instructions," << endl
           << " + 144 SSE2 (Willamette) Instructions." << endl;
      break;
    case 8:
      cout << "   Pentium 4 Instruction Set," << endl
           << " + FPU (floating point unit) on chip," << endl
           << " + support of FXSAVE and FXRSTOR," << endl
           << " + 57 MMX Instructions," << endl
           << " + 70 SSE (Katmai) Instructions," << endl
           << " + 144 SSE2 (Willamette) Instructions," << endl
           << " + 13 SSE3 (Prescott) Instructions." << endl;
      break;
    case 9:
      cout << "   Pentium 4 Instruction Set," << endl
           << " + FPU (floating point unit) on chip," << endl
           << " + support of FXSAVE and FXRSTOR," << endl
           << " + 57 MMX Instructions," << endl
           << " + 70 SSE (Katmai) Instructions," << endl
           << " + 144 SSE2 (Willamette) Instructions," << endl
           << " + 13 SSE3 (Prescott) Instructions," << endl
           << " + HTT (hyper thread technology) support.";
      break;
  }
  cout << endl;
}

/*
InstructionSet
Task:		Check the processor features.
Input:		Nothing
Output:		Available instruction set.
*/
unsigned int InstructionSet(void)
{
  __asm__ __volatile__(
    "pushl	%%ebx 				\n\t"
    "pushl	%%edi				\n\t"
    "pushl	%%esi				\n\t"

    /*
    We can be sure that at least an 80386 chip is available.
    Otherwise it would be impossible to install i386 Windows or Unix
    upon an old 8086 processor; the OS setup routine checks the
    available chipset. We must not search such dinosaur like
    8088, 8086, 80186, 80286, V20 etc. and can indicate with
    good conscience support for the 80386.
    */

    "movl	$1,%%edi 			\n\t"		//indicate 80386 instruction set

    /*
    Can we use CPUID? This instruction was added to Intel Pentiums
    and some later 80486 chips.
    */

    "pushf 					\n\t"		//push original EFLAGS
    "popl	%%eax 				\n\t"		//get original EFLAGS
    "xorl	$0x200000,%%eax 		\n\t"		//flip ID bit in EFLAGS
    "pushl	%%eax 				\n\t"		//new EFLAGS value on stack
    "popf 					\n\t"		//replace current EFLAGS value
    "pushf 					\n\t"		//get new EFLAGS
    "popl	%%ebx 				\n\t"		//store new EFLAGS in ebx
    "xorl	%%eax,%%ebx 			\n\t"
    "test	$0x200000,%%ebx			\n\t"		//can we toggle ID bit?
    "jne	1f	 			\n\t"		//no: jump
    "incl	%%edi 				\n\t"		//yes, we can use CPUID
    								//indicate 2: at least 80486 instructions
    /*
    Some older chips have built in CPUID as a stub without
    any functionality. We've to check that.
    */

    "xorl	%%eax,%%eax 			\n\t"		//ask for model
    "cpuid					\n\t"
    "test	%%eax,%%eax 			\n\t"		//function 1 supported?
    "je  	1f	 			\n\t"		//no: jump
    "movl	$1,%%eax 			\n\t"		//yes: get features
    "cpuid 					\n\t"

    /*
    Check for built in FPU
    */

    "test	$1,%%edx 			\n\t"		//do we have a built in FPU?
    "je  	1f	 			\n\t"		//no: jump
    "incl	%%edi 				\n\t"		//yes: built in FPU is available
    								//indicate 3: usage of FPU code
    /*
    Let's check now the support for SIMD (Single Instruction Multiple Data).
    It allows processors to operate on data in parallel and is therefore
    sometimes called vector programming.

    MMX (Multi Media eXtensions) was the first set of SIMD
    extensions and introduced in 1997.
    MMX added 57 new instructions that operate on single 64-bit quantities:
    two 32-bit quantities, four 16-bit quantities, or eight 8-bit quantities
    all at once. It uses the same register space as the FPU, so one
    cannot use MMX and floating point operations at the same time inside
    the same procedure.
    */

    "test	$0x800000,%%edx 		\n\t"		//MMX Support?
    "je  	1f	 			\n\t"		//no: jump
    "incl	%%edi 				\n\t"		//indicate 4: usage of MMX

    /*
    We need FXSAVE and FXRSTOR to check the operating system support
    of XMM (SSE, SSE2, SSE3 etc.). Check it next.
    */

    "test	$0x1000000,%%edx 		\n\t"		//support for FXSAVE and FXRSTOR?
    "je  	1f	 			\n\t"		//no: jump
    "incl	%%edi 				\n\t"		//indicate 5: usage of FXSAVE and FXRSTOR

    /*
    SSE is a newer SIMD extension to the Pentium III and AMD AthlonXP processors.
    Unlike MMX extensions, which occupy the same register space as the normal FPU
    registers, SSE comes with seperate register space. It adds 8 new 128-bit
    registers, divided into four 32-bit floating point values. These registers
    are called XMM0 - XMM7. An additional control register, MXCSR, is also
    available to control and check the status of SSE instructions. SSE provides
    access to 70 new instructions. It was introduced in 1999, and is sometimes
    called Katmai new Instructions (KNI), after the Pentium III codename.

    We check first the SSE support by the processor.
    */

    "test	$0x2000000,%%edx 		\n\t"		//SSE Support by Processor?
    "je  	1f	 			\n\t"		//no: jump

    /*
    At this point is clear: The processor supports SSE. We check now,
    if the operating system supports SSE, SSE2, SSE3 etc. This method
    differs from the method recommended by Intel. It is thoroughly
    tested on many different Intel and AMD processors, and is believed
    to work well.
    */

    "subl	$0x210,%%esp 			\n\t"		//allocate space for FXSAVE
    "and	$0xfffffff0,%%esp 		\n\t"		//align by 16
    "fxsave	(%%esp) 			\n\t"		//save entire FP, MMX and XMM registers
    "movl	192(%%esp),%%esi 		\n\t"		//read part of xmm2
    "xorl	$0xc46b57df,192(%%esp) 		\n\t"		//change value with a bit mask
    "fxrstor	(%%esp) 			\n\t"		//load changed value into xmm2
    "fxsave	(%%esp) 			\n\t"		//save again
    "movl	192(%%esp),%%eax 		\n\t"		//read changed xmm2 register
    "movl	%%esi,192(%%esp) 		\n\t"		//restore old value in buffer
    "fxrstor	(%%esp) 			\n\t"		//load old value into xmm2
    "xorl	%%eax,%%esi 			\n\t"		//get difference between old and new value
    "cmp	$0xc46b57df,%%esi 		\n\t"		//was xmm2 correct changed?
    "jne	1f	 			\n\t"		//no: check failed
    "incl	%%edi 				\n\t"		//indicate 6: SSE support

    /*
    At this point is clear: The installed operating system - native or
    as VM under another OS host - is aware of the new registers and will
    save these during task switches, for short: SIMD is supported by OS.

    Only to make things bullet proof: We call CPUID function 1 again.
    That refreshes the values in EAX, EBX, ECX, and EDX, which are
    needed for the rest of the SIMD check.
    */

    "movl	$1,%%eax 			\n\t"		//get features again
    "cpuid 					\n\t"

    /*
    Check now SSE2 support.
    SSE2 was first introduced on the Pentium 4, around February 2000,
    and are also known as Willamette instructions. These are very similar
    to the SSE instructions in structure, but allow more flexibility
    by number crunching. In total, 144 new instructions were added.
    */

    "test	$0x4000000,%%edx 		\n\t"		//SSE2 Support?
    "je  	1f	 			\n\t"		//no: jump
    "incl	%%edi 				\n\t"		//indicate 7: SSE2 Support

    /*
    SSE3 was introduced by Intel in early 2004 with their Prescott revision
    of the Pentium 4. SSE3 adds only 13 new instructions, but allows new
    features such as horizontal operation (operating across a single register
    instead down through multiple registers).
    For the SSE3 check, register ECX is of interest.
    */

    "test	$1,%%ecx 			\n\t"		//SSE3 support?
    "je  	1f	 			\n\t"		//no: jump
    "incl	%%edi 				\n\t"		//indicate 8: SSE3 Support

    /*
    Check HTT (hyper thread technology).
    */

    "test	$0x10000000,%%edx 		\n\t"		//HTT support?
    "je  	1f	 			\n\t"		//no: jump
    "incl	%%edi 				\n\t"		//indicate 9: HTT Support
    "1: 					\n\t"
    "movl	%%edi,%%eax 			\n\t"		//store function result
    "popl	%%esi 				\n\t"
    "popl	%%edi 				\n\t"
    "popl	%%ebx 				\n\t"
    "movl	%%ebp,%%esp 			\n\t"		//unwind stack
  :
  :
  );
}
