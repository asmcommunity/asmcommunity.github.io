#include <emmintrin.h>
float dotp256_intrin(float *v1, float *v2,unsigned int m)
{
  __m128 xmm1, *xv1=(__m128 *)v1, *xv2=(__m128 *)v2;
  __m128 xmm0 = {0,0,0,0};
	
  for (int i = 0; i < m/4; i++){
   xmm1 = _mm_mul_ps(xv1[i],xv2[i]);
   xmm0 = _mm_add_ps(xmm0,xmm1);
  }

  xmm1 = _mm_movehl_ps(xmm1,xmm0);
  xmm1 = _mm_add_ps(xmm1,xmm0);
  xmm0 = xmm1;
  xmm0 = (__m128)_mm_srli_epi64((__m128i)xmm0,32);
  xmm0 = _mm_add_ss(xmm0,xmm1);
	
  float result;
  _mm_store_ss( &result, xmm0);
  return result;
}

