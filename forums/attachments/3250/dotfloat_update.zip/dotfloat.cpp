#include <iostream>
#include <iomanip>
#include <cmath>
#include <cstdlib>
#include <ctime>

using namespace std;

const int N = 2048;						//vector size
const int FINISH = 5000000;                             	//end of time measure loop

extern unsigned int InstructionSet(void);
extern void ProcessorFeatures(unsigned int number);
extern void FillFloatVector(float V[],float value,unsigned int m);
extern float DotC(float X[],float Y[],unsigned int m);
extern float DotC2Acc(float X[],float Y[],unsigned int m);
extern float DotXMM1Acc4E(float X[],float Y[],unsigned int m);
extern float DotXMM2Acc8E(float X[],float Y[],unsigned int m);
extern float DotXMM2Acc16E(float X[],float Y[],unsigned int m);
extern float dotp256_intrin(float *v1, float *v2,unsigned int m);
extern float DotXMM2Acc16E_v2(float X[],float Y[],unsigned int m);

int main(int argc, char *argv[])
{
  float X[N] __attribute__ ((aligned (16)));			//the float vectors
  float Y[N] __attribute__ ((aligned (16)));
  float t;							//execution time
  float dot1,dot2;						//C++ results
  float dot3,dot4,dot5,dot7;					//Assembly Language results
  float dot6;							//intrinsic result
  unsigned int featurenumber = 0;				//value for processor features
  unsigned int i;						//time loop counter
  clock_t start, stop;						//time measure values

  //execution starts here

  featurenumber = InstructionSet();				//check processor features
  ProcessorFeatures(featurenumber);				//show features
  FillFloatVector(X,1.0,N);					//fill vectors
  FillFloatVector(Y,2.0,N);

  cout.precision(2);						//output format
  cout.setf(ios::fixed);

  cout << endl
       << "Calculating the dot product in 7 different variations." << endl
       << "That'll take a little while ..." << endl << endl;

  //time measure procedures

  start = clock();
  for(i = 0; i < FINISH; i++){
    dot1 = DotC(X,Y,N);
  }
  stop = clock();
  t = (float)(stop-start)/(float)CLOCKS_PER_SEC;
  cout << "Straight forward C++ implementation (FPU Code):" << endl
       << "-----------------------------------------------" << endl << endl
       << "Dot Product 1 = " << dot1 << endl
       << "Elapsed Time  = " << t << " Seconds" << endl << endl;

  start = clock();
  for(i = 0; i < FINISH; i++){
    dot2 = DotC2Acc(X,Y,N);
  }
  stop = clock();
  t = (float)(stop-start)/(float)CLOCKS_PER_SEC;
  cout << "C++ implementation (FPU Code - 2 Accumulators):" << endl
       << "-----------------------------------------------" << endl << endl
       << "Dot Product 2 = " << dot2 << endl
       << "Elapsed Time  = " << t << " Seconds" << endl << endl;


  //check SSE2 support

  if(featurenumber >= 7){					//can we use SSE2?
    start = clock();						//yes: go forward
    for(i = 0; i < FINISH; i++){
      dot6 = dotp256_intrin(X,Y,N);
    }
    stop = clock();
    t = (float)(stop-start)/(float)CLOCKS_PER_SEC;
    cout << "C++ Code with intrinsics (Original Code by Drizz):" << endl
         << "--------------------------------------------------" << endl << endl
         << "Dot Product 3 = " << dot6 << endl
         << "Elapsed Time  = " << t << " Seconds" << endl << endl;

    start = clock();
    for(i = 0; i < FINISH; i++){
      dot3 = DotXMM1Acc4E(X,Y,N);
    }
    stop = clock();
    t = (float)(stop-start)/(float)CLOCKS_PER_SEC;
    cout << "Simple SSE2 Code (1 Accumulator - 4 elements per cycle):" << endl
         << "--------------------------------------------------------" << endl << endl
         << "Dot Product 4 = " << dot3 << endl
         << "Elapsed Time  = " << t << " Seconds" << endl << endl;

    start = clock();
    for(i = 0; i < FINISH; i++){
      dot4 = DotXMM2Acc8E(X,Y,N);
    }
    stop = clock();
    t = (float)(stop-start)/(float)CLOCKS_PER_SEC;
    cout << "Solid SSE2 Code (2 Accumulators - 8 elements per cycle):" << endl
         << "--------------------------------------------------------" << endl << endl
         << "Dot Product 5 = " << dot4 << endl
         << "Elapsed Time  = " << t << " Seconds" << endl << endl;

    start = clock();
    for(i = 0; i < FINISH; i++){
      dot5 = DotXMM2Acc16E(X,Y,N);
    }
    stop = clock();
    t = (float)(stop-start)/(float)CLOCKS_PER_SEC;
    cout << "Better SSE2 Code (2 Accumulators - 16 elements per cycle):" << endl
         << "----------------------------------------------------------" << endl << endl
         << "Dot Product 6 = " << dot5 << endl
         << "Elapsed Time  = " << t << " Seconds" << endl << endl;

    start = clock();
    for(i = 0; i < FINISH; i++){
      dot7 = DotXMM2Acc16E_v2(X,Y,N);
    }
    stop = clock();
    t = (float)(stop-start)/(float)CLOCKS_PER_SEC;
    cout << "Squeezed SSE2 Code by drizz (2 Accumulators - 16 elements per cycle):" << endl
         << "---------------------------------------------------------------------" << endl << endl
         << "Dot Product 7 = " << dot7 << endl
         << "Elapsed Time  = " << t << " Seconds" << endl << endl;
  }
  else{
    cout << "SSE2 instruction set isn't available!" << endl	//no: print a message and terminate
         << "Program terminates now!" << endl << endl;
  }

  return 0;							//back to OS
}
