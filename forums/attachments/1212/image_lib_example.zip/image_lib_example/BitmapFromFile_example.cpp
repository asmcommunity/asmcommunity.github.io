
// BitmapFromFile() - demo using Ernest Murphy's image library
// have a look at project settings for "image.lib"
// my code is free to use - Stephan

#define STRICT

#include <string.h>
#include <stdlib.h>
#include <windows.h>
#include "image.h"


// Prototyp, CALLBACK == called from windows
LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);


// program name made global
const char szAppName[] = "BitmapFromFileDemo - type q to quit";

// not nice, but works, length has to do with '\0' char
// to give string functions information about end of line
char szX[] = "          ";
char szX_temp[]="    ";
char szY[] = "          ";
char szY_temp[]="    ";

char filepath[300];

HBITMAP hbitmap = NULL;


// like everytime
//		hInstance		== handle from this program instance
//		hprevInstance	== from old win16 where several instances got same memory space
//		szCmdLine		== parameters from command line
//		iShowCmd		== how to display current window (minimized, etc.)
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hprevInstance, PTSTR szCmdLine,int iShowCmd)
{
	
	HWND		hWnd;	// Handle of our window
	MSG			msg;	// structure needed to get window messages like: WM_LBUTTONDOWN
	WNDCLASS	wc;		// type of window class

	
	// define window properies before creating window -> fill WNDCLASS structure
	wc.style			=	CS_HREDRAW | CS_VREDRAW;		// repaint on vertical and horizontal sizechange
	wc.lpfnWndProc		=	WndProc;						// WndProc returns pointer of WndProc(), lpfn==long (far) pointer to function
	wc.cbClsExtra		=	0;								// preserver extra memory for this window
	wc.cbWndExtra		=	0;								//               -||-
	wc.hInstance		=	hInstance;						// only our winmain program could use this window
	wc.hCursor			=	LoadCursor(NULL,IDC_CROSS);		// no cursor allowed, else take: LoadCursor(NULL,IDC_CROSS);
	wc.hIcon			=	LoadIcon(NULL,IDI_APPLICATION);				// load icon for window; take standard one: LoadIcon(NULL,IDI_APPLICATION);
	wc.hbrBackground	=	(HBRUSH) GetSysColorBrush(COLOR_WINDOW);	// clear background of window with brush; (HBRUSH) GetStockObject(WHITE_BRUSH);
	wc.lpszClassName	=	szAppName;						// saves name for this own defined window calss to create more of this later
	wc.lpszMenuName		=	NULL;							// no menu yet
	
	RegisterClass(&wc);										// register our own defined window in window's windowmanager(!)
	
	
	
	hWnd = CreateWindow(szAppName,							// create window 'instance' of our own registered class
		szAppName,											// text in title
		WS_OVERLAPPEDWINDOW,								// style of window, could be: WS_OVERLAPPED, WS_POPUP
		CW_USEDEFAULT,										// X-Position
		CW_USEDEFAULT,										// Y-Position
		CW_USEDEFAULT,										// Windowwidth
		CW_USEDEFAULT,										// Windowheight
		NULL,
		NULL,
		hInstance,											// handle to our program instance: window is owned by our program instance
		NULL);
	
	
	// window is registered and created but not drawn yet
	ShowWindow(hWnd, iShowCmd);								// iShowCmd == open window in style...minimized...etc.
	UpdateWindow(hWnd);										// send WM_PAINT message to window for immediately redraw
	
	
	
	// take every message (range: 0 to 0 == infinite/all)
	// from message queue which is dedicated
	// to our whole prog (NULL) and save it in msg-structure
	// until prog gets close/terminate/kill
	// message -> GetMessage returns NULL
	while (GetMessage(&msg,NULL,0,0))
	{
		TranslateMessage(&msg);								// translate keyboard input
		DispatchMessage(&msg);								// distribute message to correct receivers
	}
	
	return msg.wParam;										//if program closed -> return value from wParam of last message
}


// message handling, react on User input and so on
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{			
	
	switch (message)
	{

	case WM_CREATE:
		{
			CoInitialize(NULL);
			GetCurrentDirectory(300,filepath);
 			lstrcat(filepath,"\\load.jpg");
			hbitmap = BitmapFromFile(filepath);		// CHANGE THIS PATH!

			if(hbitmap == NULL)
				MessageBox(NULL, "Could not load image!", "Error", MB_OK | MB_ICONEXCLAMATION);
			return 0;
		}
	case WM_DESTROY:										// if user clicked cross or alt+f4 ...
		{
			CoUninitialize();
			DeleteObject(hbitmap);
			PostQuitMessage(0);								// send quitmessage to getmessage, 0 == WM_QUIT
			return 0;
		}
	case WM_CHAR:											// if keyboard input
		{
			if (wParam=='q')
			{
				PostQuitMessage(0);
			}
			return 0;
			
		}
	case WM_ERASEBKGND:
		{	
			// prevent windows from erasing window content
			// by filling the window with backgrnd color
			return ((LRESULT)1);    
		} 
	case WM_PAINT:
		{
			
			
			RECT rc;
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hWnd, &ps);			
			
			// get the size of the client rectangle.
			GetClientRect(hWnd, &rc);
			
			// create a compatible DC.
			HDC hdcMem = CreateCompatibleDC(hdc);
			
			// create a bitmap big enough for our client rectangle and select it into off-screen
			HBITMAP hbmMem = CreateCompatibleBitmap(hdc,rc.right,rc.bottom);
			HBITMAP hbmOld = (HBITMAP) SelectObject(hdcMem, hbmMem);
			
			// erase the background (important) and do painting --> we use a doublebuffer to prevent flickering :)
			FillRect(hdcMem, &rc, CreateSolidBrush(GetSysColor(COLOR_SCROLLBAR)));
			{			
				// mdc(hdc),holdbm select,bitblt(hdcmem),back select,deletedc
				HDC hdcMemBm = CreateCompatibleDC(hdc);
				HANDLE	hbmOldBm = SelectObject(hdcMemBm, hbitmap);
				BitBlt(hdcMem,0, 0, rc.right, rc.bottom, hdcMemBm, 0, 0, SRCCOPY);
				SelectObject(hdcMemBm,hbmOldBm);
				DeleteDC(hdcMemBm);									
				
				SetBkMode(hdcMem, TRANSPARENT);
				SetTextColor(hdcMem, RGB(0,0,240));

				DrawText(hdcMem,szX,-1,&rc,DT_SINGLELINE | DT_TOP    | DT_RIGHT);
				DrawText(hdcMem,szY,-1,&rc,DT_SINGLELINE | DT_BOTTOM | DT_LEFT);
			}
			
			// Blt the changes to the screen DC.
			BitBlt(hdc, 0, 0, rc.right, rc.bottom, hdcMem, 0, 0, SRCCOPY);
			
			// Done with off-screen bitmap and DC.
			SelectObject(hdcMem, hbmOld);
			DeleteObject(hbmMem);
			DeleteDC(hdcMem);		
			
			EndPaint(hWnd, &ps);
			
			
			return(0);
		}
	case WM_GETMINMAXINFO:
		{
			
			MINMAXINFO* sMMI = (LPMINMAXINFO) lParam;
			sMMI->ptMinTrackSize.x = 250;
			sMMI->ptMinTrackSize.y = 100;
			
			return(0);
		}
	case WM_MOUSEMOVE:
		{
			
			itoa((int)LOWORD(lParam), szX_temp,10);
			strncpy(szX,"X POS: ",(int)sizeof("X POS: "));
			strncat(szX,szX_temp,(int)sizeof(szX_temp));
			
			itoa((int)HIWORD(lParam), szY_temp,10);
			strncpy(szY,"Y POS: ",(int)sizeof("Y POS: "));
			strncat(szY,szY_temp,(int)sizeof(szY_temp));

			// force redraw(important)
			InvalidateRect(hWnd,NULL,TRUE);

			return(0);
			
		} 	
	}
	
	// send all other messages to standard message handling from DefWindowProc, minimized.. etc.
	return DefWindowProc(hWnd, message, wParam, lParam);
}