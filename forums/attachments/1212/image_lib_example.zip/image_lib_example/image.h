/*
** Ernest Murphy's Image Library
*/

#ifdef __cplusplus
extern "C" {
#endif

HBITMAP __stdcall BitmapFromFile(char *pszFileName);
HBITMAP __stdcall BitmapFromMemory(void *pMemory, DWORD dwFileSize);
//HBITMAP BitmapFromPicture(IPicture *pPicture); // don't type of IPICTURE
HBITMAP __stdcall BitmapFromResource(HINSTANCE hModule, DWORD ResNumber);

#ifdef __cplusplus
}
#endif
