#define _WIN32_WINNT 0x0400
#define _WIN32_DCOM 

#include <stdio.h>
#include <tchar.h>
#include <windows.h>
#include <wbemidl.h>
#pragma comment(lib,"wbemuuid.lib")

void _tmain(int argc, _TCHAR* argv[])
{
    // result code from COM calls 
    HRESULT hr = 0; 

    // COM interface pointers 
    IWbemLocator         *locator  = NULL;
    IWbemServices        *services = NULL;
    IEnumWbemClassObject *results  = NULL; 

    // BSTR strings we'll use (http://msdn.microsoft.com/en-us/library/ms221069.aspx) 
    BSTR resource = SysAllocString(L"ROOT\\CIMV2");   //Ĭ�������ռ�Ϊroot\cimv2
    BSTR language = SysAllocString(L"WQL"); //WQL��WMI�еĲ�ѯ����,ȫ����WMI Query Language
    BSTR query    = SysAllocString(L"SELECT * FROM Win32_Processor"); //��ѯ��Win32_Processor

    // initialize COM 
    hr = CoInitializeEx(0, COINIT_MULTITHREADED);
    hr = CoInitializeSecurity(NULL, -1, NULL, NULL, RPC_C_AUTHN_LEVEL_DEFAULT, RPC_C_IMP_LEVEL_IMPERSONATE, NULL, EOAC_NONE, NULL); 

    // connect to WMI 
    hr = CoCreateInstance(&CLSID_WbemLocator, 0, CLSCTX_INPROC_SERVER, &IID_IWbemLocator, (LPVOID *) &locator);
    hr = locator->lpVtbl->ConnectServer(locator, resource, NULL, NULL, NULL, 0, NULL, NULL, &services); 

    // issue a WMI query 
    hr = services->lpVtbl->ExecQuery(services, language, query, WBEM_FLAG_BIDIRECTIONAL, NULL, &results); 

    // list the query results 
    if (results != NULL) {
        IWbemClassObject *result = NULL;
        ULONG returnedCount = 0; 

        // enumerate the retrieved objects 
        while((hr = results->lpVtbl->Next(results, WBEM_INFINITE, 1, &result, &returnedCount)) == S_OK) {
            VARIANT name;
            VARIANT speed;
            VARIANT DeviceID;
            VARIANT ProcessorId;

            // obtain the desired properties of the next result and print them out 
            hr = result->lpVtbl->Get(result, L"Name", 0, &name, 0, 0);
            hr = result->lpVtbl->Get(result, L"MaxClockSpeed", 0, &speed, 0, 0);
            hr = result->lpVtbl->Get(result, L"DeviceID", 0, &DeviceID, 0, 0);
            hr = result->lpVtbl->Get(result, L"ProcessorId", 0, &ProcessorId, 0, 0);
            
            wprintf(L"%s, %dMHz\r\n%s:%s\n", name.bstrVal, speed.intVal, DeviceID.bstrVal, ProcessorId.bstrVal); 

            // release the current result object 
            result->lpVtbl->Release(result);
        }
    } 

    // release WMI COM interfaces 
    results->lpVtbl->Release(results);
    services->lpVtbl->Release(services);
    locator->lpVtbl->Release(locator); 

    // unwind everything else we've allocated 
    CoUninitialize(); 

    SysFreeString(query);
    SysFreeString(language);
    SysFreeString(resource);
} 
/* By http://msdn.microsoft.com/en-us/library/aa394373(v=VS.85).aspx
Win32_Processor Class   
The Win32_ProcessorWMI class represents a device that can interpret a sequence of instructions on a computer running on a Windows operating system. On a multiprocessor computer, one instance of the Win32_Processor class exists for each processor.

The following syntax is simplified from Managed Object Format (MOF) code and includes all of the inherited properties. Properties are listed in alphabetic order, not MOF order.

Syntax
Copyclass Win32_Processor : CIM_Processor
{
  uint16   AddressWidth;
  uint16   Architecture;
  uint16   Availability;
  string   Caption;
  uint32   ConfigManagerErrorCode;
  boolean  ConfigManagerUserConfig;
  uint16   CpuStatus;
  string   CreationClassName;
  uint32   CurrentClockSpeed;
  uint16   CurrentVoltage;
  uint16   DataWidth;
  string   Description;
  string   DeviceID; <---------------
  boolean  ErrorCleared;
  string   ErrorDescription;
  uint32   ExtClock;
  uint16   Family;
  datetime InstallDate;
  uint32   L2CacheSize;
  uint32   L2CacheSpeed;
  uint32   L3CacheSize;
  uint32   L3CacheSpeed;
  uint32   LastErrorCode;
  uint16   Level;
  uint16   LoadPercentage;
  string   Manufacturer;
  uint32   MaxClockSpeed;  <---------
  string   Name;    <----------------
  uint32   NumberOfCores;
  uint32   NumberOfLogicalProcessors;
  string   OtherFamilyDescription;
  string   PNPDeviceID;
  uint16   PowerManagementCapabilities[];
  boolean  PowerManagementSupported;
  string   ProcessorId; <------------
  uint16   ProcessorType;
  uint16   Revision;
  string   Role;
  string   SocketDesignation;
  string   Status;
  uint16   StatusInfo;
  string   Stepping;
  string   SystemCreationClassName;
  string   SystemName;
  string   UniqueId;
  uint16   UpgradeMethod;
  string   Version;
  uint32   VoltageCaps;
};
*/

/*  By OAIdl.h
typedef /* [wire_marshal] */ //struct tagVARIANT VARIANT;
/*
struct tagVARIANT
    {
    union 
        {
        struct __tagVARIANT
            {
            VARTYPE vt;
            WORD wReserved1;
            WORD wReserved2;
            WORD wReserved3;
            union 
                {
                LONGLONG llVal;
                LONG lVal;
                BYTE bVal;
                SHORT iVal;
                FLOAT fltVal;
                DOUBLE dblVal;
                VARIANT_BOOL boolVal;
                _VARIANT_BOOL bool;
                SCODE scode;
                CY cyVal;
                DATE date;
                BSTR bstrVal; <-------------
                IUnknown *punkVal;
                IDispatch *pdispVal;
                SAFEARRAY *parray;
                BYTE *pbVal;
                SHORT *piVal;
                LONG *plVal;
                LONGLONG *pllVal;
                FLOAT *pfltVal;
                DOUBLE *pdblVal;
                VARIANT_BOOL *pboolVal;
                _VARIANT_BOOL *pbool;
                SCODE *pscode;
                CY *pcyVal;
                DATE *pdate;
                BSTR *pbstrVal;
                IUnknown **ppunkVal;
                IDispatch **ppdispVal;
                SAFEARRAY **pparray;
                VARIANT *pvarVal;
                PVOID byref;
                CHAR cVal;
                USHORT uiVal;
                ULONG ulVal;
                ULONGLONG ullVal;
                INT intVal;  <--------------
                UINT uintVal;
                DECIMAL *pdecVal;
                CHAR *pcVal;
                USHORT *puiVal;
                ULONG *pulVal;
                ULONGLONG *pullVal;
                INT *pintVal;
                UINT *puintVal;
                struct __tagBRECORD
                    {
                    PVOID pvRecord;
                    IRecordInfo *pRecInfo;
                    } 	__VARIANT_NAME_4;
                } 	__VARIANT_NAME_3;
            } 	__VARIANT_NAME_2;
        DECIMAL decVal;
        } 	__VARIANT_NAME_1;
    } ;
typedef VARIANT *LPVARIANT;

typedef VARIANT VARIANTARG;

typedef VARIANT *LPVARIANTARG;

*/
