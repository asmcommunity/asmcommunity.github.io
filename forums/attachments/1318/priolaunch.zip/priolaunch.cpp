#define WIN32_LEAN_AND_MEAN
#include <windows.h>

int main(int argc, char* argv[])
{
	PROCESS_INFORMATION	pi;
	STARTUPINFO			si;
	DWORD				affi = 1;
	
	GetStartupInfo(&si);
	
	if(!CreateProcess(0, argv[1], 0, 0, 0, CREATE_SUSPENDED, 0, 0, &si, &pi))
		return -1;

	SetProcessAffinityMask(pi.hProcess, affi);
	SetThreadAffinityMask(pi.hThread, affi);
	SetPriorityClass(pi.hProcess, REALTIME_PRIORITY_CLASS);
	SetThreadPriority(pi.hThread, THREAD_PRIORITY_TIME_CRITICAL);

	ResumeThread(pi.hThread);

	WaitForSingleObject(pi.hProcess, INFINITE);
	CloseHandle(pi.hProcess);
	CloseHandle(pi.hThread);
}
