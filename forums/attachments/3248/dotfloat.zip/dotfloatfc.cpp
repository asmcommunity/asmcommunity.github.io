/*
FillFloatVector
Purpose:	Fill a float vector with values; start with a defined value.
Input:		V     = vector to fill
		value = start value
		m     = number of vector elements
*/
void FillFloatVector(float V[],float value,unsigned int m)
{
  unsigned int i;						//loop counter
  for(i = 0; i < m; i++){					//fill loop
    V[i] = value;
    value++;
  }
}

/*
DotC
Task:		Calculate the dot product of 2 vectors of the dimension m.
Input:		X = 1. vector
		Y = 2. vector
		m = # of array elements
Output:		dot product
*/
float DotC(float X[],float Y[],unsigned int m)
{
  register float s = 0;						//dot product
  register unsigned int i;					//counter
  for(i = 0; i < m; i++){					//compute the dot product
    s += X[i]*Y[i];
  }
  return s;
}

/*
DotC2Acc
Task:		Calculate the dot product of 2 vectors of the dimension m.
Input:		X = 1. vector
		Y = 2. vector
		m = # of array elements
Output:		dot product
Remark:		Loop is rolled out by a factor of 2.
*/
float DotC2Acc(float X[],float Y[],unsigned int m)
{
  register float s0 = 0;					//results
  register float s1 = 0;
  register unsigned int i;
  for(i = 0; i < m; i+=2){
    s0 += X[i]*Y[i];
    s1 += X[i+1]*Y[i+1];
  }
  return s0+s1;
}

