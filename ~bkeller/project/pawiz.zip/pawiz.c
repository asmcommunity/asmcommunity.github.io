#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <tchar.h>
#include <wizard.h>
#include "pawiz.h"

#define	NELEMS(a) ( sizeof ( a ) / sizeof ( a [ 0 ] ) )

typedef enum {
	DIALOG_APPLICATION,
	SDI_APPLICATION,
	CONSOLE_APPLICATION,
	LIBRARY_APPLICATION,
	DLL_APPLICATION
} APPLICATION_TYPE;

static TCHAR g_szProjectName [ 9 ];
static TCHAR g_szPROJECTNAME [ 9 ];
static TCHAR g_szDisplayName [ 80 ];

static int iProjectName;
static int iDisplayName;

static APPLICATION_TYPE g_fType = DIALOG_APPLICATION;

static BOOL WINAPI Step_One ( HWND, enum WizAction );
static BOOL WINAPI Step_Two ( HWND, enum WizAction );
static void WINAPI ParseLine ( PTSTR, int );

BOOL WINAPI WizMain ( void ) {

	TCHAR szBuffer[1025];
	TCHAR szTail[16];

	/* Initialize Wizard */
	if ( ! WizGetProjectName ( szBuffer, NELEMS ( szBuffer ) ) ) return ( FALSE );
	iProjectName = lstrlen ( lstrcpyn ( g_szProjectName, szBuffer, NELEMS ( g_szProjectName ) ) );
	CharUpper ( lstrcpy ( g_szPROJECTNAME, g_szProjectName ) );
	LoadString ( WizGetInstanceHandle(), IDS_APPLICATION, szTail, NELEMS ( szTail ) );
	lstrcpyn ( g_szDisplayName, szBuffer, NELEMS ( g_szDisplayName ) - lstrlen ( szTail ) );
	lstrcat ( g_szDisplayName, szTail );

	/* Add Dialogs */
	if (	! WizAddStep ( MAKEINTRESOURCE ( IDD_START ), Step_One ) ||
		! WizAddStep ( MAKEINTRESOURCE ( IDD_FINISH ), Step_Two )
	) return ( FALSE );

	/* Run Wizard */
	if ( ! WizShowSteps ( ) ) return ( FALSE );

	/* Run the source through the Preparser */
	iDisplayName = lstrlen ( g_szDisplayName );
	if ( g_fType == DIALOG_APPLICATION ) {

		/* Set Project Type */
		if ( ! WizSetProjectType ( Project_Win32_GUI ) ) return ( FALSE );

		/* Create Dialog As Main Project */
		if (	! WizWriteTextFileFromResourceA ( "main.asm", MAKEINTRESOURCE ( FILE_DIALOG_MAIN_ASM ), ParseLine ) ||
			! WizWriteTextFileFromResourceA ( "main.inc", MAKEINTRESOURCE ( FILE_DIALOG_MAIN_INC ), ParseLine ) ||
			! WizWriteTextFileFromResourceA ( "main.rc", MAKEINTRESOURCE ( FILE_DIALOG_MAIN_RC ), ParseLine )
		) return ( FALSE );

		/* Add source files to the project */
		if (	! WizAddProjectFile ( "main.asm" ) ||
			! WizAddProjectFile ( "main.rc" )
		) return ( FALSE );

	} else if ( g_fType == SDI_APPLICATION ) {

		/* Set Project Type */
		if ( ! WizSetProjectType ( Project_Win32_GUI ) ) return ( FALSE );

		/* Create SDI Application Project */
		if (	! WizWriteTextFileFromResourceA ( "main.asm", MAKEINTRESOURCE ( FILE_SDIAPP_MAIN_ASM ), ParseLine ) ||
			! WizWriteTextFileFromResourceA ( "main.inc", MAKEINTRESOURCE ( FILE_SDIAPP_MAIN_INC ), ParseLine )
		) return ( FALSE );

		/* Add source files to the project */
		if ( ! WizAddProjectFile ( "main.asm" ) ) return ( FALSE );

	} else if ( g_fType == CONSOLE_APPLICATION ) {

		/* Set Project Type */
		if ( ! WizSetProjectType ( Project_Win32_Console ) ) return ( FALSE );

		/* Create Console Application Project */
		if (	! WizWriteTextFileFromResourceA ( "main.asm", MAKEINTRESOURCE ( FILE_CONSOLE_MAIN_ASM ), ParseLine ) ||
			! WizWriteTextFileFromResourceA ( "main.inc", MAKEINTRESOURCE ( FILE_CONSOLE_MAIN_INC ), ParseLine )
		) return ( FALSE );

		/* Add source files to the project */
		if ( ! WizAddProjectFile ( "main.asm" ) ) return ( FALSE );

	} else if ( g_fType == LIBRARY_APPLICATION ) {

		/* Set Project Type */
		if ( ! WizSetProjectType ( Project_Win32_Library ) ) return ( FALSE );

		/* Create Console Application Project */
		if (	! WizWriteTextFileFromResourceA ( "main.asm", MAKEINTRESOURCE ( FILE_LIBRARY_MAIN_ASM ), ParseLine ) ||
			! WizWriteTextFileFromResourceA ( "main.inc", MAKEINTRESOURCE ( FILE_LIBRARY_MAIN_INC ), ParseLine )
		) return ( FALSE );

		/* Add source files to the project */
		if ( ! WizAddProjectFile ( "main.asm" ) ) return ( FALSE );

	} else if ( g_fType == DLL_APPLICATION ) {

		/* Set Project Type */
		if ( ! WizSetProjectType ( Project_Win32_DLL ) ) return ( FALSE );

		/* Create Console Application Project */
		if (	! WizWriteTextFileFromResourceA ( "main.asm", MAKEINTRESOURCE ( FILE_DLL_MAIN_ASM ), ParseLine ) ||
			! WizWriteTextFileFromResourceA ( "main.def", MAKEINTRESOURCE ( FILE_DLL_MAIN_DEF ), ParseLine )
		) return ( FALSE );

		/* Add source files to the project */
		if (	! WizAddProjectFile ( "main.asm" ) ||
			! WizAddProjectFile ( "main.def" )
		) return ( FALSE );

	}

	return ( TRUE );
}

static BOOL WINAPI Step_One ( HWND hWnd, enum WizAction action ) {

	switch ( action ) {
		case Action_SetActive:
		SetDlgItemText ( hWnd, IDC_DISPLAYNAME, g_szDisplayName );
		if ( g_fType == DIALOG_APPLICATION ) CheckRadioButton ( hWnd, IDC_DLGAPP, IDC_DLLAPP, IDC_DLGAPP );
		else if ( g_fType == SDI_APPLICATION ) CheckRadioButton ( hWnd, IDC_DLGAPP, IDC_LIBAPP, IDC_SDIAPP );
		else if ( g_fType == CONSOLE_APPLICATION ) CheckRadioButton ( hWnd, IDC_DLGAPP, IDC_LIBAPP, IDC_CONAPP );
		else if ( g_fType == LIBRARY_APPLICATION ) CheckRadioButton ( hWnd, IDC_DLGAPP, IDC_LIBAPP, IDC_LIBAPP );
		else if ( g_fType == DLL_APPLICATION ) CheckRadioButton ( hWnd, IDC_DLGAPP, IDC_LIBAPP, IDC_DLLAPP );
		break;

		case Action_KillActive:
		GetDlgItemText ( hWnd, IDC_DISPLAYNAME, g_szDisplayName, NELEMS(g_szDisplayName) );
		if ( IsDlgButtonChecked ( hWnd, IDC_DLGAPP ) ) g_fType = DIALOG_APPLICATION;
		else if ( IsDlgButtonChecked ( hWnd, IDC_SDIAPP ) ) g_fType = SDI_APPLICATION;
		else if ( IsDlgButtonChecked ( hWnd, IDC_CONAPP ) ) g_fType = CONSOLE_APPLICATION;
		else if ( IsDlgButtonChecked ( hWnd, IDC_LIBAPP ) ) g_fType = LIBRARY_APPLICATION;
		else if ( IsDlgButtonChecked ( hWnd, IDC_DLLAPP ) ) g_fType = DLL_APPLICATION;
		return ( g_szDisplayName [ 0 ] != '\0' );
	}
	return ( FALSE );
}

static BOOL WINAPI Step_Two ( HWND hWnd, enum WizAction action ) {

	TCHAR szProjectPath[260];

	switch ( action ) {
		case Action_SetActive:
		SendDlgItemMessage ( hWnd, IDC_RESULTFILES, LB_RESETCONTENT, 0, 0 );
		SendDlgItemMessage ( hWnd, IDC_RESULTFILES, LB_ADDSTRING, 0, ( LPARAM ) ( LPSTR ) "main.asm" );
		if ( g_fType != DLL_APPLICATION ) SendDlgItemMessage ( hWnd, IDC_RESULTFILES, LB_ADDSTRING, 0, ( LPARAM ) ( LPSTR ) "main.inc" );
		if ( g_fType == DLL_APPLICATION ) SendDlgItemMessage ( hWnd, IDC_RESULTFILES, LB_ADDSTRING, 0, ( LPARAM ) ( LPSTR ) "main.def" );
		if ( g_fType == DIALOG_APPLICATION ) SendDlgItemMessage ( hWnd, IDC_RESULTFILES, LB_ADDSTRING, 0, ( LPARAM ) ( LPSTR ) "main.rc" );

		GetCurrentDirectory ( NELEMS(szProjectPath), szProjectPath );
		SetDlgItemText ( hWnd, IDC_PROJFOLDER, szProjectPath );
		return ( TRUE );

		case Action_KillActive:
		return ( TRUE );
	}
	return ( FALSE );
}

static void WINAPI ParseLine ( PTSTR pLine, int iMax ) {

	PTSTR ptr;
	int len;

	while ( 1 ) {
		ptr = _tcsstr ( pLine, TEXT("<PROJECT>") );
		if ( ptr != NULL ) {
			len = lstrlen ( pLine );
			_tmemmove ( ptr + iProjectName, ptr + 9, pLine + len - ( ptr + 9 ) + 1 );
			_tmemcpy ( ptr, g_szProjectName, iProjectName );
			continue;
		}
		ptr = _tcsstr ( pLine, TEXT("<DISPLAY>") );
		if ( ptr != NULL ) {
			len = lstrlen ( pLine );
			_tmemmove ( ptr + iDisplayName, ptr + 9, pLine + len - ( ptr + 9 ) + 1 );
			_tmemcpy ( ptr, g_szDisplayName, iDisplayName );
			continue;
		}
		break;
	}
}
