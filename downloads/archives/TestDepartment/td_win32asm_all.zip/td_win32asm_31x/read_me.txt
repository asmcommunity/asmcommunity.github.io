;==============================================================================
;	    Test Department's WINDOWS 32 BIT x86 ASSEMBLY EXAMPLE	31x
;==============================================================================

Content of td_win32asm_31x.zip :
=================================

read_me.txt          --- this file
td_id.diz            --- Test Department's Websites and Email
builddll.bat         --- batch file for MASM32, copy it in c:\MASM32\bin directory
td_win32asm_310.asm  --- source code of the DLL
td_win32asm_310.def  --- required, defines the DLL filename and exported functions
td_win32asm_310.dll  --- created DLL
td_win32asm_310.lib  --- created LIBRARY
td_win32asm_310.inc  --- created INCLUDE ( L2inca.exe /m td_win32asm_310.lib )
td_win32asm_311.asm  --- source, loads a DLL and calls a function inside implicit
td_win32asm_311.exe  --- created EXE
td_win32asm_312.asm  --- source, loads a DLL and calls a function inside explicit
td_win32asm_312.exe  --- created EXE
